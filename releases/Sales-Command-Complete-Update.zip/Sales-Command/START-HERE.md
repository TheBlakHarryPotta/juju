# Start Sales Command

This is the built local-first application, not a single HTML attachment. Keep the `dist` folder together.

If you have Node.js 22.12 or newer:

1. In this folder, run `npm ci` once.
2. Run `npm run build`, then `npm run preview`.
3. Open the address printed by the server in your browser.
4. Choose **Device & Backups** and create your blank hotel.
5. Add one SRP code, import a redacted report, and export your first encrypted backup.

The downloadable release also includes launchers that serve the already-built `dist` folder using Python 3. On Windows run `start-windows.bat`; on macOS/Linux run `bash start-local.sh`. Both use loopback port 4173, preserving the same browser origin between sessions. Keep the server running while you use the app.

All files and work records remain in the browser on that computer. Back up before clearing browser data, changing the site's address, or moving computers. The application starts with the preserved sample workspace; a blank hotel does not inherit the sample hotel's contacts, contract details or targets.

Voice memos and typed transcripts work immediately. Automatic local transcription requires the separate Python companion and an official model download: see `tools/README.md`. The current cloud environment blocks that model source. No actual speech recognition benchmark has been completed.

See `README.md`, `docs/WORKFLOWS.md` and `docs/VALIDATION.md` for supported formats, signing limits and test evidence. No Hilton-system connection or hosted deployment is included.

## M1 Mac transcription update

Use `setup-mac.command` for the pinned native whisper.cpp installation and verified tiny.en model download. Then run `start-mac.command` to start the local app and speech bridge. The bridge uses Python only for local HTTP and audio decoding; inference runs in the native executable, with Metal enabled by the installer on Apple Silicon. It runs only when requested. An official model download is required; the cloud environment has not yet allowed that destination.

The Mac installer checks for Apple Command Line Tools and CMake. Its Mac/Metal build must be run on your Mac; the Linux executable built in this workspace is not a Mac binary and is not bundled into the portable release.

## Contract update for an already installed Mac

Export an encrypted backup first. Extract this update into a separate folder, then run `update-mac.command` from the NEW folder and select your EXISTING installed Sales-Command folder. It updates only app files and preserves the installed transcription engine/model/token. Restart using your original launcher and hostname/port. Open once online, close all Sales Command tabs, and reopen to activate the updated offline cache. See `docs/CONTRACTS-UPDATE.md` and `docs/TEAM-CHANGE-REVIEW.md`.

Pittsburgh edition: see `docs/PITTSBURGH-UPDATE.md` for Import Station, Tours,
Networking, Prospect Pipeline, automatic weekly reporting and app-only Mac update
steps. Open `docs/PITTSBURGH-PREVIEW.html` to compare the four themes and phone
screenshots. The main app appearance button controls colors and animations.

Complete workflows: start with `docs/COMPLETE-UPDATE.md`. Deal Package, Need Date
Matchmaker, Repeat Business Memory and Follow-ups & History are implemented in
this build. The app-only Mac update preserves your installed speech setup.
