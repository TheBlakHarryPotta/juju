import { defineConfig } from '@playwright/test';
export default defineConfig({
  testDir: './tests',
  outputDir: process.env.SC_TEST_OUTPUT || 'test-results',
  testMatch: '**/*.spec.js',
  webServer: process.env.SC_SKIP_SERVERS ? undefined : [
    { command: 'npm run dev -- --host 127.0.0.1 --port 5173', url: 'http://127.0.0.1:5173', reuseExistingServer: true, timeout: 30_000 },
    { command: 'npm run build && npm run preview -- --host 127.0.0.1 --port 4173', url: 'http://127.0.0.1:4173', reuseExistingServer: true, timeout: 120_000 },
  ],
  timeout: 45_000,
  expect: { timeout: 8_000 },
  fullyParallel: false,
  workers: 1,
  reporter: [['list'], ['json', { outputFile: `${process.env.SC_TEST_OUTPUT || 'test-results'}/results.json` }]],
  use: {
    baseURL: process.env.SC_TEST_URL || 'http://127.0.0.1:5173',
    browserName: 'chromium',
    launchOptions: { executablePath: process.env.CHROMIUM_PATH || '/usr/bin/chromium', args: ['--no-sandbox'] },
    trace: 'retain-on-failure',
    screenshot: 'only-on-failure',
    reducedMotion: 'reduce',
  },
});
