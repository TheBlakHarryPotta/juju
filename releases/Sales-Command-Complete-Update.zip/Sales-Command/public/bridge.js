/* A narrow adapter keeps the established Sales Command calculators intact. */
(() => {
  const listeners = new EventTarget();
  const pendingViews = new Map();
  let propertyLoading=0,loadingWasInert=false;
  const SC = window.SC = {
    get state() { return state; },
    get propertyId() { return HR.active; },
    get registry() { return HR; },
    get currentView() { return view; },
    get view() { return view; },
    get ui() { return ui; },
    get navigation() { return NAV; },
    reportRange(date = state.reportDate) { return weekRange(date); },
    isPropertySwitching(){return propertyLoading>0;},
    assertProperty(expectedPropertyId = HR.active) { if(propertyLoading)throw Error('This hotel is still loading. Wait before editing its records.'); if(SC.transactions?.isBusy?.())throw Error('A linked sales update is saving. Wait for it to finish.'); if (expectedPropertyId !== HR.active) throw Error('Hotel changed. Reopen this operation in its original hotel.'); if (SC.storage?.isRestoring?.()) throw Error('Wait for backup restore to finish.'); },
    escape: h,
    uid,
    toast,
    render() { render(); listeners.dispatchEvent(new Event('render')); },
    navigate(id) { if (!TITLES[id]) return; view = id; location.hash = id; document.body.classList.remove('menu-open'); SC.render(); },
    go(id) { SC.navigate(id); },
    modal(html) { return xModal(html); },
    closeModal() { xModalClose(); },
    download(blob, name) { downloadBlob(blob, name); },
    parseWorkbook(buffer) { return XL.read(buffer); },
    installLocalIntake(fn) { xIngest = async (files,from) => {
      const list=Array.from(files||[]);
      if(view==='needDates'&&SC.needDates?.receiveFile&&list.length===1){try{return await SC.needDates.receiveFile(list[0]);}catch(error){toast(error.message);return;}}
      if(view==='dealPackage'&&SC.dealPackage?.open&&list.length===1&&/\.(txt|md)$/i.test(list[0].name||'')){const propertyId=HR.active;if(list[0].size>200000){toast('Use a conversation under 200 KB.');return;}try{const text=await list[0].text();SC.assertProperty(propertyId);if(view!=='dealPackage')throw Error('The workspace changed. Drop the conversation again.');return await SC.dealPackage.open(text,{propertyId,sourceName:list[0].name});}catch(error){toast(error.message);return;}}
      if(view==='captureStation' && SC.salesImport?.receiveFiles)return SC.salesImport.receiveFiles(list);
      if(view==='contracts'&&SC.contractImport?.reviewTranscript&&list.length===1&&/\.(txt|md)$/i.test(list[0].name||'')){
        const propertyId=HR.active;
        if(list[0].size>200000){toast('Use a transcript file under 200 KB.');return;}
        try{const text=await list[0].text();if(propertyId!==HR.active||view!=='contracts')throw Error('The hotel or view changed. Drop the transcript in its contract again.');return await SC.contractImport.reviewTranscript(text,{propertyId,sourceName:list[0].name});}
        catch(error){toast(error.message);return;}
      }
      return fn(files,{contextView:view,source:from});
    }; },
    configureLocalRoutes() {
      if (XV.intake) { XV.inbox=XV.intake;TITLES.inbox=['Files & Capture','Local documents and reviewed field suggestions']; }
      if (XV.calls) { XV.ai=XV.calls;TITLES.ai=['Call Desk','Local memos and reviewed transcripts']; }
      for (const group of NAV) group[1]=group[1].filter(([id])=>!['inbox','ai'].includes(id));
    },
    setState(value) { state = value; migrate(); xMigrate(); applyTheme(); },
    setRegistry(value) { HR = value; try { localStorage.setItem(HREG,JSON.stringify(HR)); } catch {} },
    async switchProperty(id) { if(SC.transactions?.isBusy?.()||SC.storage?.isRestoring?.())throw Error('Wait for the current save or restore before changing hotels.'); await xSwitch(id); listeners.dispatchEvent(new Event('propertychange')); },
    save() { save(); },
    async createProperty(meta) {
      SC.assertProperty(HR.active);
      if (!meta?.name?.trim()) throw new Error('Enter a hotel name.');
      if (SC.storage) { SC.storage.capture(); await SC.storage.flush(); }
      clearTimeout(xSaveT); xWriteLocal();
      const id = 'h' + uid();
      const fresh = blankHotel(meta);
      HR.list.push({id,name:meta.name,short:meta.short || meta.name,rooms:Number(meta.rooms)||100});
      HR.active = id; state=fresh; xMigrate(); state._at=Date.now();
      hWrite();xWriteLocal(); applyTheme();
      if(SC.storage) { SC.storage.capture();await SC.storage.flush(); }
      view='home';location.hash='home';SC.render();
      listeners.dispatchEvent(new Event('propertychange')); return id;
    },
    writeLocal() { return xWriteLocal(); },
    installPersistence(storage) {
      SC.storage = storage;
      const previousSave = save;
      save = function () {
        state._at = Date.now();
        try { storage.capture(); } catch (e) { toast('Could not queue save: ' + e.message); }
        previousSave();
      };
      const previousWrite = xWriteLocal;
      SC.prepareAtomic = () => { clearTimeout(xSaveT);clearTimeout(saveTimer); };
      SC.mirrorAtomic = () => previousWrite();
      xWriteLocal = function () {
        const result = previousWrite();
        try { storage.capture(); } catch (e) { toast('Could not queue save: ' + e.message); }
        return result;
      };
      const previousSwitch = xSwitch;
      let switchGeneration=0;
      xSwitch = async function(id) {
        if(SC.transactions?.isBusy?.())throw Error('A linked sales update is saving. Wait before changing hotels.');
        const generation=++switchGeneration;
        if (id === HR.active) return;
        if(!HR.list.some(property=>property.id===id))throw Error('This hotel is no longer available.');
        if(propertyLoading++===0){loadingWasInert=document.body.inert;document.body.inert=true;}
        try {
        storage.capture(); await storage.flush();
        if(generation!==switchGeneration)return;
        await previousSwitch(id);
        if(generation!==switchGeneration||HR.active!==id)return;
        const latest = await storage.loadProperty(id);
        if(generation!==switchGeneration||HR.active!==id)return;
        if (latest) SC.setState(latest);
        SC.render(); listeners.dispatchEvent(new Event('propertychange'));
        } finally {propertyLoading--;if(!propertyLoading){document.body.inert=loadingWasInert;SC.render();}}
      };
      const previousLoad = loadState;
      loadState = function () { previousLoad(); };
      listeners.dispatchEvent(new Event('storage'));
    },
    registerView(id, title, subtitle, fn, icon = 'report') {
      if (!/^[a-zA-Z][a-zA-Z0-9]{1,40}$/.test(id)) throw new Error('Invalid workspace ID');
      TITLES[id] = [title, subtitle];
      let group = NAV.find(([name]) => name === 'Workspace');
      if (!group) { group = ['Workspace', []]; NAV.splice(1, 0, group); }
      if (!group[1].some(([key]) => key === id)) group[1].push([id,title,icon]);
      XV[id] = () => {
        const result = fn();
        if (!result || typeof result.then !== 'function') return result || '';
        const targetProperty = HR.active;
        const token = {}; pendingViews.set(id,token);
        result.then(html => {
          if (pendingViews.get(id) === token && view === id && HR.active === targetProperty) document.getElementById('view').innerHTML = html;
        }).catch(error => { if (view === id) document.getElementById('view').textContent = 'Could not load workspace: ' + error.message; });
        return '<div class="card sc-loading" role="status">Opening local workspace…</div>';
      };
    },
    on(event, fn) { listeners.addEventListener(event, fn); return () => listeners.removeEventListener(event, fn); },
    emit(event) { listeners.dispatchEvent(new Event(event)); },
    hasActiveJobs() { return !!(propertyLoading || SC.intakeBusy?.() || SC.workspaceBusy?.() || SC.legacyFileBusy || SC.salesImport?.isBusy?.() || SC.salesReport?.isBusy?.() || SC.transactions?.isBusy?.() || SC.dealPackage?.isBusy?.() || SC.needDates?.isBusy?.() || SC.repeatBusiness?.isBusy?.()); },
    async migrateLegacyFiles(db) {
      const oldGet=rmGet, oldPut=rmPut;
      for (const snapshot of await db.snapshots.toArray()) {
        const groups=snapshot.state?.rm?.groups || {};
        for (const group of Object.values(groups)) for (const file of group.files || []) {
          const id='legacy:'+snapshot.id+':'+file.id;
          if (await db.files.get(id)) continue;
          const blob=await oldGet(file.id).catch(()=>null);
          if (!(blob instanceof Blob)) continue;
          const bytes=await crypto.subtle.digest('SHA-256',await blob.arrayBuffer());
          const hash=Array.from(new Uint8Array(bytes),b=>b.toString(16).padStart(2,'0')).join('');
          await db.files.put({id,legacyId:file.id,propertyId:snapshot.id,name:file.name||'Attached contract',type:blob.type||'application/octet-stream',mime:blob.type||'application/octet-stream',size:blob.size,blob,hash,createdAt:new Date().toISOString(),status:'attachment',coverage:'Original revenue-meeting attachment; stored locally and included in encrypted backup.'});
        }
      }
      rmPut=async function(id,blob) {
        if(id==='ks.handle')return oldPut(id,blob);
        if(!(blob instanceof Blob))throw new Error('Choose a valid attachment.');
        if(blob.size>25*1024*1024)throw new Error('Attachments are limited to 25 MB.');
        const propertyId=HR.active;SC.legacyFileBusy=true;
        try {
          const bytes=await crypto.subtle.digest('SHA-256',await blob.arrayBuffer());
          const hash=Array.from(new Uint8Array(bytes),b=>b.toString(16).padStart(2,'0')).join('');
          await db.transaction('rw',db.files,async()=>{
            const total=(await db.files.toArray()).reduce((sum,file)=>sum+(file.size||0),0);
            if(total+blob.size>500*1024*1024)throw new Error('Attachment storage limit reached. Save a backup and remove unneeded originals.');
            await db.files.put({id:'legacy:'+propertyId+':'+id,legacyId:id,propertyId,name:blob.name||'Attached contract',type:blob.type||'application/octet-stream',size:blob.size,blob,hash,createdAt:new Date().toISOString(),status:'attachment',coverage:'Original revenue-meeting attachment.'});
          });
        } finally {SC.legacyFileBusy=false;}
      };
      rmGet=async function(id) {
        if(id==='ks.handle')return oldGet(id);
        const file=await db.files.get('legacy:'+HR.active+':'+id);
        return file?.blob;
      };
    },
    commitActivity(draft, expectedPropertyId = HR.active) {
      SC.assertProperty(expectedPropertyId);
      const activity = {
        id: uid(), date: draft.date || todayISO(), type: draft.type || 'prospecting',
        account: String(draft.account || ''), contact: String(draft.contact || ''),
        segment: String(draft.segment || ''), outcome: String(draft.outcome || ''),
        notes: String(draft.notes || ''), followUp: draft.followUp || '', done: false,
        ts: new Date().toISOString(), sourceId: draft.sourceId || '', source: draft.source || null, localDraftId: draft.localDraftId || ''
      };
      state.activities.push(activity); save(); return activity;
    },
    commitPlannedTask(draft, expectedPropertyId = HR.active) {
      SC.assertProperty(expectedPropertyId);
      if (!draft.account || !draft.due || !/^\d{4}-\d{2}-\d{2}$/.test(draft.due)) throw new Error('Choose an account and follow-up date.');
      const task={account:String(draft.account),contact:String(draft.contact||''),due:draft.due,notes:String(draft.notes||''),nextStep:String(draft.nextStep||''),outreach:String(draft.outreach||''),type:String(draft.type||'followup'),source:structuredClone(draft.source||null),sourceId:String(draft.sourceId||''),localDraftId:String(draft.localDraftId||''),id:uid(),propertyId:HR.active,createdAt:new Date().toISOString(),done:false};
      state.plannedTasks=state.plannedTasks || [];state.plannedTasks.push(task);save();return task;
    },
    completePlannedTask(id,details={},expectedPropertyId = HR.active) {
      SC.assertProperty(expectedPropertyId);
      const task=(state.plannedTasks||[]).find(task=>task.id===id && !task.done);
      if(!task)throw new Error('This follow-up is no longer pending.');
      if(!String(details.notes||details.outcome||'').trim())throw new Error('Describe what actually happened before logging completed work.');
      const activity=SC.commitActivity({type:'followup',account:task.account,contact:task.contact,date:details.date||todayISO(),notes:details.notes||details.outcome,outcome:details.outcome||'',source:task.source,sourceId:task.sourceId,localDraftId:task.localDraftId});
      task.done=true;task.completedAt=new Date().toISOString();task.activityId=activity.id;save();return activity;
    },
    commitAccount(draft, expectedPropertyId = HR.active) { SC.assertProperty(expectedPropertyId); const value = xAcctUpsert(draft); save(); return value; },
    commitRfp(draft, expectedPropertyId = HR.active) { SC.assertProperty(expectedPropertyId); const value = {...structuredClone(draft),id:uid(),name:draft.name || draft.account || 'New inquiry',receivedDate:draft.receivedDate||draft.date||todayISO()}; state.rfps.push(value);save();return value; },
    commitGroup(draft, expectedPropertyId = HR.active) { SC.assertProperty(expectedPropertyId); const value = {...structuredClone(draft),id:uid(),name:draft.name || draft.account || 'New group',status:draft.status||'Prospect'};state.bookings.push(value);save();return value; }
  };
  addEventListener('hashchange', () => listeners.dispatchEvent(new Event('navigate')));
})();
