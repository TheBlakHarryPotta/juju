/* Contract mutations are applied as one validated draft change, within one hotel. */
(() => {
  const SC = window.SC;
  const panels = [];
  Object.assign(SIGS,{herr:['Classic',"'Allura'",1.2],saint:['Elegant',"'Great Vibes'",1.15],allison:['Modern',"'Caveat'",1],dafoe:['Bold',"'Caveat'",1]});
  let courtesyRenderer = null;
  const unsafe = new Set(['__proto__','prototype','constructor']);
  const termKeys = ['taxes','bookingBilling','hold','cutoffCancellation','hotelResponsibilities','acceptance','governingLaw'];
  const clone = x => structuredClone(x);
  function safeObject(x,depth=0) {
    if(depth>20)throw Error('Contract data is nested too deeply.');
    if(!x||typeof x!=='object')return;
    for(const key of Object.keys(x)){if(unsafe.has(key))throw Error('Unsafe contract field.');safeObject(x[key],depth+1);}
  }
  function validDate(s){if(typeof s!=='string'||!/^\d{4}-\d{2}-\d{2}$/.test(s))return false;const d=new Date(s+'T12:00:00Z');return Number.isFinite(d.valueOf())&&d.toISOString().slice(0,10)===s;}
  function isSigned(c){return c.status==='Signed'||c.data.signed;}
  function requireDraft(c){SC.assertProperty(SC.propertyId);if(!c)throw Error('Open or create a contract draft first.');if(isSigned(c))throw Error('This contract is signed. Make a draft copy before changing it.');if(SC.storage?.isRestoring?.())throw Error('Wait for backup restore to finish.');}
  function approvalBasis(c){const D=clone(c.data);delete D.layout;delete D.signed;if(D.courtesyTerms)delete D.courtesyTerms.reviewed;return JSON.stringify({data:D,hotel:kSettings(),salesName:state.settings.preparedBy||''});}
  function invalidateReview(c){if(c?.data?.courtesyTerms?.reviewed&&(!c.courtesyApprovalBasis||c.courtesyApprovalBasis!==approvalBasis(c)))c.data.courtesyTerms.reviewed=false;}
  function snapshot(c){invalidateReview(c);return c?{...clone(c),propertyId:SC.propertyId}:null;}
  function validate(D,type,changes){
    const dateKeys=type==='group'?['arrive','depart','contractDate','cutoffDate','optionDate']:['start','end','contractDate'];
    for(const k of dateKeys)if(D[k]&&!validDate(D[k]))throw Error('Enter a complete valid date for '+k+'.');
    const start=type==='group'?D.arrive:D.start,end=type==='group'?D.depart:D.end;
    if(start&&end&&(type==='group'?end<=start:end<start))throw Error('Departure or agreement end must be after the start date.');
    if(type==='group') {
      const dates=start&&end?kNights(start,end):[];
      if(start&&end&&(Date.parse(end)-Date.parse(start))/86400000>120)throw Error('Use a room block of 120 nights or fewer.');
      if(D.cutoffDate&&D.arrive&&D.cutoffDate>D.arrive)throw Error('Reservation cutoff cannot be after arrival.');
      if(D.optionDate&&D.arrive&&D.optionDate>D.arrive)throw Error('Tentative hold cannot end after arrival.');
      const resolvedCutoff=kCutoff(D),resolvedHold=kOption(D);
      if(resolvedCutoff&&(!validDate(resolvedCutoff)||(D.arrive&&resolvedCutoff>D.arrive)))throw Error('Review the reservation cutoff together with the proposed stay.');
      if(resolvedHold&&(!validDate(resolvedHold)||(D.arrive&&resolvedHold>D.arrive)))throw Error('The existing tentative hold ends after the proposed arrival. Review the hold date together with the stay.');
      if(!Array.isArray(D.rooms)||D.rooms.length>30)throw Error('Use no more than 30 room types.');
      for(const r of D.rooms){
        if(!r||typeof r!=='object'||typeof r.type!=='string'||r.type.length>200)throw Error('Check the room type.');
        if(!Number.isFinite(Number(r.rate))||Number(r.rate)<0||Number(r.rate)>100000)throw Error('Check the nightly rate.');
        if(!r.nights||typeof r.nights!=='object'||Array.isArray(r.nights))throw Error('Review the nightly room allocation.');
        for(const [day,value]of Object.entries(r.nights)){
          if(!validDate(day)||!Number.isInteger(Number(value))||Number(value)<0||Number(value)>10000)throw Error('Room counts must be whole numbers on valid stay dates.');
          if(Number(value)>0&&!dates.includes(day))throw Error('Existing room counts fall outside the proposed stay. Review the room allocation with the new dates.');
        }
      }
    }
  }
  SC.contracts = {
    current(){return snapshot(kCur());},
    makeDraft(type='group'){if(!['group','cna'].includes(type))throw Error('Choose a group or corporate agreement.');const c=type==='cna'?newCna():newGroupContract();c.data.layout='professional';c.status='Draft';c.data.signed=false;return clone(c);},
    validateDraft(c){safeObject(c);if(!c||!['group','cna'].includes(c.type)||c.status!=='Draft'||c.data?.signed)throw Error('Use a new unsigned contract draft.');validate(c.data,c.type,{});return true;},
    create(type='group',layout='professional'){
      if(!['group','cna'].includes(type))throw Error('Choose group or corporate agreement.');
      if(SC.storage?.isRestoring?.())throw Error('Wait for backup restore to finish.');
      const c=type==='cna'?newCna():newGroupContract();c.data.layout=layout==='courtesy-modern'&&type==='group'?'courtesy-modern':'professional';
      kList().push(c);ui.kt=c.id;SC.save();SC.navigate('contracts');return snapshot(c);
    },
    duplicate(id){if(SC.storage?.isRestoring?.())throw Error('Wait for backup restore to finish.');const original=kList().find(c=>c.id===id);if(!original)throw Error('Contract not found.');const c=clone(original);c.id=uid();c.created=c.updated=todayISO();c.status='Draft';c.data.signed=false;c.data.contractDate=todayISO();delete c.data.signedDate;kList().push(c);ui.kt=c.id;SC.save();SC.navigate('contracts');return snapshot(c);},
    registerPanel(fn){panels.push(fn);},
    context(c=kCur()){return {escape:h,settings:clone(kSettings()),salesName:state.settings.preparedBy||'',totals:c?.type==='group'?kTotals(c.data):null,cutoff:c?.type==='group'?kCutoff(c.data):'',option:c?.type==='group'?kOption(c.data):'',contractNumber:c?kNo(c):'',propertyId:SC.propertyId,hotelSignature:c?.data?.signed?sigSpan(state.settings.preparedBy||'',30):'',signedDate:c?.data?.signed?c.data.contractDate:''};},
    panelHTML(){return panels.map(fn=>fn(snapshot(kCur()),SC.contracts.context())||'').join('');},
    setRenderer(fn){courtesyRenderer=fn;},
    renderDocument(c){
      invalidateReview(c);
      if(c.type==='group'&&c.data.layout==='courtesy-modern'&&courtesyRenderer){
        return courtesyRenderer(c,SC.contracts.context(c));
      }
      return c.type==='cna'?kCnaDoc(c):kGroupDoc(c);
    },
    setPresentation({layout,terms,contractId,propertyId}={}){
      const c=kCur();requireDraft(c);
      if((contractId&&c.id!==contractId)||(propertyId&&SC.propertyId!==propertyId))throw Error('The hotel or contract changed. Reopen presentation settings.');
      if(!['professional','classic','courtesy-modern'].includes(layout))throw Error('Choose a contract presentation.');
      if(layout==='courtesy-modern'&&(c.type!=='group'||c.data.attr!=='courtesy'))throw Error('Courtesy presentation requires a courtesy group block. Keep the standard presentation for guaranteed blocks.');
      const D=clone(c.data);D.layout=layout;
      if(terms!==undefined){safeObject(terms);const clean={};for(const k of termKeys){if(terms[k]!==undefined){if(typeof terms[k]!=='string'||terms[k].length>12000)throw Error('Contract terms are too long.');clean[k]=terms[k];}}clean.reviewed=terms.reviewed===true;D.courtesyTerms=clean;}
      c.data=D;if(terms?.reviewed)c.courtesyApprovalBasis=approvalBasis(c);c.updated=todayISO();SC.save();SC.render();return snapshot(c);
    },
    apply({propertyId,contractId,baseDataJSON,baseStatus,changes,source}={}){
      if(propertyId!==SC.propertyId)throw Error('The hotel changed. Reopen the transcript review in its original hotel.');
      const c=kCur();requireDraft(c);
      if(c.id!==contractId)throw Error('The selected contract changed. Review the transcript again.');
      if(JSON.stringify(c.data)!==baseDataJSON||(baseStatus!==undefined&&baseStatus!==c.status))throw Error('This contract changed after review opened. Review the latest values before applying.');
      if(!changes||typeof changes!=='object'||Array.isArray(changes))throw Error('Review the proposed contract fields.');safeObject(changes);safeObject(source);
      const fields=c.type==='group'?['org','event','contact','phone','email','address','arrive','depart','contractDate','groupCode','link','cutoffDate','optionDate','rooms']:['account','contact','phone','email','address','city','title','rateName','start','end','contractDate'];
      const D=clone(c.data);
      for(const [key,value]of Object.entries(changes)){
        if(!fields.includes(key))throw Error('This import cannot change '+key+'. Set commercial terms in the contract editor.');
        if(key==='rooms'){
          if(!Array.isArray(value)||value.length>30)throw Error('Review the room rows.');
          D.rooms=value.map(row=>{
            if(!row||typeof row!=='object'||!row.nights||typeof row.nights!=='object'||Array.isArray(row.nights))throw Error('Review each nightly room count.');
            if(typeof row.type!=='string'||!row.type.trim()||row.type.length>200)throw Error('Review the room type.');
            const numeric=value=>(typeof value==='number'&&Number.isFinite(value))||(typeof value==='string'&&value.trim()!==''&&/^\d+(?:\.\d+)?$/.test(value.trim()));
            if(!numeric(row.rate))throw Error('Enter an explicit nightly rate; missing is not zero.');
            if(row.each!==undefined&&row.each!==''&&(!numeric(row.each)||!Number.isInteger(Number(row.each))))throw Error('Check the per-night room count.');
            const rate=Number(row.rate);const nights={};for(const [day,count]of Object.entries(row.nights)){if(!numeric(count))throw Error('Enter an explicit room count; missing is not zero.');nights[day]=Number(count);}
            return {id:uid(),type:String(row.type||'Run of House'),occ:['Single','Double','Triple','Quad'].includes(row.occ)?row.occ:'Double',rate,each:row.each??'',nights};
          });
        }else{if(typeof value!=='string'||value.length>2000)throw Error('Check the proposed '+key+'.');D[key]=value.trim();}
      }
      if(Object.hasOwn(changes,'cutoffDate'))D.cutoff='custom';if(Object.hasOwn(changes,'optionDate'))D.option='custom';
      validate(D,c.type,changes);
      if(Object.keys(changes).length&&D.courtesyTerms)D.courtesyTerms.reviewed=false;
      // Commit only after every candidate has passed. Provenance is never a printed clause.
      const provenance={at:new Date().toISOString(),sourceId:String(source?.sourceId||'').slice(0,200),sourceName:String(source?.sourceName||'Pasted transcript').slice(0,300),fields:Object.keys(changes),transcriptFileId:String(source?.transcriptFileId||'').slice(0,200),sourceHash:/^[a-f0-9]{64}$/i.test(source?.sourceHash||source?.sha256||'')?(source.sourceHash||source.sha256):''};
      const history=[...(c.captureHistory||[]),{at:provenance.at,before:clone(c.data),source:provenance}].slice(-10);
      c.data=D;c.captureHistory=history;c.updated=todayISO();SC.save();SC.render();return snapshot(c);
    },
    exportCheck(c=kCur()){
      if(!c)return 'Open a contract first.';
      invalidateReview(c);
      try{validate(c.data,c.type,{});}catch(error){return error.message;}
      if(c.data.layout==='courtesy-modern'){
        if(c.type!=='group'||c.data.attr!=='courtesy')return 'This presentation is for courtesy blocks only. Choose the standard presentation for guaranteed blocks.';
        if(!c.data.courtesyTerms?.reviewed)return 'Review and approve the courtesy agreement terms before exporting.';
        if(termKeys.slice(0,6).some(key=>typeof c.data.courtesyTerms[key]!=='string'||!c.data.courtesyTerms[key].trim()))return 'Complete all six courtesy agreement terms before exporting.';
        if(!c.data.arrive||!c.data.depart||!kTotals(c.data).rn)return 'Complete the stay dates and room allocation before exporting.';
      }
      return '';
    }
  };
  const originalView=vContracts;
  vContracts=function(){return '<div class="sc-contract-panels">'+SC.contracts.panelHTML()+'</div>'+originalView();};
  const originalPrint=kPrint;
  kPrint=function(c){const message=SC.contracts.exportCheck(c);if(message){SC.toast(message);return;}return originalPrint(c);};
})();
