/* Keeps the established report layout and all its exports on one data source. */
(() => {
  const SC=window.SC, providers=[];
  const ordinaryPipelineInquiries=pipelineRfps;
  pipelineRfps=function(range){return ordinaryPipelineInquiries(range).filter(b=>!b.dealPackageId&&!b.repeatMemoryId&&b.sourceRef?.kind!=='repeat-business');};
  const baseCounts=activityCounts;
  activityCounts=function(range=weekRange(),withAdj=true){
    const counts=baseCounts(range,withAdj),valid=d=>typeof d==='string'&&/^\d{4}-\d{2}-\d{2}$/.test(d)&&Number.isFinite(Date.parse(d))&&new Date(d+'T00:00:00Z').toISOString().slice(0,10)===d;
    for(const r of SC.state.rfps||[]){if(r.propertyId&&r.propertyId!==SC.propertyId)continue;const date=[r.receivedDate,r.date,r.created].find(valid);if(!date||date<range.start||date>range.end)continue;const logged=(SC.state.activities||[]).some(a=>a.type==='rfp'&&!(a.planned&&!a.done)&&(!a.propertyId||a.propertyId===SC.propertyId)&&(a.source?.rfpId===r.id||a.source?.salesRfpId===r.id||a.sourceId==='rfp:'+r.id||r.sourceId&&a.sourceId===r.sourceId));if(!logged){counts.rfps++;counts.total++;}}
    return counts;
  };
  const baseReport=weeklyReportData;
  SC.salesReport={
    registerProvider(fn){if(typeof fn!=='function')throw Error('Invalid report provider.');providers.push(fn);},
    data(date=SC.state.reportDate){return weeklyReportData(date);},
    exportText(){return weeklyEmailText();}
  };
  weeklyReportData=function(date=SC.state.reportDate){
    const data=baseReport(date),range=weekRange(date);
    const unique=list=>[...new Set(list.map(v=>String(v).trim()).filter(Boolean))];
    for(const fn of providers){const extra=fn(range)||{};data.hl.push(...(extra.hl||[]));data.bt.push(...(extra.bt||[]));}
    data.hl=unique(data.hl);data.bt=unique(data.bt);return data;
  };
  const legacyToDeal=ppToDeal;
  ppToDeal=function(booking){
    if(SC.dealChecker?.importBooking){
      const value=structuredClone(booking),dates=ppNights(booking);
      if(dates.length&&(booking.dealPackageId||ppRooms(booking)>0)){value.nightly=dates.map(date=>{const mix=ppMix(booking,date),source=booking.reviewedPackageRoomRows||[],rooms=booking.legacyRoomTypeReviewNeeded?source.reduce((sum,row)=>sum+num(row.nights?.[date]),0):mix.k+mix.qq+mix.roh;return {date,rooms,compRooms:booking.comp==='none'?0:'',rate:num(booking.rate)||num(booking.adr)};});}
      return SC.dealChecker.importBooking(value);
    }return legacyToDeal(booking);
  };
  const originalPPSync=ppSync;
  ppSync=function(booking){
    if(!booking.dealPackageId){const wasManual=booking.revManual,manualRevenue=booking.rev;originalPPSync(booking);if(wasManual){booking.revManual=true;booking.rev=manualRevenue;}else if(!booking.revManual)booking.rev=num(booking.rn)*num(booking.adr);return;}
    if(booking.arrive)booking.arrival=booking.arrive.slice(0,7);
    if(!booking.legacyRoomTypeReviewNeeded){const rn=ppRooms(booking);if(rn)booking.rn=rn;}
    if(num(booking.rate))booking.adr=num(booking.rate);
    if(!booking.revManual)booking.rev=num(booking.rn)*num(booking.adr);
  };
  const originalPPEditor=ppEditor;
  ppEditor=function(booking){
    if(!booking.legacyRoomTypeReviewNeeded)return originalPPEditor(booking);
    const p=key=>'bookings.#'+booking.id+'.'+key,rows=booking.reviewedPackageRoomRows||[];
    return `<section class="card pp-ed sc-package-allocation-review"><div class="row between"><h3>${SC.escape(booking.name)}</h3><button class="btn" data-act="ppClose">Close</button></div><p>${SC.escape(ppDates(booking))} · ${num(booking.rn)} reviewed room nights</p><div class="innovation-evidence"><h4>Review these room types in Contract Maker</h4><p>The Pipeline K / QQ / ROH editor cannot represent every type in this block. The full reviewed allocation is preserved below; no room type has been reclassified or dropped.</p></div><div class="tw"><table><thead><tr><th>Room type</th><th>Occupied dates and counts</th><th>Reviewed rate</th></tr></thead><tbody>${rows.map(row=>`<tr><td>${SC.escape(row.type)}</td><td>${SC.escape(Object.entries(row.nights||{}).map(([date,count])=>date+': '+count).join(' · '))}</td><td>${money(row.rate,2)}</td></tr>`).join('')}</tbody></table></div><div class="form">${fld('Pipeline group rate / weighted ADR',inp(p('rate'),{type:'number'}),'s3')}${fld('Next-step notes',inp(p('notes')),'s6')}</div><p>Pipeline room revenue: ${money(bookingRev(booking),2)}. Original room-type prices remain in the linked contract; review that draft before sending.</p><div class="row wrap">${STATUSES.map(status=>`<button class="chip ${booking.status===status?'on':''}" data-act="ppStatus" data-v="${status}">${SC.escape(status)}</button>`).join('')}<button class="btn" data-act="ppContract">Open contract room block</button><button class="btn" data-act="ppDeal">Check in Group Deal Checker</button></div></section>`;
  };
  const baseWeekly=vWeekly;
  vWeekly=function(){const range=weekRange();return (SC.salesWorkflows?.reportHTML(range)||'')+(SC.salesImport?.reportHTML(range)||'')+baseWeekly();};
  let syncing=false,lastError='';
  function syncSavedSales(){
    if(syncing||SC.isPropertySwitching?.()||!SC.salesWorkflows)return;syncing=true;
    try{SC.salesWorkflows.syncRFPs?.(SC.state.rfps||[]);SC.salesWorkflows.syncCalls?.(SC.state.activities||[]);}
    catch(error){if(error.message!==lastError){lastError=error.message;SC.toast('Saved source needs prospect review: '+error.message);}}
    finally{syncing=false;}
  }
  function manualButtons(){
    const host=document.getElementById('view');if(!host||!SC.salesWorkflows)return;
    const collections={activities:'activity',rfps:'rfp',bookings:'booking',bt:'bt'};
    for(const [collection,kind]of Object.entries(collections)){
      const ids=new Set();
      host.querySelectorAll(`[data-p^="${collection}.#"],[data-coll="${collection}"][data-id]`).forEach(input=>{
        const id=input.dataset.id||input.dataset.p?.slice(collection.length+2).split('.')[0];
        if(!id||ids.has(id))return;const row=input.closest('tr');if(!row)return;ids.add(id);
        if(row.querySelector('[data-sc-report-send]'))return;
        const cell=row.lastElementChild,button=reportButton(kind,id);cell?.append(button);
      });
    }
    host.querySelectorAll('.deal[data-act="ppOpen"]').forEach(card=>{if(!card.querySelector('[data-sc-report-send]'))card.append(reportButton('booking',card.dataset.v));});
    if(!host.querySelector('#sc-report-dedup')){
      const bar=document.createElement('section');bar.className='sc-card sc-report-actions';
      const text=document.createElement('p');text.className='muted';text.textContent='Saved sales work feeds the report automatically. Use a record’s Send to weekly report button to include it explicitly; repeat clicks do not create another activity.';
      const button=document.createElement('button');button.className='btn';button.id='sc-report-dedup';button.textContent='Check for duplicates';button.addEventListener('click',()=>{try{showAllDuplicates();}catch(error){SC.toast(error.message);}});const send=document.createElement('button');send.className='btn';send.textContent='Send this section to weekly report';send.addEventListener('click',()=>openSectionReport(host));bar.append(text,button,send);host.prepend(bar);
    }
  }
  function duplicateGroups(){
    const groups=[];
    const specs=[['Activity',SC.state.activities||[],a=>[a.date,a.type,a.account,a.contact,a.outcome,a.notes]],['RFP',SC.state.rfps||[],a=>[a.solId||a.name,a.receivedDate||a.date||'',a.account]],['Pipeline',SC.state.bookings||[],a=>[a.name,a.account,a.arrive||a.arrival,a.depart]],['BT account',SC.state.bt||[],a=>[a.account]]];
    for(const [kind,rows,fields]of specs){const seen=new Map();for(const row of rows){if(row.propertyId&&row.propertyId!==SC.propertyId)continue;const values=fields(row).map(v=>String(v||'').trim().normalize('NFKC').toLowerCase());if(!values.some(Boolean))continue;const key=JSON.stringify(values);if(seen.has(key)){let group=groups.find(g=>g.kind===kind&&g.key===key);if(!group){group={kind,key,label:row.account||row.name||row.contact||row.date||kind,ids:[seen.get(key)]};groups.push(group);}group.ids.push(row.id);}else seen.set(key,row.id);}}
    return groups;
  }
  function showAllDuplicates(){const groups=duplicateGroups();SC.modal(`<section class="sc-card"><h2>Check for duplicates</h2><p>${groups.length} possible repeated sales records. Shared names can represent separate inquiries; no records were merged or deleted.</p>${groups.map(g=>`<article class="sc-card"><strong>${SC.escape(g.kind)} · ${SC.escape(g.label)}</strong><p>${g.ids.length} matching records. Review the source section before deleting anything.</p></article>`).join('')||'<p>No exact matching sales record groups found.</p>'}<div class="sc-actions"><button class="btn" type="button" data-sc-prospect-duplicates>Check prospect email / phone matches</button><button class="btn" type="button" data-act="xClose">Close</button></div></section>`);document.querySelector('[data-sc-prospect-duplicates]')?.addEventListener('click',()=>{SC.closeModal();SC.salesWorkflows.showDuplicates();});}
    let capturing=false;
  function openSectionReport(host){
    const propertyId=SC.propertyId,title=TITLES[SC.view]?.[0]||'Sales information',copy=host.cloneNode(true);
    copy.querySelectorAll('button,.sc-report-actions,.sales-week-feed,.report-prev,script,style').forEach(el=>el.remove());
    const text=copy.innerText||copy.textContent||'';
    SC.modal(`<section class="sc-card"><h2>Send sales information to weekly report</h2><p>Review the summary and its actual reporting date. This adds a highlight without counting another completed call or tour.</p><form id="sc-section-report-form"><label class="sc-field">Sales summary<textarea name="summary" rows="8" maxlength="8000" required>${SC.escape((title+' — '+text.trim().replace(/\n{3,}/g,'\n\n')).slice(0,8000))}</textarea></label><label class="sc-field">Actual date<input name="date" type="date" value="${todayISO()}" required></label><label><input name="confirmed" type="checkbox" required> I reviewed this summary and date for the selected report week.</label><p role="alert" id="sc-section-report-error"></p><button class="btn pri" type="submit">Send reviewed highlight</button><button class="btn" type="button" data-act="xClose">Cancel</button></form></section>`);
    document.getElementById('sc-section-report-form')?.addEventListener('submit',async event=>{
      event.preventDefault();if(capturing)return;capturing=true;const form=event.currentTarget;
      try{SC.assertProperty(propertyId);const values=new FormData(form),date=String(values.get('date')||''),summary=String(values.get('summary')||'').trim(),range=SC.reportRange();if(!summary||values.get('confirmed')!=='on')throw Error('Review and confirm the summary.');if(!/^\d{4}-\d{2}-\d{2}$/.test(date)||!Number.isFinite(Date.parse(date))||new Date(date+'T00:00:00Z').toISOString().slice(0,10)!==date||date<range.start||date>range.end)throw Error('Choose an actual date inside the selected report week.');
        const digest=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(date+'|'+summary));SC.assertProperty(propertyId);if(!form.isConnected)throw Error('The review was closed. Nothing was added.');if(SC.state.reportDate!==range.end)throw Error('Report week changed. Reopen the summary in its report week.');const key='manual:'+Array.from(new Uint8Array(digest),x=>x.toString(16).padStart(2,'0')).join('');
        SC.state.salesWorkflows=SC.state.salesWorkflows||{prospects:[],tours:[],networking:[],reportPins:[]};const pins=SC.state.salesWorkflows.reportPins;
        if(!pins.some(p=>p.reportEnd===range.end&&p.item.key===key)){pins.push({id:SC.uid(),reportEnd:range.end,item:{key,date,kind:'highlight',summary:date+': '+summary,propertyId,planned:false},createdAt:new Date().toISOString()});SC.save();}
        SC.closeModal();SC.toast('Highlight included once in the weekly report. Activity counts were preserved.');SC.render();
      }catch(error){const el=form.querySelector('[role=alert]');if(el)el.textContent=error.message;}finally{capturing=false;}
    });
  }
  SC.salesReport.isBusy=()=>capturing;
  for(const event of ['propertychange','restore'])SC.on(event,()=>{if(document.getElementById('sc-section-report-form'))SC.closeModal();});
  SC.salesReport.checkDuplicates=duplicateGroups;
  SC.salesReport.showDuplicates=showAllDuplicates;
  function reportButton(kind,id){const button=document.createElement('button');button.type='button';button.className='btn sm sc-report-send';button.dataset.scReportSend=kind;button.textContent='Send to weekly report';button.addEventListener('click',event=>{event.preventDefault();event.stopPropagation();try{SC.salesWorkflows.pinToReport({kind,id,reportEnd:SC.state.reportDate});SC.toast('Included once in the selected weekly report.');SC.render();}catch(error){SC.toast(error.message);}});return button;}
  SC.on('render',()=>{syncSavedSales();manualButtons();});
  const reportHost=document.getElementById('view');let reportFrame=false;
  if(reportHost)new MutationObserver(()=>{if(reportFrame)return;reportFrame=true;requestAnimationFrame(()=>{reportFrame=false;manualButtons();});}).observe(reportHost,{childList:true,subtree:true});
})();
