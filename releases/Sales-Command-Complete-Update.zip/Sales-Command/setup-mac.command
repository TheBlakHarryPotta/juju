#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if [ "$(uname -s)" != Darwin ]; then
  echo "This installer is for macOS. Use tools/setup-speech.sh on Linux."
  exit 1
fi
bash tools/setup-speech.sh
tools/.venv/bin/python tools/download-speech-model.py
echo "Local transcription is installed. Run start-mac.command to open Sales Command."
