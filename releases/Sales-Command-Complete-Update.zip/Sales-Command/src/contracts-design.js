import contractPrintCSS from './contracts.css?inline';

export { contractPrintCSS };

const defaultEscape = value => String(value ?? '').replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[char]));
const numeric = value => Number.isFinite(Number(value)) ? Number(value) : 0;
const dateLabel = (value, weekday = false) => {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(String(value || ''))) return 'To be completed';
  const parsed = new Date(`${value}T12:00:00Z`);
  if (Number.isNaN(parsed.getTime())) return 'To be completed';
  return new Intl.DateTimeFormat('en-US', { ...(weekday ? { weekday: 'long' } : {}), month: 'long', day: 'numeric', year: 'numeric', timeZone: 'UTC' }).format(parsed);
};

const TERM_FIELDS = [
  ['taxes', 'Rates, taxes & fees'], ['bookingBilling', 'Courtesy block, booking & billing'],
  ['hold', 'Tentative hold & confirmation'], ['cutoffCancellation', 'Cutoff, reservation changes & cancellation'],
  ['hotelResponsibilities', 'Hotel responsibilities, governing law & notices'], ['acceptance', 'Acceptance'],
  ['governingLaw', 'Separate governing law clause (optional, if approved)'],
];

function initialTerms(c, ctx) {
  // Reuse renderer defaults so the editable text is exactly what the preview displays.
  const shell = document.createElement('div');
  shell.innerHTML = renderCourtesy({ ...c, data: { ...c.data, courtesyTerms: {} } }, ctx);
  const sections = [...shell.querySelectorAll('.kc-section')];
  const sectionText = number => [...sections[number - 1]?.querySelectorAll(':scope > p') || []].map(p => p.innerText || p.textContent).join('\n\n');
  return { taxes: shell.querySelector('.kc-tax-note')?.textContent || '', bookingBilling: sectionText(3), hold: sectionText(4), cutoffCancellation: sectionText(5), hotelResponsibilities: sectionText(6), acceptance: sectionText(7) };
}

export function renderContractPanel(c, ctx = {}) {
  if (!c || c.type !== 'group') return '';
  const e = ctx.escape || defaultEscape;
  const D = c.data || {};
  const locked = c.status === 'Signed' || D.signed;
  const courtesy = D.layout === 'courtesy-modern';
  if (locked) return '<section class="kstep sc-contract-design"><h4>Document style</h4><p class="small muted">This signed contract keeps its saved layout and terms. Make a draft copy before changing it.</p></section>';
  const defaults = courtesy ? initialTerms(c, ctx) : {};
  const terms = D.courtesyTerms || {};
  return `<section class="kstep sc-contract-design" data-contract-id="${e(c.id)}" data-property-id="${e(ctx.propertyId || '')}"><h4>Document style</h4><label class="field"><span>Agreement layout</span><select data-contract-layout><option value="professional"${courtesy ? '' : ' selected'}>Professional group agreement</option><option value="courtesy-modern"${courtesy ? ' selected' : ''}>Courtesy room block · professional layout</option></select></label><p class="small muted">${courtesy ? 'This is a separate courtesy agreement with its own terms, including guest-paid billing and reservation-confirmation cancellation language. It replaces the standard agreement wording. Review or edit every section for this property before exporting.' : 'The standard group agreement keeps its existing terms. Courtesy layout is available only when attrition is explicitly set to Courtesy block.'}</p>${courtesy ? `<form class="sc-courtesy-terms" data-contract-id="${e(c.id)}"><p class="small muted">No jurisdiction or tax percentages are copied from another hotel. Edit the property-specific responsibilities and approved tax wording before confirming review.</p>${TERM_FIELDS.map(([key, title]) => `<label class="field"><span>${title}</span><textarea name="${key}" rows="${key === 'hotelResponsibilities' ? 6 : 4}" maxlength="12000"${key === 'governingLaw' ? '' : ' required'}>${e(terms[key] || defaults[key] || '')}</textarea></label>`).join('')}<label class="sc-contract-review"><input type="checkbox" name="reviewed"${terms.reviewed ? ' checked' : ''} required><span>I reviewed this property's taxes, booking, billing, cancellation and final terms and approve this draft for export.</span></label><div class="btns"><button type="submit" class="btn pri">Save reviewed courtesy terms</button></div><p class="sc-contract-feedback small" role="status"></p></form>` : ''}</section>`;
}

/** An explicitly selected courtesy agreement. All document fields are plain text. */
export function renderCourtesy(contract, ctx = {}) {
  const e = ctx.escape || defaultEscape;
  const D = contract?.data || {};
  const K = ctx.settings?.k || ctx.settings || {};
  const T = ctx.totals || { nights: [], rows: [], rn: 0, peak: 0 };
  const terms = D.courtesyTerms || {};
  const hotel = K.hotel || 'Hotel name to be completed';
  const group = D.org || D.contact || 'Group name to be completed';
  const sales = ctx.salesName || ctx.preparedBy || '';
  const cutoff = ctx.cutoff || '';
  const option = ctx.option || '';
  const currency = ctx.currency || 'USD';
  const money = value => new Intl.NumberFormat('en-US', { style: 'currency', currency: /^[A-Z]{3}$/.test(currency) ? currency : 'USD' }).format(numeric(value));
  const line = value => value ? e(value) : '<span class="kc-unfilled">To be completed</span>';
  const paragraphs = text => String(text || '').split(/\n\s*\n/).filter(Boolean).map(part => `<p>${e(part).replace(/\n/g, '<br>')}</p>`).join('');
  const contactLine = (...parts) => parts.filter(Boolean).map(e).join(' · ');
  const footer = `<div class="kc-footer"><span>${contactLine(K.addr1, K.addr2)}<br>${contactLine(K.direct, K.salesEmail)}</span><span>${e(ctx.contractNumber || '')}</span></div>`;
  const logo = typeof ctx.logo === 'string' && /^data:image\/(png|jpeg|webp);base64,[a-z0-9+/=]+$/i.test(ctx.logo) ? `<img class="kc-logo" src="${ctx.logo}" alt="${e(hotel)}">` : '';
  const header = `<header class="kc-header"><div class="kc-hotel"><div class="kc-hotel-name">${e(hotel)}</div>${K.location || K.addr2 ? `<div class="kc-hotel-location">${e(K.location || K.addr2)}</div>` : ''}</div>${logo}</header><div class="kc-title-block"><h1>Courtesy room block agreement</h1><p class="kc-subtitle">${e(D.event || group)}${D.arrive ? ` <span aria-hidden="true">|</span> ${e(dateLabel(D.arrive))}${D.depart ? ` – ${e(dateLabel(D.depart))}` : ''}` : ''}</p></div>`;
  const section = (number, title, body, cls = '') => `<section class="kc-section ${cls}"><h2><span>${String(number).padStart(2, '0')}</span>${e(title)}</h2>${body}</section>`;
  const needsReview = !terms.reviewed;
  const conflicts = D.attr && D.attr !== 'courtesy';
  const note = needsReview || conflicts ? `<div class="kc-review-note"><strong>Draft for hotel review.</strong> ${conflicts ? 'The selected attrition setting conflicts with a courtesy block. Resolve it before issuing this agreement. ' : ''}${needsReview ? 'Confirm property-specific taxes, booking instructions, cancellation terms and responsibilities before issuing.' : ''}</div>` : '';
  const dates = `<div class="kc-dates">${[['Arrival', dateLabel(D.arrive, true)], ['Departure', dateLabel(D.depart, true)], ['Reservation cutoff', dateLabel(cutoff)], ['Tentative hold expires', dateLabel(option)]].map(([label, value]) => `<div><span>${label}</span><strong>${e(value)}</strong></div>`).join('')}</div><p class="kc-small">Issued ${e(dateLabel(D.contractDate))}. ${numeric(T.nights?.length)} night${T.nights?.length === 1 ? '' : 's'}. All dates and deadlines refer to Hotel local time.</p>`;
  const nights = Array.isArray(T.nights) ? T.nights : [];
  const rows = Array.isArray(T.rows) ? T.rows : [];
  let varies = false;
  const roomRows = rows.map(row => {
    const counts = nights.map(day => numeric(row.nights?.[day]));
    const min = counts.length ? Math.min(...counts) : 0;
    const max = counts.length ? Math.max(...counts) : 0;
    if (min !== max) varies = true;
    return `<tr><td>${e(row.type || 'Room type to be completed')}</td><td>${min === max ? max : `${min}–${max}`}</td><td>${counts.filter(n => n > 0).length}</td><td>${e(money(row.rate))}</td></tr>`;
  }).join('');
  const roomTable = `<table class="kc-room-table"><thead><tr><th scope="col">Room type</th><th scope="col">Rooms / night</th><th scope="col">Nights used</th><th scope="col">Nightly rate</th></tr></thead><tbody>${roomRows || '<tr><td colspan="4">Complete the stay dates and room block before issuing.</td></tr>'}</tbody><tfoot><tr><th scope="row">Total courtesy block</th><td>${numeric(T.peak)} peak</td><td colspan="2">${numeric(T.rn)} room nights total</td></tr></tfoot></table>${varies ? '<p class="kc-small">Nightly room quantities vary. Ranges above are not fixed nightly commitments; the dated schedule below controls room quantities.</p>' + `<table class="kc-room-table kc-nightly"><thead><tr><th scope="col">Stay date</th>${rows.map(row => `<th scope="col">${e(row.type || 'Room type')}</th>`).join('')}</tr></thead><tbody>${nights.map(day => `<tr><td>${e(dateLabel(day))}</td>${rows.map(row => `<td>${numeric(row.nights?.[day])}</td>`).join('')}</tr>`).join('')}</tbody></table>` : ''}`;
  const taxes = terms.taxes || `Rates are in ${currency}, per room, per night, before applicable taxes and fees. Applicable tax rates and fees must be confirmed by Hotel before this agreement is issued. No minimum room-night or revenue guarantee applies to this courtesy block.`;
  const billing = terms.bookingBilling || `The Group is not responsible for unreserved rooms and owes no attrition or group cancellation damages under this courtesy block. Each guest must reserve using the Hotel-provided booking instructions${K.direct ? ` or by calling ${K.direct}` : ''} and identifying ${group}. Each guest is responsible for room charges, taxes and incidentals; no master billing is established by this agreement.`;
  const hold = terms.hold || `Hotel will hold the arrangements tentatively through ${dateLabel(option)}. Group must return the signed agreement by that date. The block becomes definite when both parties sign. Hotel may release the arrangements if Group misses the deadline. Extensions and late acceptance require Hotel's written confirmation and are subject to availability.`;
  const cancellation = terms.cutoffCancellation || `The block and group rate are available through ${dateLabel(cutoff)}. After cutoff, unreserved rooms will be released for general sale; new bookings are subject to availability at prevailing rates. Changes to room counts, room types or stay dates require Hotel's written approval. Release of unused rooms does not cancel confirmed individual reservations.\n\nEach reservation confirmation will state its guarantee requirements, cancellation deadline, and any late-cancellation or no-show charges. Those terms remain in effect if Group cancels the trip or the unused block is released. Group should notify Hotel promptly of a trip cancellation.`;
  // No jurisdiction, tax percentages, relocation promise or force-majeure clause is silently borrowed from another property.
  const responsibilities = terms.hotelResponsibilities || 'Hotel-approved responsibilities, guest conduct, personal property, relocation, force majeure, governing law and notice provisions must be entered and reviewed for this property before issuing this agreement.';
  const acceptance = terms.acceptance || 'By signing below, each representative confirms authority to bind the party represented and accepts this agreement.';
  const extras = (Array.isArray(D.custom) ? D.custom : []).filter(item => item.title || item.text).map(item => `<div class="kc-extra"><h3>${e(item.title || 'Additional terms')}</h3>${paragraphs(item.text)}</div>`).join('');
  const signatures = `<div class="kc-signatures"><div><h3>For Group</h3><strong>${e(group)}</strong><p>${e(D.contact || 'Group representative')}</p><div class="kc-sign-line"></div><span>Signature</span><div class="kc-date-line"></div><span>Date</span></div><div><h3>For Hotel</h3><strong>${e(hotel)}</strong><p>${contactLine(sales, K.title)}</p><div class="kc-sign-line">${D.signed === true ? (ctx.hotelSignature || '') : ''}</div><span>Signature</span><div class="kc-date-line">${D.signed === true && ctx.signedDate ? e(dateLabel(ctx.signedDate)) : ''}</div><span>Date</span></div></div>`;
  return `<div class="kdoc kc-document" data-contract-layout="courtesy-modern"><table class="kc-document-flow" role="presentation"><thead class="kc-repeat-head"><tr><td>${header}</td></tr></thead><tbody><tr><td class="kc-page-one">${note}<p class="kc-intro">This Courtesy Room Block Agreement ("Agreement") is between ${e(hotel)} ("Hotel") and ${e(group)} ("Group") for the stay described below.</p><div class="kc-contact-box"><div><h2>Group / event</h2><strong>${e(group)}</strong>${D.event ? `<p>${e(D.event)}</p>` : ''}<p>${line(D.contact)}<br>${line(D.phone)}<br>${line(D.email)}</p></div><div><h2>Hotel sales contact</h2><strong>${contactLine(sales, K.title) || 'To be completed'}</strong><p>${e(hotel)}<br>${K.salesPhone ? `Direct: ${e(K.salesPhone)}<br>` : ''}${K.direct ? `Hotel: ${e(K.direct)}<br>` : ''}${e(K.salesEmail || '')}</p></div></div>${section(1, 'Stay details & important dates', dates)}${section(2, 'Guest room block & rates', roomTable + `<p class="kc-small kc-tax-note">${e(taxes)}</p>`)}${section(3, 'Courtesy block, booking & billing', paragraphs(billing))}<div class="kc-screen-footer">${footer}</div></td></tr><tr class="kc-start-page"><td class="kc-page-two"><div class="kc-screen-header">${header}</div>${section(4, 'Tentative hold & confirmation', paragraphs(hold))}${section(5, 'Cutoff, reservation changes & cancellation', paragraphs(cancellation))}${section(6, 'Hotel terms & responsibilities', paragraphs(responsibilities) + (terms.governingLaw ? `<div class="kc-extra"><h3>Governing law</h3>${paragraphs(terms.governingLaw)}</div>` : '') + extras)}${section(7, 'Acceptance', paragraphs(acceptance) + signatures, 'kc-acceptance')}<div class="kc-screen-footer">${footer}</div></td></tr></tbody><tfoot class="kc-repeat-foot"><tr><td>${footer}</td></tr></tfoot></table></div>`;
}

export function initContractDesign({ SC }) {
  const api = SC?.contracts;
  if (!api) return { renderCourtesy, contractPrintCSS };
  if (typeof api.setCourtesyRenderer === 'function') api.setCourtesyRenderer(renderCourtesy);
  else if (typeof api.setRenderer === 'function') api.setRenderer(renderCourtesy);
  if (typeof api.setPrintCSS === 'function') api.setPrintCSS(contractPrintCSS);
  if (typeof api.registerPanel === 'function') api.registerPanel(() => renderContractPanel(api.current(), typeof api.context === 'function' ? api.context() : { escape: SC.escape, settings: SC.state?.settings?.k || {}, salesName: SC.state?.settings?.preparedBy || '', propertyId: SC.propertyId }));
  const getContract = element => {
    const panel = element.closest('.sc-contract-design');
    const current = api.current();
    const c = current?.contract || current;
    if (!c || panel?.dataset.contractId !== c.id || (panel?.dataset.propertyId && panel.dataset.propertyId !== SC.propertyId) || c.status === 'Signed' || c.data?.signed) throw new Error('Reopen an editable draft before changing its layout or terms.');
    return c;
  };
  document.addEventListener('change', async event => {
    if (!event.target.matches('select[data-contract-layout]')) return;
    const select = event.target;
    try {
      const c = getContract(select);
      await api.setPresentation({ propertyId: SC.propertyId, contractId: c.id, layout: select.value });
      SC.render();
    } catch (error) { SC.toast(error.message || 'The document layout could not be updated.'); SC.render(); }
  });
  document.addEventListener('input', event => {
    const form = event.target.closest('.sc-courtesy-terms');
    if (form && event.target.matches('textarea')) form.elements.reviewed.checked = false;
  });
  document.addEventListener('submit', async event => {
    const form = event.target.closest('.sc-courtesy-terms'); if (!form) return;
    event.preventDefault();
    const submit = form.querySelector('[type="submit"]'); submit.disabled = true;
    try {
      const c = getContract(form);
      const values = new FormData(form);
      const terms = Object.fromEntries(TERM_FIELDS.map(([key]) => [key, String(values.get(key) || '').trim()]));
      if (TERM_FIELDS.some(([key]) => key !== 'governingLaw' && !terms[key])) throw new Error('Complete every required courtesy terms section before approving the draft.');
      terms.reviewed = values.get('reviewed') === 'on';
      if (!terms.reviewed) throw new Error('Review the terms and confirm the approval box before saving.');
      await api.setPresentation({ propertyId: SC.propertyId, contractId: c.id, layout: 'courtesy-modern', terms });
      SC.render(); SC.toast('Courtesy terms saved for this draft. Review the full preview before sending.');
    } catch (error) {
      const feedback = form.querySelector('.sc-contract-feedback'); if (feedback) feedback.textContent = error.message || 'Terms could not be saved.';
    } finally { submit.disabled = false; }
  });
  return { renderCourtesy, contractPrintCSS };
}
