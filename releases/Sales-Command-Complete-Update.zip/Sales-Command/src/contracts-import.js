import {parseContractText,CONTRACT_LABELS} from './contracts-parser.js';
const GROUP=['org','event','contact','phone','email','address','arrive','depart','cutoffDate','optionDate','groupCode'];
const CNA=['account','contact','phone','email','address','city','title','rateName','start','end'];
const DATES=new Set(['arrive','depart','cutoffDate','optionDate','start','end']);
const uid=()=>crypto.randomUUID();
function nightsBetween(arrive,depart){if(!arrive||!depart||depart<=arrive)return [];const list=[];let d=new Date(arrive+'T00:00:00Z');for(let i=0;i<120&&d.toISOString().slice(0,10)<depart;i++){list.push(d.toISOString().slice(0,10));d.setUTCDate(d.getUTCDate()+1);}return list;}
export async function initContractImport({SC,db}) {
  const esc=SC.escape,property=()=>String(SC.propertyId),current=()=>SC.contracts.current();
  let pendingText='',pendingSource={},review=null,reviewSequence=0,busy=false;
  SC.contractImport={reviewTranscript, busy:()=>busy};
  const priorBusy=SC.workspaceBusy;SC.workspaceBusy=()=>busy||!!priorBusy?.();
  const field=(label,html)=>`<label class="sc-field"><span>${esc(label)}</span>${html}</label>`;
  const input=(name,value='',extra='')=>`<input name="${esc(name)}" value="${esc(value)}" ${extra}>`;
  const action=(name,label,extra='')=>`<button type="button" class="btn" data-contract-action="${name}" ${extra}>${label}</button>`;
  function panel(){const c=current();return `<section class="sc-card" id="sc-contract-intake"><h3>Fill a contract from the whole conversation</h3><p class="muted">Paste the entire transcript or inquiry, or drop its text here. Review every proposed field together before anything changes. Files stay on this device.</p>${!c?`<p>Start or open a draft contract first. Your pasted conversation stays here while you choose.</p><div class="sc-actions">${action('create-group','Start group draft')}${action('create-cna','Start corporate draft')}</div>`:c.status==='Signed'||c.data?.signed?`<p class="sc-badge">This contract is signed. Make a draft copy to review imported changes.</p>${action('duplicate','Make draft copy')}`:`<p class="muted">Target: ${esc(c.type==='group'?(c.data.event||c.data.org||'Untitled group'):(c.data.account||'Untitled corporate agreement'))}. Existing entries stay as they are unless you explicitly select replacement values.</p>`}<label class="sc-field"><span>Full transcript, email or inquiry</span><textarea id="sc-contract-text" rows="6" maxlength="200000" placeholder="Paste the full conversation here. For example: Company: Acme. Arrival: June 4, 2027. Departure: June 6, 2027…">${esc(pendingText)}</textarea></label><div class="sc-actions">${action('review','Review all proposed fields')}${action('choose-text','Choose text file')}<input id="sc-contract-file" type="file" accept=".txt,.md,text/plain,text/markdown" hidden></div><p class="muted">Local extraction works best with stated labels and clear dates. Missing years, conflicting dates, unclear prices and unallocated room counts are flagged instead of guessed. Signed status, taxes, billing and legal clauses are never filled from a transcript.</p></section>`;}
  SC.contracts.registerPanel(panel);
  function snapshot(){const c=current();if(!c)throw Error('Start or open a draft contract, then review this conversation.');if(c.status==='Signed'||c.data?.signed)throw Error('Make a draft copy before changing a signed contract.');return {propertyId:property(),contractId:c.id,type:c.type,baseStatus:c.status,baseDataJSON:JSON.stringify(c.data),data:structuredClone(c.data)};}
  async function reviewTranscript(text,source={}){
    if(SC.storage?.isRestoring?.())throw Error('Wait for backup restore to finish.');
    if(source.propertyId&&String(source.propertyId)!==property())throw Error('Open this transcript in its original hotel before filling a contract.');
    if(typeof text!=='string'||!text.trim())throw Error('Paste or drop the whole conversation first.');if(text.length>200000)throw Error('Use text under 200,000 characters.');
    pendingText=text;pendingSource={...source,propertyId:property()};
    if(!current()||current().status==='Signed'||current().data?.signed){SC.navigate('contracts');SC.render();SC.toast(!current()?'Start or open a draft. Your full transcript is ready here.':'Make a draft copy. Your full transcript is ready here.');return;}
    const target=snapshot();review={...target,id:uid(),text,source:pendingSource,year:'',dateOrder:'',parsed:parseContractText(text,{type:target.type})};renderReview();
  }
  function valueBefore(key){const d=review.data;if(key==='cutoffDate'&&d.cutoff!=='custom'&&d.arrive&&/^\d+$/.test(d.cutoff)){const date=new Date(d.arrive+'T00:00:00Z');date.setUTCDate(date.getUTCDate()-Number(d.cutoff));return date.toISOString().slice(0,10)+' (current relative cutoff)';}if(key==='optionDate'&&d.option!=='custom'&&d.contractDate&&/^\d+$/.test(d.option)){const date=new Date(d.contractDate+'T00:00:00Z');date.setUTCDate(date.getUTCDate()+Number(d.option));return date.toISOString().slice(0,10)+' (current relative hold)';}return d[key]??'';}
  function renderReview(){
    if(!review)return;const allowed=review.type==='group'?GROUP:CNA;
    const candidates=Object.values(review.parsed.fields).filter(c=>allowed.includes(c.field));
    const rows=candidates.map(c=>{const before=valueBefore(c.field),replace=String(before).trim()!=='';return `<article class="sc-card"><label class="sc-field"><span><input type="checkbox" name="use:${esc(c.field)}" ${c.value&&!replace&&!c.needsConfirmation?'checked':''}> ${replace?'Replace existing':'Fill'} ${esc(c.label)}</span></label><p class="muted">Before: ${esc(String(before)||'Empty')}</p>${field('Reviewed value',input('field:'+c.field,c.value,`type="${DATES.has(c.field)?'date':c.field==='email'?'email':c.field==='phone'?'tel':'text'}" maxlength="2000"`))}${c.alternatives.length>1?`<p class="muted">Source alternatives: ${c.alternatives.map(esc).join(' / ')}</p>`:''}${c.issue?`<p class="sc-badge">${esc(c.issue)}</p>`:''}<details><summary>Source evidence</summary>${c.evidence.map(e=>`<p style="white-space:pre-wrap">${esc(e)}</p>`).join('')}</details></article>`;}).join('');
    const roomCards=review.type==='group'?review.parsed.roomRows.map((r,i)=>`<article class="sc-card"><label class="sc-field"><span><input name="room-use:${i}" type="checkbox"> Include reviewed room row ${i+1}</span></label><div class="sc-grid">${field('Room type',input('room-type:'+i,r.type,'maxlength="100"'))}${field('Rooms (not room nights)',input('room-count:'+i,r.quantity,'type="number" min="0" max="10000" step="1"'))}${field('Approved nightly rate',input('room-rate:'+i,r.rate??'','type="number" min="0" max="100000" step="0.01"'))}${field('Occupancy shown on contract',`<select name="room-occ:${i}"><option>Single</option><option selected>Double</option><option>Triple</option><option>Quad</option></select>`)}</div><p class="muted">Source: ${esc(r.evidence)}</p>${r.issue?`<p class="sc-badge">${esc(r.issue)}</p>`:''}<label class="sc-field"><span><input type="checkbox" name="room-repeat:${i}"> I confirm this many rooms are held on every occupied night of the reviewed stay.</span></label><p class="muted">${Object.keys(r.nights).length?'An explicit night was detected below. Verify its count; it must fall within arrival and checkout.':'No nightly block has been inferred. Select the uniform allocation confirmation above, or enter explicit date: count lines below.'}</p>${field('Explicit nightly allocation (YYYY-MM-DD: count, one per line)',`<textarea name="room-nights:${i}" rows="3" placeholder="2027-06-04: 10\n2027-06-05: 10">${esc(Object.entries(r.nights).map(([d,n])=>d+': '+n).join('\n'))}</textarea>`)}</article>`).join(''):'';
    SC.modal(`<section class="sc-card" id="sc-contract-review"><h3>Review the whole contract import</h3><p class="muted">Only checked fields will change. Existing values need explicit replacement selection. Signatures, status, taxes, billing and legal text are excluded.</p><div class="sc-grid">${field('Explicit year for dates that did not state one',input('sc-review-year',review.year,'id="sc-review-year" type="number" min="2000" max="2100" placeholder="Choose a year only if you can confirm it"'))}${field('Numeric date order',`<select id="sc-review-order"><option value="">Leave ambiguous dates unresolved</option><option value="MDY" ${review.dateOrder==='MDY'?'selected':''}>Month / day / year</option><option value="DMY" ${review.dateOrder==='DMY'?'selected':''}>Day / month / year</option></select>`)}</div>${action('reparse','Re-read with my date choices')}<p class="muted">Re-reading resets the review edits below; it never changes the contract.</p>${review.parsed.warnings.map(w=>`<p class="sc-badge">${esc(w)}</p>`).join('')}<form id="sc-contract-review-form"><div class="sc-grid">${rows||'<p>No supported header fields were safely identified. Add clear labels to the source or enter the details in Contract Maker.</p>'}</div>${roomCards?`<h4>Room block proposals</h4><p class="muted">Selecting room rows replaces the contract’s whole room table. Your current table has ${review.data.rooms?.length||0} rows. Review dates, counts and nightly rates first.</p>${roomCards}<label class="sc-field"><span><input type="checkbox" name="replaceRooms"> I explicitly approve replacing the existing room table with my checked room rows.</span></label>`:''}<label class="sc-field"><span><input name="confirmed" type="checkbox" required> I reviewed the checked changes, before/after values, dates and any room allocations.</span></label><div class="sc-actions"><button class="btn pri" type="submit">Apply reviewed fields together</button>${action('close','Cancel')}</div><p id="sc-contract-review-error" role="alert" aria-live="polite"></p></form></section>`);
  }
  function readChanges(form){
    const changes=Object.create(null),allowed=review.type==='group'?GROUP:CNA;
    for(const key of allowed){if(!form.elements.namedItem('use:'+key)?.checked)continue;const value=form.elements.namedItem('field:'+key)?.value?.trim();if(!value)throw Error('Enter the reviewed value for '+CONTRACT_LABELS[key]+', or leave it unchecked.');changes[key]=value;}
    const data={...review.data,...changes};
    const arrive=data.arrive,depart=data.depart;
    if(review.type==='group'&&(changes.arrive||changes.depart)&&(!arrive||!depart||depart<=arrive))throw Error('Confirm both arrival and checkout. Checkout must be after arrival.');
    if(review.type==='cna'&&(changes.start||changes.end)&&(!data.start||!data.end||data.end<=data.start))throw Error('Confirm both agreement dates. End must be after start.');
    if((changes.arrive||changes.depart)&&review.data.rooms?.some(r=>Object.values(r.nights||{}).some(n=>Number(n)>0))&&!form.elements.replaceRooms?.checked)throw Error('This draft has an allocated room block. Explicitly review and replace its room table when changing stay dates, or update the dates and block together in Contract Maker.');
    const roomRows=[];
    for(const [i,row]of review.parsed.roomRows.entries()){
      if(!form.elements.namedItem('room-use:'+i)?.checked)continue;
      const type=form.elements.namedItem('room-type:'+i).value.trim(),quantity=Number(form.elements.namedItem('room-count:'+i).value),rawRate=form.elements.namedItem('room-rate:'+i).value,rate=Number(rawRate);
      if(!type||!Number.isInteger(quantity)||quantity<0||quantity>10000||rawRate===''||!Number.isFinite(rate)||rate<0||rate>100000)throw Error('Review room type, whole room count and approved rate in room row '+(i+1)+'.');
      const dates=nightsBetween(arrive,depart);if(!dates.length||dates.length>119)throw Error('A room block needs reviewed arrival and checkout dates for a stay under 120 nights.');
      const nights=Object.create(null),repeat=form.elements.namedItem('room-repeat:'+i).checked,explicit=form.elements.namedItem('room-nights:'+i).value.trim();
      if(repeat&&explicit)throw Error('Room row '+(i+1)+': use either the each-night confirmation or explicit nightly lines, not both.');
      if(repeat)for(const d of dates)nights[d]=quantity;
      else {
        if(!explicit)throw Error('Room row '+(i+1)+': confirm the count repeats each night or enter the exact nightly allocation. Room-night totals cannot be spread automatically.');
        for(const line of explicit.split(/\n+/)){const m=line.trim().match(/^(\d{4}-\d{2}-\d{2})\s*:\s*(\d{1,5})$/);if(!m||!dates.includes(m[1]))throw Error('Every nightly line needs a valid occupied date within arrival and checkout, followed by its count.');if(Object.hasOwn(nights,m[1]))throw Error('A nightly date is repeated in room row '+(i+1)+'.');const n=Number(m[2]);if(n>10000)throw Error('Nightly room count is too large.');nights[m[1]]=n;}
        if(dates.some(d=>!Object.hasOwn(nights,d)))throw Error('Enter every occupied night in room row '+(i+1)+', including an explicit zero where no rooms are held. Missing nights are not assumed zero.');
      }
      roomRows.push({id:uid(),type,occ:form.elements.namedItem('room-occ:'+i).value,rate,each:repeat?quantity:'',nights});
    }
    if(roomRows.length){if(!form.elements.replaceRooms?.checked)throw Error('Explicitly approve replacing the room table before importing room rows.');changes.rooms=roomRows;}
    else if(form.elements.replaceRooms?.checked)throw Error('Check at least one reviewed room row before replacing the room table.');
    if(!Object.keys(changes).length)throw Error('Select at least one reviewed field to apply.');
    return changes;
  }
  async function apply(form){
    if(!review)throw Error('Open a fresh review first.');if(!form.reportValidity())return;
    if(!form.elements.confirmed.checked)throw Error('Confirm you reviewed the selected changes.');
    if(SC.storage?.isRestoring?.())throw Error('Wait for backup restore to finish.');
    const captured=review;
    if(captured.propertyId!==property())throw Error('Hotel changed. Reopen the review in the correct hotel.');
    const now=current();if(!now||now.id!==captured.contractId||now.status!==captured.baseStatus||JSON.stringify(now.data)!==captured.baseDataJSON)throw Error('The target contract changed. Cancel this review and re-read the transcript against its latest version.');
    const changes=readChanges(form),bytes=new TextEncoder().encode(captured.text),hash=[...new Uint8Array(await crypto.subtle.digest('SHA-256',bytes))].map(b=>b.toString(16).padStart(2,'0')).join('');
    let sourceId=captured.source.sourceId||null;
    if(sourceId){const file=await db.files.get(sourceId);if(!file||file.propertyId!==captured.propertyId)throw Error('The source transcript is not available in this hotel. Reopen its original source.');}
    // Keep the whole text as local provenance, not in printed contract clauses or notes.
    const textId=await db.transaction('rw',db.files,async()=>{
      const files=await db.files.toArray(),existing=files.find(f=>f.propertyId===captured.propertyId&&f.hash===hash);if(existing)return existing.id;
      if(files.reduce((sum,f)=>sum+(f.size||0),0)+bytes.length>500*1024*1024)throw Error('The 500 MB local attachment budget is full. Export a backup and manage old originals before importing.');
      const id=uid();await db.files.add({id,propertyId:captured.propertyId,hash,name:'Contract conversation '+new Date().toISOString().slice(0,10)+'.txt',type:'text/plain',size:bytes.length,blob:new Blob([captured.text],{type:'text/plain'}),createdAt:new Date().toISOString(),status:'attachment',contextView:'contracts',coverage:'Whole user-provided conversation retained locally as contract import evidence. No legal text was generated.'});return id;
    });
    if(review!==captured)throw Error('The review changed while saving its source. Reopen the current review before applying.');
    const source={id:captured.id,kind:'contract-transcript',sourceId,transcriptFileId:textId,sourceName:captured.source.sourceName||'Pasted contract conversation',sha256:hash,sourceHash:hash,parser:'local-contract-parser-1',reviewedAt:new Date().toISOString(),fields:Object.keys(changes),explicitYear:captured.year||null,numericDateOrder:captured.dateOrder||null};
    await SC.contracts.apply({propertyId:captured.propertyId,contractId:captured.contractId,baseDataJSON:captured.baseDataJSON,baseStatus:captured.baseStatus,changes,source});
    review=null;SC.closeModal();SC.render();SC.toast('Reviewed fields applied together. Legal clauses and signing state were preserved.');
  }
  async function act(trigger){
    const name=trigger.dataset.contractAction;
    if(name==='review'){pendingText=document.querySelector('#sc-contract-text')?.value||pendingText;await reviewTranscript(pendingText,pendingSource);}
    if(name==='create-group'||name==='create-cna'){pendingText=document.querySelector('#sc-contract-text')?.value||pendingText;SC.contracts.create(name==='create-cna'?'cna':'group');SC.render();}
    if(name==='duplicate'){pendingText=document.querySelector('#sc-contract-text')?.value||pendingText;const c=current();if(c)SC.contracts.duplicate(c.id);SC.render();}
    if(name==='choose-text')document.querySelector('#sc-contract-file')?.click();
    if(name==='close'){review=null;SC.closeModal();}
    if(name==='reparse'){
      if(!review)return;const year=document.querySelector('#sc-review-year').value,dateOrder=document.querySelector('#sc-review-order').value;if(year&&(!/^20\d{2}$/.test(year)||Number(year)>2100))throw Error('Choose a year between 2000 and 2100.');review.year=year;review.dateOrder=dateOrder;review.parsed=parseContractText(review.text,{type:review.type,year:year?Number(year):undefined,dateOrder});renderReview();
    }
  }
  function error(e){const message=e?.message||String(e),node=document.querySelector('#sc-contract-review-error');if(node)node.textContent=message;SC.toast(message);}
  document.addEventListener('click',event=>{
    const trigger=event.target.closest('[data-contract-action]');if(!trigger)return;event.preventDefault();event.stopPropagation();if(busy||SC.storage?.isRestoring?.()){error(Error('Wait for the current local operation to finish.'));return;}busy=true;trigger.disabled=true;Promise.resolve().then(()=>act(trigger)).catch(error).finally(()=>{busy=false;trigger.disabled=false;});
  },true);
  document.addEventListener('submit',event=>{const form=event.target;if(form.id!=='sc-contract-review-form')return;event.preventDefault();event.stopPropagation();if(busy)return;busy=true;const button=form.querySelector('[type=submit]');button.disabled=true;void apply(form).catch(error).finally(()=>{busy=false;button.disabled=false;});},true);
  document.addEventListener('input',e=>{if(e.target.id==='sc-contract-text'){pendingText=e.target.value;pendingSource={propertyId:property(),sourceName:'Pasted conversation'};}});
  document.addEventListener('change',event=>{if(event.target.id!=='sc-contract-file'||!event.target.files?.[0])return;if(busy||SC.storage?.isRestoring?.()){error(Error('Wait for the current local operation or backup restore to finish.'));return;}const file=event.target.files[0],p=property();if(file.size>200000){error(Error('Choose a text transcript under 200 KB.'));return;}busy=true;void file.text().then(text=>{if(property()!==p)throw Error('Hotel changed. Reopen the text file in the correct hotel.');pendingText=text;pendingSource={propertyId:p,sourceName:file.name};SC.render();return reviewTranscript(text,pendingSource);}).catch(error).finally(()=>{busy=false;});});
  const isContractDrop = target => !!target.closest('#sc-contract-intake')||SC.currentView==='contracts'||SC.view==='contracts';
  document.addEventListener('dragover',event=>{if(isContractDrop(event.target)&&[...(event.dataTransfer?.types||[])].some(t=>t==='text/plain'||t==='Files')){event.preventDefault();}},true);
  document.addEventListener('drop',event=>{
    if(!isContractDrop(event.target)||!event.dataTransfer)return;
    const text=event.dataTransfer.getData('text/plain'),file=event.dataTransfer.files?.[0];
    if(!text&&!(file&&(/\.(txt|md)$/i.test(file.name)||file.type==='text/plain')))return;
    event.preventDefault();event.stopImmediatePropagation();if(busy||SC.storage?.isRestoring?.()){error(Error('Wait for the current local operation to finish.'));return;}
    const metadata=event.dataTransfer.getData('application/x-sales-command-transcript');
    if(metadata){let origin;try{origin=JSON.parse(metadata);}catch{error(Error('This transcript has invalid origin metadata. Reopen it from Call Desk.'));return;}if(!origin||String(origin.propertyId)!==property()){error(Error('This transcript belongs to another hotel. Open its original hotel before importing.'));return;}}
    const p=property();busy=true;
    void Promise.resolve().then(async()=>{if(file&&file.size>200000)throw Error('Choose a text transcript under 200 KB.');const body=text||await file.text();if(property()!==p)throw Error('Hotel changed. Drop the transcript into its correct hotel.');return reviewTranscript(body,{propertyId:p,sourceName:file?.name||'Dropped conversation text'});}).catch(error).finally(()=>{busy=false;});
  },true);
  SC.on?.('propertychange',()=>{reviewSequence++;pendingText='';pendingSource={};review=null;SC.closeModal();});
  SC.on?.('restore',()=>{reviewSequence++;pendingText='';pendingSource={};review=null;});
  return SC.contractImport;
}
