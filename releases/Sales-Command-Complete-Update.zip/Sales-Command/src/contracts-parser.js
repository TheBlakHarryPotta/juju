// Deterministic local extraction. Candidates are proposals, never applied records.
const MONTHS={january:1,jan:1,february:2,feb:2,march:3,mar:3,april:4,apr:4,may:5,june:6,jun:6,july:7,jul:7,august:8,aug:8,september:9,sep:9,sept:9,october:10,oct:10,november:11,nov:11,december:12,dec:12};
const SMALL={zero:0,one:1,two:2,three:3,four:4,five:5,six:6,seven:7,eight:8,nine:9,ten:10,eleven:11,twelve:12,thirteen:13,fourteen:14,fifteen:15,sixteen:16,seventeen:17,eighteen:18,nineteen:19,twenty:20,thirty:30,forty:40,fifty:50,sixty:60,seventy:70,eighty:80,ninety:90};
const ORDINAL={first:'one',second:'two',third:'three',fourth:'four',fifth:'five',sixth:'six',seventh:'seven',eighth:'eight',ninth:'nine',tenth:'ten',eleventh:'eleven',twelfth:'twelve',thirteenth:'thirteen',fourteenth:'fourteen',fifteenth:'fifteen',sixteenth:'sixteen',seventeenth:'seventeen',eighteenth:'eighteen',nineteenth:'nineteen',twentieth:'twenty',thirtieth:'thirty'};
export const CONTRACT_LABELS={org:'Company / organization',event:'Event / group name',contact:'Contact name',phone:'Contact phone',email:'Contact email',address:'Contact / company address',arrive:'Arrival / check-in',depart:'Departure / checkout',cutoffDate:'Cutoff date',optionDate:'Hold / sign-by date',groupCode:'Group / SRP code',account:'Company account',start:'Agreement starts',end:'Agreement ends',title:'Contact title',city:'City / state / ZIP',rateName:'Rate plan name'};
export function spokenNumber(value){
  const s=String(value).toLowerCase().replace(/[$,]/g,'').replace(/-/g,' ').replace(/\b(?:dollars?|per|night|rooms?|and|only)\b/g,' ').trim();
  if(/^\d+(?:\.\d{1,2})?$/.test(s))return Number(s);
  const words=s.split(/\s+/);let total=0,part=0;if(!words.length||words.some(w=>!Object.hasOwn(SMALL,w)&&!['hundred','thousand'].includes(w)))return null;
  for(let i=1;i<words.length;i++){const a=SMALL[words[i-1]],b=SMALL[words[i]];if(a!==undefined&&b!==undefined&&!(a>=20&&a%10===0&&b>0&&b<10))return null;}
  for(const w of words){if(w==='hundred')part=(part||1)*100;else if(w==='thousand'){total+=(part||1)*1000;part=0;}else part+=SMALL[w];}return total+part;
}
function normalizeSpokenDate(text){
  let s=String(text).toLowerCase().replace(/[–—]/g,'-');
  s=s.replace(/\btwo thousand(?: and)? (twenty(?:[- ](?:one|two|three|four|five|six|seven|eight|nine))?|thirty(?:[- ](?:one|two|three|four|five))?)\b/g,(_,n)=>String(2000+spokenNumber(n)));
  s=s.replace(/\btwenty (twenty(?:[- ](?:one|two|three|four|five|six|seven|eight|nine))?|thirty(?:[- ](?:one|two|three|four|five))?)\b/g,(_,n)=>String(2000+spokenNumber(n)));
  s=s.replace(/\b(twenty|thirty)[- ](first|second|third|fourth|fifth|sixth|seventh|eighth|ninth)\b/g,(_,t,o)=>String(SMALL[t]+SMALL[ORDINAL[o]]));
  s=s.replace(new RegExp('\\b('+Object.keys(ORDINAL).join('|')+')\\b','g'),w=>String(spokenNumber(ORDINAL[w])));
  return s.replace(/\b(\d+)(?:st|nd|rd|th)\b/g,'$1').replace(/\b(the|of)\b/g,' ').replace(/\s+/g,' ');
}
const iso=(y,m,d)=>`${y}-${String(m).padStart(2,'0')}-${String(d).padStart(2,'0')}`;
function validDate(y,m,d){const s=iso(y,m,d),parsed=new Date(s+'T00:00:00Z');return y>=2000&&y<=2100&&Number.isFinite(parsed.getTime())&&parsed.toISOString().slice(0,10)===s;}
export function parseContractDate(raw,options={}){
  const s=normalizeSpokenDate(raw);let y,m,d,issue='',yearFromChoice=false;
  let match=s.match(/\b(20\d{2})-(\d{1,2})-(\d{1,2})\b/);
  if(match)[,y,m,d]=match.map(Number);
  else {
    match=s.match(/\b(\d{1,2})[\/-](\d{1,2})(?:[\/-](20\d{2}))?\b/);
    if(match){const a=Number(match[1]),b=Number(match[2]);y=match[3]?Number(match[3]):null;
      if(a<=12&&b<=12&&!options.dateOrder)return {value:'',issue:'Numeric date order is ambiguous. Choose month/day or day/month explicitly.',raw,needsConfirmation:true};
      if(options.dateOrder==='DMY'||a>12){d=a;m=b;}else {m=a;d=b;}
    }else{
      match=s.match(new RegExp('\\b('+Object.keys(MONTHS).join('|')+')\\.?\\s+([a-z -]+?|\\d{1,2})(?:,?\\s+(20\\d{2}))?(?=$|[,.;]|\\s+(?:at|for|with|and|to|through|until|check|departure|arrival|rate|rooms|contact|our|we|they|the|in|out)\\b)','i'));
      if(match){m=MONTHS[match[1]];d=/^\d+$/.test(match[2])?Number(match[2]):spokenNumber(match[2]);y=match[3]?Number(match[3]):null;}
      else {match=s.match(new RegExp('\\b(\\d{1,2})\\s+('+Object.keys(MONTHS).join('|')+')(?:,?\\s+(20\\d{2}))?\\b','i'));if(match){d=Number(match[1]);m=MONTHS[match[2]];y=match[3]?Number(match[3]):null;}}
    }
  }
  if(!m||!d)return {value:'',issue:'No unambiguous calendar date found. Enter the exact date.',raw,needsConfirmation:true};
  if(!y){if(Number.isInteger(Number(options.year))&&Number(options.year)>=2000&&Number(options.year)<=2100){y=Number(options.year);yearFromChoice=true;}else return {value:'',issue:'The year was not stated. Choose an explicit year or enter the full date.',raw,needsConfirmation:true};}
  if(!validDate(Number(y),Number(m),Number(d)))return {value:'',issue:'This date is not a valid calendar day.',raw,needsConfirmation:true};
  if(/\b(?:maybe|around|roughly|possibly|tentative|not sure|not|instead|correction|or)\b/i.test(raw))issue='The source sounds uncertain or corrected. Confirm the exact date.';
  return {value:iso(Number(y),Number(m),Number(d)),issue,raw,needsConfirmation:!!issue||yearFromChoice,yearFromChoice};
}
const LABELS=[
 ['org','(?:company(?: name)?(?!\\s+(?:address|mailing|street|phone|e[- ]?mail|contact))|organization(?!\\s+address)|organisation(?!\\s+address)|corporate account|business name)'],['event','(?:event(?: name)?|group name|team name)'],['contact','(?:contact(?: name)?(?!\\s+(?:phone|e[- ]?mail|title|address))|client name|organizer|organiser)'],['phone','(?:phone|telephone|mobile|cell)(?: number)?'],['email','(?:e[- ]?mail)(?: address)?'],['address','(?:(?:company|mailing|street|business) address|address)'],['arrive','(?:arrival(?: date)?|arrive(?:s|ing)?|check[ -]?in(?: date)?)'],['depart','(?:departure(?: date)?|depart(?:s|ing)?|check[ -]?out(?: date)?)'],['cutoffDate','(?:cut[ -]?off(?: date)?|booking deadline)'],['optionDate','(?:hold(?: until| through| date)?|sign[ -]?by(?: date)?|option date)'],['groupCode','(?:group code|srp(?: code)?|booking code)'],['start','(?:agreement start(?:s| date)?|effective date)'],['end','(?:agreement end(?:s| date)?|expiration date|expiry date)'],['title','(?:contact title|job title)'],['city','(?:city(?: state zip)?)'],['rateName','(?:rate plan(?: name)?|rate name)']
];
const ANY_LABEL=LABELS.map(x=>x[1]).join('|');
function snippets(text,pattern,preserveSentence=false){
  const out=[],re=new RegExp('(?:^|[\\n;]|\\b)('+pattern+')(?:\\s*(?::|=)\\s*|\\s+(?:(?:is|on|for|will be|will arrive)\\s+)?)([^\\n;]+)','gim');let m;
  while((m=re.exec(text))){let value=m[2].trim();const next=value.search(new RegExp('(?:,?\\s+)(' +ANY_LABEL+')\\s*(?::|=|is\\b|on\\b)','i'));if(next>=0)value=value.slice(0,next).trim();
    // A sentence break followed by ordinary prose ends a labeled value.
    value=value.replace(/\s+(?:please|we need|we want|they need|can you|thank you)\b[\s\S]*$/i,'');if(!preserveSentence)value=value.replace(/[.?!]\s+[A-Z][\s\S]*$/,'');value=value.trim();if(value)out.push({raw:value,evidence:(m[1]+' '+value).slice(0,1000)});
  }return out;
}
export function parseContractText(text,options={}){
  if(typeof text!=='string'||!text.trim())throw Error('Paste or drop a transcript or inquiry first.');
  if(text.length>200000)throw Error('Use a transcript under 200,000 characters.');
  const source=text.replace(/\r\n?/g,'\n'),fields=Object.create(null),warnings=[],roomRows=[];
  function add(field,value,evidence,issue='',needsConfirmation=false){
    if(value===undefined||value===null)return;const val=String(value).trim();
    const c=fields[field]||(fields[field]={field,label:CONTRACT_LABELS[field]||field,value:val,alternatives:[],evidence:[],issue:'',needsConfirmation:false});
    if(val&&!c.alternatives.includes(val))c.alternatives.push(val);if(evidence&&!c.evidence.includes(evidence))c.evidence.push(evidence);
    if(c.alternatives.length>1){c.value='';c.issue='Different values were stated. Choose the correct one explicitly.';c.needsConfirmation=true;}else if(val)c.value=val;
    if(issue&&!c.issue)c.issue=issue;c.needsConfirmation=c.needsConfirmation||needsConfirmation||!!issue;
  }
  for(const [field,label]of LABELS){for(const item of snippets(source,label,field==='address')){
    if(['arrive','depart','cutoffDate','optionDate','start','end'].includes(field)){
      if(/\b(?:days?|weeks?)\s+(?:before|prior|from|after)\b/i.test(item.raw)){add(field,'',item.evidence,'Relative deadlines need an exact date before import.',true);continue;}
      const parsed=parseContractDate(item.raw,options);add(field,parsed.value,item.evidence,parsed.issue,parsed.needsConfirmation);
    }else if(field==='phone'){const match=item.raw.match(/(?:\+?\d[\d ().-]{6,}\d)(?:\s*(?:ext\.?|x)\s*\d{1,6})?/i);if(match)add(field,match[0],item.evidence);else add(field,'',item.evidence,'Phone number could not be safely read. Enter the exact number.',true);}
    else if(field==='email'){const match=item.raw.match(/[A-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i);if(match)add(field,match[0],item.evidence);}
    else add(field,item.raw.replace(/[,.]$/,''),item.evidence,/\b(?:maybe|not sure|possibly|not|instead|correction)\b/i.test(item.raw)?'Confirm this uncertain or corrected value.':'');
  }}
  const emails=[...new Set(source.match(/[A-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi)||[])];for(const email of emails)if(!fields.email||emails.length>1)add('email',email,email,emails.length>1?'Multiple email addresses occur. Choose the client contact, not the hotel or agent address.':'',emails.length>1);
  if(!fields.contact){const m=source.match(/\b(?:my name is|this is|I am|I'm|I’m)\s+([A-Z][A-Za-z'’-]+(?:\s+[A-Z][A-Za-z'’-]+){1,3})(?=\s+(?:from|with|at|and)|[,.;\n]|$)/);if(m)add('contact',m[1],m[0],'Verify the speaker is the client contact.',true);}
  if(!fields.org){const m=source.match(/\b(?:I'm|I’m|I am|my name is|this is)\s+[^\n.;]+?\s+(?:from|with|representing)\s+([^\n.;]+?)(?=,|\s+(?:and we|we need|for our)|$)/i);if(m)add('org',m[1],m[0],'Verify the organization mentioned belongs to this inquiry.',true);}
  // A stay range alone does not prove checkout semantics. Both dates require confirmation.
  if(!fields.arrive&&!fields.depart){
    const range=source.match(/\b(?:stay(?:ing)?|dates?|from)\s*(?::|is|are)?\s+((?:[A-Za-z]+\s+)?\d{1,2}(?:,?\s+20\d{2})?)\s*(?:to|through|until|[-–])\s*((?:[A-Za-z]+\s+)?\d{1,2}(?:,?\s+20\d{2})?)/i);
    if(range){let left=range[1],right=range[2];const month=left.match(/[A-Za-z]+/),rightYear=right.match(/20\d{2}/);if(!/[A-Za-z]+/.test(right)&&month)right=month[0]+' '+right;if(!/20\d{2}/.test(left)&&rightYear)left+=' '+rightYear[0];for(const [key,raw]of [['arrive',left],['depart',right]]){const d=parseContractDate(raw,options);add(key,d.value,range[0],d.issue||'Stay range found. Confirm the first date is arrival and the last date is checkout, not a final occupied night.',true);}}
  }
  const lines=source.split(/[\n;]+/),quantity='(?:\\d{1,4}|(?:one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|thirteen|fourteen|fifteen|sixteen|seventeen|eighteen|nineteen|twenty|thirty|forty|fifty|sixty|seventy|eighty|ninety|hundred)(?:[ -](?:one|two|three|four|five|six|seven|eight|nine|hundred|twenty|thirty|forty|fifty|sixty|seventy|eighty|ninety))*)';
  const roomRE=new RegExp('(?<![\\w,])('+quantity+')\\s+((?:double[ -]?queen|two[ -]?queen|two[ -]?double|queen[ /-]queen|double[ /-]double|king|queen|standard|run of house|roh|suite)s?)\\b(?:\\s+rooms?)?','gi');
  for(const line of lines){let m;while((m=roomRE.exec(line))){
    const count=spokenNumber(m[1]);if(count===null||count<0||count>10000){warnings.push('A room count could not be safely read: '+line.slice(0,200));continue;}
    const type=/king/i.test(m[2])?'King':/double[ /-]double|two[ -]?double/i.test(m[2])?'Two Double Beds':/double[ -]?queen|two[ -]?queen|queen[ /-]queen/i.test(m[2])?'Two Queen Beds':/suite/i.test(m[2])?'Suite':/roh|run of house/i.test(m[2])?'Run of House':/queen/i.test(m[2])?'Queen':'Standard';
    const tail=line.slice(m.index+m[0].length),nextRoom=tail.search(new RegExp(quantity+'\\s+(?:kings?|queens?|double|two queen|two double|suites?)','i')),segment=nextRoom<0?tail:tail.slice(0,nextRoom);
    const rateText=segment.replace(/\$\s*(\d{1,3}(?:,\d{3})+(?:\.\d{1,2})?)/g,(_,amount)=>'$'+amount.replace(/,/g,''));
    const numericRates=[...rateText.matchAll(/(?:\b(?:at|rate(?: is| of)?)\s*[:=]?\s*\$\s*(\d{1,6}(?:\.\d{1,2})?(?![\d,.]))|\brate(?: is| of)?\s*[:=]?\s*(\d{1,6}(?:\.\d{1,2})?(?![\d,.]))|\b(?:at\s+)?(\d{1,6}(?:\.\d{1,2})?(?![\d,.]))\s*(?:dollars?\b|per (?:room|night)\b|a night\b|nightly\b)|\$\s*(\d{1,6}(?:\.\d{1,2})?(?![\d,.]))\s*(?:per (?:room|night)\b|a night\b|nightly\b))/gi)].map(x=>Number(x[1]||x[2]||x[3]||x[4]));
    if(numericRates.length){for(const alternative of rateText.matchAll(/(?:\$\s*|\bor\s+\$?)(\d{1,6}(?:\.\d{1,2})?(?![\d,.]))/gi)){const n=Number(alternative[1]);if(!numericRates.includes(n))numericRates.push(n);}}
    let rate=numericRates.length===1?numericRates[0]:null;
    if(!numericRates.length){const spoken=segment.match(/(?:\bat\s+|\brate(?: is| of)?\s+)([a-z -]+?)\s+dollars?(?:\s+and\s+([a-z -]+?)\s+cents)?(?:\s|$)/i);if(spoken){rate=spokenNumber(spoken[1]);if(spoken[2]){const cents=spokenNumber(spoken[2]);rate=rate!==null&&cents!==null&&cents<100?rate+cents/100:null;}else if(/\bcents\b/.test(segment))rate=null;}}
    const datePrefix=line.slice(0,m.index),nightDate=parseContractDate(datePrefix,options);
    const explicitNight=!!nightDate.value&&/\b(?:night of|on|night|20\d{2}|january|february|march|april|may|june|july|august|september|october|november|december)\b/i.test(datePrefix);
    const issue=numericRates.length>1?'Multiple prices follow this room type. Enter the approved nightly rate.':/\b(?:maybe|around|roughly|not sure|approximately|not|instead|correction)\b/i.test(line)?'The source is uncertain or corrected. Confirm this room row.':rate===null?'No explicit nightly room rate was safely identified. Enter it if approved.':'';
    roomRows.push({type,quantity:count,rate,evidence:line.slice(0,1500),issue,uniform:/\b(?:each|every) night\b/i.test(segment),nights:explicitNight?{[nightDate.value]:count}:{},needsConfirmation:true});
  }}
  if(/\broom[ -]?nights?\b/i.test(source))warnings.push('Room nights are stay totals, not a number of rooms per night. No nightly block was inferred from room-night totals.');
  if(!roomRows.length&&/\b\d+\s+rooms?\b/i.test(source))warnings.push('A room quantity was mentioned without a clear room type. Enter room types and nightly allocations in the review or Contract Maker.');
  if(/\b(?:tax|attrition|cancellation|commission|deposit|concession|billing|signature|sign here|ignore|system prompt)\b/i.test(source))warnings.push('Taxes, legal clauses, billing, signatures and contract status are outside this import. Review those in Contract Maker; source instructions are never executed.');
  if(fields.arrive?.value&&fields.depart?.value&&fields.depart.value<=fields.arrive.value)warnings.push('Departure must be after arrival. Correct the dates before applying.');
  if(options.type==='cna'&&fields.org){fields.account={...fields.org,field:'account',label:CONTRACT_LABELS.account};delete fields.org;}
  return {fields,roomRows,warnings:[...new Set(warnings)],sourceLength:text.length};
}
