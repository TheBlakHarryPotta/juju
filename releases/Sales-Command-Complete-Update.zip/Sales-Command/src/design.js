const MODES = [
  ['daily', 'Daily', 'home'],
  ['revenue', 'Revenue', 'revmeet'],
  ['documents', 'Documents', 'templateLibrary'],
  ['presentation', 'Presentation', 'gm'],
];

/** A progressive visual layer. It never replaces business data or the renderer. */
export function initDesign(SC) {
  if (document.documentElement.dataset.scDesign) return;
  document.documentElement.dataset.scDesign = 'ready';
  let mode = 'daily';
  try { mode = localStorage.getItem('sc.workspaceMode') || mode; } catch {}
  if (!MODES.some(([id]) => id === mode)) mode = 'daily';
  let pending = false;
  const modalFocus = new WeakMap();
  let previousDialog = null;
  let storageMessage = SC.storage?.status?.message || 'Local workspace';
  const navigate = target => {
    if (typeof SC.go === 'function') return SC.go(target);
    if (typeof SC.navigate === 'function') return SC.navigate(target);
    const link = document.querySelector(`.nav[data-go="${target}"]`);
    if (link) link.click();
    else location.hash = target;
  };
  const make = (tag, cls, text) => {
    const el = document.createElement(tag);
    if (cls) el.className = cls;
    if (text) el.textContent = text;
    return el;
  };
  const button = (text, target, primary = false) => {
    const el = make('button', `btn ${primary ? 'pri' : ''}`, text);
    el.type = 'button';
    el.addEventListener('click', () => navigate(target));
    return el;
  };
  const currentRoute = () => SC.currentView || SC.view || document.querySelector('#side .nav.on')?.dataset.go || location.hash.slice(1) || 'home';

  function createWorkbar() {
    const view = document.getElementById('view');
    if (!view || document.getElementById('scWorkbar')) return;
    const bar = make('div', 'sc-workbar'); bar.id = 'scWorkbar';
    const identity = make('div', 'sc-workspace-label');
    const property = make('span', 'sc-eyebrow', SC.state?.settings?.short || SC.state?.settings?.hotel || 'YOUR SALES WORKSPACE');
    property.id = 'scPropertyLabel'; identity.append(property);
    const status = make('span', 'sc-workspace-status', storageMessage);
    status.id = 'scWorkspaceStatus'; status.setAttribute('role', 'status');
    identity.append(status);
    const group = make('div', 'sc-mode-switch');
    group.setAttribute('role', 'group'); group.setAttribute('aria-label', 'Workspace mode');
    MODES.forEach(([id, label, target]) => {
      const el = make('button', 'sc-mode', label); el.type = 'button';
      el.dataset.scMode = id; el.setAttribute('aria-pressed', String(mode === id));
      el.title = `${label} workspace`;
      el.addEventListener('click', () => {
        mode = id;
        try { localStorage.setItem('sc.workspaceMode', mode); } catch {}
        syncMode(); navigate(target);
      });
      group.append(el);
    });
    const exit = make('button', 'btn sc-exit-presentation', 'Exit presentation');
    exit.type = 'button';
    exit.addEventListener('click', () => {
      mode = 'daily'; try { localStorage.setItem('sc.workspaceMode', mode); } catch {}
      syncMode(); navigate('home');
    });
    bar.append(identity, group, exit); view.before(bar);
  }
  function syncMode() {
    document.documentElement.dataset.scMode = mode;
    document.querySelectorAll('[data-sc-mode]').forEach(el => {
      const pressed = String(el.dataset.scMode === mode);
      if (el.getAttribute('aria-pressed') !== pressed) el.setAttribute('aria-pressed', pressed);
    });
  }
  function homeEnhancements(view) {
    if (view.dataset.scRoute !== 'home') return;
    const grid = [...view.children].find(el => el.classList.contains('grid') && el.querySelector('#actForm'));
    if (grid) {
      grid.classList.add('sc-home-grid');
      grid.querySelector(':scope > .hero')?.classList.add('sc-home-greeting');
      grid.querySelector('#actForm')?.closest('.card')?.classList.add('sc-home-quick-log');
      grid.querySelector(':scope > .g6')?.classList.add('sc-home-metrics');
    }
    [...view.children].filter(el => el.classList.contains('x-drop')).forEach(el => el.classList.add('sc-home-import'));
    if (document.getElementById('scToday')) return;
    const today = make('section', 'sc-today sc-card'); today.id = 'scToday';
    today.setAttribute('aria-labelledby', 'scTodayTitle');
    const copy = make('div', 'sc-today-copy');
    copy.append(make('span', 'sc-eyebrow', 'A LITTLE FOCUS. A BIGGER DAY.'));
    const title = make('h2', '', 'Good work starts here.'); title.id = 'scTodayTitle'; copy.append(title);
    copy.append(make('p', 'muted', 'Capture a conversation, follow the next lead, or pick up where you left off.'));
    const actions = make('div', 'sc-actions');
    actions.append(button('Record a memo', 'calls', true), button('Import a file', 'intake'), button('Account radar', 'accountRadar'));
    today.append(copy, actions); view.prepend(today);
  }

  function enhanceDialogs() {
    const dialogs = [...document.querySelectorAll('.x-modal, .x-palette')];
    dialogs.forEach(dialog => {
      if (dialog.dataset.scDialog) return;
      dialog.dataset.scDialog = 'ready'; dialog.setAttribute('role', 'dialog'); dialog.setAttribute('aria-modal', 'true');
      const heading = dialog.querySelector('h2,h3');
      if (heading) {
        if (!heading.id) heading.id = `sc-dialog-title-${++enhanceDialogs.counter}`;
        dialog.setAttribute('aria-labelledby', heading.id);
      } else dialog.setAttribute('aria-label', dialog.classList.contains('x-palette') ? 'Search workspace' : 'Sales Command dialog');
      modalFocus.set(dialog, document.activeElement); previousDialog = dialog;
      dialog.querySelectorAll('[data-act="xClose"], [data-act="xdClose"]').forEach(el => {
        if (!el.getAttribute('aria-label')) el.setAttribute('aria-label', 'Close dialog');
      });
      requestAnimationFrame(() => {
        if (!dialog.isConnected || dialog.contains(document.activeElement)) return;
        const first = dialog.querySelector('input:not([type="hidden"]),textarea,select,button,[tabindex="0"]');
        if (first) first.focus(); else { dialog.tabIndex = -1; dialog.focus(); }
      });
    });
    if (previousDialog && !previousDialog.isConnected) {
      const original = modalFocus.get(previousDialog);
      if (original?.isConnected) original.focus();
      previousDialog = dialogs.at(-1) || null;
    }
  }
  enhanceDialogs.counter = 0;
  function enhance() {
    pending = false;
    createWorkbar(); syncMode();
    const property = document.getElementById('scPropertyLabel');
    const propertyName = SC.state?.settings?.short || SC.state?.settings?.hotel || 'YOUR SALES WORKSPACE';
    if (property && property.textContent !== propertyName) property.textContent = propertyName;
    const view = document.getElementById('view');
    if (view) { const route = currentRoute(); if (view.dataset.scRoute !== route) view.dataset.scRoute = route; homeEnhancements(view); }
    const menu = document.querySelector('.menu-btn');
    if (menu) { menu.setAttribute('aria-label', 'Open navigation'); menu.setAttribute('aria-controls', 'side'); menu.setAttribute('aria-expanded', String(document.getElementById('side')?.classList.contains('open') || false)); }
    document.querySelectorAll('.iconbtn').forEach(el => { if (!el.getAttribute('aria-label') && el.title) el.setAttribute('aria-label', el.title); });
    const toast = document.getElementById('toast'); if (toast && !toast.getAttribute('role')) toast.setAttribute('role', 'status');
    enhanceDialogs();
  }
  const schedule = () => { if (!pending) { pending = true; requestAnimationFrame(enhance); } };
  // Child changes only: our labels/classes never trigger an attribute-observer loop.
  const observer = new MutationObserver(schedule);
  observer.observe(document.body, { childList: true, subtree: true });
  window.addEventListener('hashchange', schedule);
  window.addEventListener('sc-storage-status', event => {
    const detail = event.detail || {};
    storageMessage = detail.message || (detail.state === 'error' ? 'Local save needs attention' : ['pending', 'saving'].includes(detail.state) ? 'Saving on this device…' : detail.state === 'saved' ? 'Saved on this device' : 'Opening local storage');
    const label = document.getElementById('scWorkspaceStatus'); if (label && label.textContent !== storageMessage) label.textContent = storageMessage;
  });
  document.addEventListener('click', event => {
    if (event.target.closest('.menu-btn')) requestAnimationFrame(() => {
      const menu = document.querySelector('.menu-btn'); menu?.setAttribute('aria-expanded', String(document.getElementById('side')?.classList.contains('open') || false));
    });
    if (event.target.closest('#side .nav') && window.matchMedia('(max-width: 820px)').matches) document.getElementById('side')?.classList.remove('open');
  });
  document.addEventListener('keydown', event => {
    const dialog = [...document.querySelectorAll('.x-modal, .x-palette')].at(-1);
    if (event.key === 'Escape') {
      if (dialog) {
        const close = dialog.querySelector('[data-act="xClose"],[data-act="xdClose"],[data-act="xPaletteClose"]');
        if (close) close.click(); else dialog.remove();
        event.preventDefault();
      } else if (document.getElementById('side')?.classList.contains('open')) {
        document.getElementById('side').classList.remove('open'); document.querySelector('.menu-btn')?.focus(); schedule();
      }
    }
    if (event.key !== 'Tab' || !dialog) return;
    const focusable = [...dialog.querySelectorAll('button:not([disabled]),a[href],input:not([disabled]):not([type="hidden"]),select:not([disabled]),textarea:not([disabled]),[tabindex="0"]')].filter(el => el.getClientRects().length);
    if (!focusable.length) { event.preventDefault(); dialog.focus(); return; }
    const first = focusable[0], last = focusable.at(-1);
    if (event.shiftKey && (document.activeElement === first || !dialog.contains(document.activeElement))) { event.preventDefault(); last.focus(); }
    else if (!event.shiftKey && (document.activeElement === last || !dialog.contains(document.activeElement))) { event.preventDefault(); first.focus(); }
  });
  enhance();
}
