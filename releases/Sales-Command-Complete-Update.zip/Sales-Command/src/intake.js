import Uppy from '@uppy/core';
import Dashboard from '@uppy/dashboard';
import '@uppy/core/css/style.min.css';
import '@uppy/dashboard/css/style.min.css';
import { getDocument, GlobalWorkerOptions } from 'pdfjs-dist';
import pdfWorker from 'pdfjs-dist/build/pdf.worker.min.mjs?url';
import mammoth from 'mammoth/mammoth.browser.js';
import { createWorker } from 'tesseract.js';

GlobalWorkerOptions.workerSrc = pdfWorker;
const LIMITS = Object.freeze({ fileBytes: 25 * 1024 * 1024, batchFiles: 10, vaultBytes: 500 * 1024 * 1024, pdfPages: 20, ocrPages: 4, textChars: 200000, zipEntries: 1500, zipExpandedBytes: 80 * 1024 * 1024, imagePixels: 20_000_000, jobMs: 120000 });
const id = () => crypto.randomUUID();
const now = () => new Date().toISOString();
const dateToday = () => { const d=new Date(); return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0'); };
const ext = n => String(n || '').toLowerCase().split('.').pop();
const textExt = new Set(['txt','md','csv','tsv','json','xml','log','ics','eml']);
const audioExt = new Set(['wav','mp3','m4a','ogg','opus','webm','flac','aac']);
const imageExt = new Set(['png','jpg','jpeg','webp','bmp','gif','tif','tiff']);
const isRaster = b => b.length>=12 && ((b[0]===0x89&&b[1]===0x50&&b[2]===0x4e&&b[3]===0x47) || (b[0]===0xff&&b[1]===0xd8&&b[2]===0xff) || String.fromCharCode(...b.subarray(0,6)).startsWith('GIF8') || (b[0]===0x42&&b[1]===0x4d) || (b[0]===0x49&&b[1]===0x49&&b[2]===0x2a&&b[3]===0) || (b[0]===0x4d&&b[1]===0x4d&&b[2]===0&&b[3]===0x2a) || (String.fromCharCode(...b.subarray(0,4))==='RIFF'&&String.fromCharCode(...b.subarray(8,12))==='WEBP'));

// ZIP metadata is checked before handing an Office document to a parser. No archive extraction to disk.
export function inspectZip(buffer) {
  const v = new DataView(buffer); const bytes = new Uint8Array(buffer);
  let end = -1;
  for (let p = Math.max(0, bytes.length - 22); p >= Math.max(0, bytes.length - 65557); p--) if (v.getUint32(p,true) === 0x06054b50) { end = p; break; }
  if (end < 0) throw new Error('The Office ZIP directory is missing. Save a fresh copy and try again.');
  const count = v.getUint16(end + 10,true), offset = v.getUint32(end + 16,true);
  if (count > LIMITS.zipEntries || count === 65535 || offset === 0xffffffff) throw new Error('This archive is too complex for local preview. The original is retained.');
  const entries = []; let p = offset, expanded = 0;
  for (let i=0;i<count;i++) {
    if (p+46>bytes.length || v.getUint32(p,true)!==0x02014b50) throw new Error('Invalid Office ZIP directory.');
    const flags=v.getUint16(p+8,true), size=v.getUint32(p+24,true), nameLen=v.getUint16(p+28,true), extra=v.getUint16(p+30,true), comment=v.getUint16(p+32,true);
    if (flags&1) throw new Error('Encrypted Office files cannot be previewed. Upload an unencrypted copy.');
    if (size===0xffffffff || (expanded+=size)>LIMITS.zipExpandedBytes) throw new Error('Expanded Office content exceeds the safe preview limit.');
    if (p+46+nameLen+extra+comment>bytes.length) throw new Error('Invalid Office ZIP entry.');
    const name=new TextDecoder().decode(bytes.subarray(p+46,p+46+nameLen));
    if (name.split('/').includes('..') || name.startsWith('/')) throw new Error('Unsafe archive entry.');
    entries.push(name); p+=46+nameLen+extra+comment;
  }
  return entries;
}

// Check actual decompressed bytes as well as directory claims before Office parsing.
export async function validateZipPayload(buffer) {
  const bytes=new Uint8Array(buffer),v=new DataView(buffer);let end=-1,total=0;
  for(let p=Math.max(0,bytes.length-22);p>=Math.max(0,bytes.length-65557);p--)if(v.getUint32(p,true)===0x06054b50){end=p;break;}
  let p=v.getUint32(end+16,true);const count=v.getUint16(end+10,true);
  for(let i=0;i<count;i++){
    const method=v.getUint16(p+10,true),compressed=v.getUint32(p+20,true),declared=v.getUint32(p+24,true),nameLen=v.getUint16(p+28,true),extra=v.getUint16(p+30,true),comment=v.getUint16(p+32,true),local=v.getUint32(p+42,true);
    if(local+30>bytes.length||v.getUint32(local,true)!==0x04034b50)throw new Error('Invalid Office ZIP local entry.');
    const start=local+30+v.getUint16(local+26,true)+v.getUint16(local+28,true);
    if(start+compressed>bytes.length)throw new Error('Truncated Office ZIP entry.');
    let actual=0;
    if(method===0){actual=compressed;total+=actual;}
    else if(method===8){
      const reader=new Blob([bytes.subarray(start,start+compressed)]).stream().pipeThrough(new DecompressionStream('deflate-raw')).getReader();
      try{for(;;){const chunk=await reader.read();if(chunk.done)break;actual+=chunk.value.byteLength;total+=chunk.value.byteLength;if(total>LIMITS.zipExpandedBytes||actual>declared){await reader.cancel();throw new Error('Office archive expands beyond its declared or allowed size.');}}}finally{reader.releaseLock();}
    }else throw new Error('Unsupported Office archive compression method. Save a fresh .docx/.xlsx copy.');
    if(actual!==declared||total>LIMITS.zipExpandedBytes)throw new Error('Office archive size mismatch or expansion limit exceeded.');
    p+=46+nameLen+extra+comment;
  }
}

// A small bounded RFC4180-style reader. Formula strings remain strings, never executed.
export function parseDelimited(text, delimiter = ',') {
  const rows=[];let row=[],cell='',quoted=false;
  for(let i=0;i<text.length;i++) {
    const c=text[i];
    if(c==='"') { if(quoted && text[i+1]==='"'){cell+='"';i++;} else if(quoted || cell==='') quoted=!quoted; else cell+=c; }
    else if(!quoted && c===delimiter){row.push(cell);cell='';}
    else if(!quoted && (c==='\n'||c==='\r')) { if(c==='\r'&&text[i+1]==='\n')i++;row.push(cell);rows.push(row);row=[];cell='';if(rows.length>=10000)throw new Error('CSV preview is limited to 10,000 rows. Split the report into smaller files.'); }
    else cell+=c;
  }
  if(quoted)throw new Error('The CSV has an unclosed quoted field. Correct it before importing.');
  if(cell || row.length){row.push(cell);rows.push(row);}
  return rows;
}

export function suggestDraft(text, filename='') {
  const lines=String(text).split(/\r?\n/).map(s=>s.trim()).filter(Boolean);
  const matchLabel = labels => { for (const line of lines) {const m=line.match(new RegExp('^(?:'+labels+')\\s*[:=]\\s*(.{1,200})$','i'));if(m)return {value:m[1],evidence:line};} return {value:'',evidence:''}; };
  const account=matchLabel('company|account|organization|business');
  const contact=matchLabel('contact|contact name|caller');
  const group=matchLabel('group|event|group name');
  const email=String(text).match(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i)?.[0] || '';
  const rooms=String(text).match(/\b(\d{1,4})\s+(?:rooms?|room nights?)\b/i);
  const rate=String(text).match(/\$\s*(\d{1,4}(?:\.\d{1,2})?)\s*(?:per (?:room|night)|\/night|nightly|rate)?/i);
  return {account:account.value,contact:contact.value,group:group.value,email,rooms:rooms?.[1]||'',rate:rate?.[1]||'',notes:text.slice(0,10000),evidence:[account.evidence,contact.evidence,group.evidence,email,rooms?.[0],rate?.[0]].filter(Boolean),filename};
}

export async function initIntake({SC,db}) {
  const h = SC.escape; let files=[],loading=false,worker=null,ocrBusy=false,queue=Promise.resolve(),uppy=null,recorder=null,recordChunks=[],recordStart=0,recordTimer=null,recordProperty=null;
  let helperToken='',lastError='',activeDialog=null,activeJobs=0;const pdfTasks=new WeakMap(),processingTokens=new Map();
  const runJob=async(fn)=>{activeJobs++;try{return await fn();}finally{activeJobs--;}};
  SC.intakeBusy=()=>activeJobs>0||ocrBusy||recorder?.state==='recording';
  let requestRefresh=0,reloadSequence=0;
  function toast(s){SC.toast(s);}
  function refresh(){clearTimeout(requestRefresh);requestRefresh=setTimeout(()=>{if(['intake','calls'].includes(SC.view || location.hash.slice(1)))SC.render();},40);}
  async function reload(){if(loading)return;loading=true;const sequence=++reloadSequence,propertyId=SC.propertyId;try{const found=await db.files.where('propertyId').equals(propertyId).reverse().sortBy('createdAt');if(SC.propertyId===propertyId&&sequence===reloadSequence)files=found;}catch(e){lastError='Local file storage could not be read: '+e.message;}finally{if(sequence===reloadSequence){loading=false;refresh();}}}
  async function getFile(fileId){const f=await db.files.get(fileId);if(!f || f.propertyId!==SC.propertyId)throw new Error('This file belongs to another hotel or is no longer available.');return f;}
  async function update(f,patch){Object.assign(f,patch,{updatedAt:now()});await db.files.put(f);const i=files.findIndex(x=>x.id===f.id);if(i>=0)files[i]=f;refresh();return f;}
  function withTimeout(p,ms=LIMITS.jobMs){let timer;return Promise.race([p,new Promise((_,reject)=>{timer=setTimeout(()=>reject(new Error('Local processing exceeded two minutes. The original is retained; use a smaller file.')),ms);})]).finally(()=>clearTimeout(timer));}

  async function ocr(blob) {
    if(ocrBusy)throw new Error('Another OCR job is running. Try again when it finishes.');ocrBusy=true;
    try {
      if(!worker)worker=await withTimeout(createWorker('eng',1,{workerPath:'/ocr/worker.min.js',langPath:'/ocr',corePath:'/ocr',workerBlobURL:false,gzip:true}));
      const result=await withTimeout(worker.recognize(blob));
      return {text:result.data.text||'',confidence:Math.round(result.data.confidence||0)};
    } catch(e){if(worker)await worker.terminate().catch(()=>{});worker=null;throw new Error('Local OCR failed: '+e.message+' Check that the local OCR assets are installed.');}
    finally{ocrBusy=false;}
  }
  async function pdfOpen(buffer){const task=getDocument({data:buffer,isEvalSupported:false,stopAtErrors:true,useSystemFonts:true,disableFontFace:true,maxImageSize:LIMITS.imagePixels,isOffscreenCanvasSupported:false,cMapUrl:'/pdfjs/cmaps/',cMapPacked:true,standardFontDataUrl:'/pdfjs/standard_fonts/',wasmUrl:'/pdfjs/wasm/'});try{const pdf=await task.promise;pdfTasks.set(pdf,task);return pdf;}catch(e){await task.destroy().catch(()=>{});throw e;}}
  async function pdfClose(pdf){const task=pdfTasks.get(pdf);if(task){pdfTasks.delete(pdf);await task.destroy();}}
  async function pageImage(page){const initial=page.getViewport({scale:1});const scale=Math.min(1.75,1800/Math.max(initial.width,initial.height));const viewport=page.getViewport({scale});const canvas=document.createElement('canvas');canvas.width=Math.ceil(viewport.width);canvas.height=Math.ceil(viewport.height);const ctx=canvas.getContext('2d');await page.render({canvasContext:ctx,viewport}).promise;return await new Promise((resolve,reject)=>canvas.toBlob(b=>b?resolve(b):reject(new Error('PDF page could not be rendered.')),'image/png'));}
  SC.localPdfImages=async(buffer,max=4)=>{const pdf=await pdfOpen(buffer);try{if(pdf.numPages>Math.min(max,LIMITS.ocrPages))throw new Error('This PDF has '+pdf.numPages+' pages. Use File Inbox for explicit page coverage or split it into at most four pages.');const images=[];for(let p=1;p<=pdf.numPages;p++)images.push(await pageImage(await pdf.getPage(p)));return images;}finally{await pdfClose(pdf);}};

  async function extract(f) {
    const token=id();processingTokens.set(f.id,token);try{
    const buffer=await f.blob.arrayBuffer(), bytes=new Uint8Array(buffer), extension=ext(f.name); let text='',coverage='',status='review',kind='attachment',details={};
    if(bytes.length>=5 && String.fromCharCode(...bytes.subarray(0,5))==='%PDF-') {
      kind='pdf';const pdf=await pdfOpen(buffer);const pages=Math.min(pdf.numPages,LIMITS.pdfPages),parts=[];let ocrCount=0;const skippedScans=[];
      try{for(let n=1;n<=pages;n++){const page=await pdf.getPage(n);const content=await page.getTextContent();let pageText=content.items.map(x=>x.str+(x.hasEOL?'\n':' ')).join('');if(pageText.trim().length<15 && ocrCount<LIMITS.ocrPages){const result=await ocr(await pageImage(page));pageText=result.text;ocrCount++;}else if(pageText.trim().length<15){skippedScans.push(n);}parts.push(`[Page ${n}]\n${pageText}`);if(parts.join('\n').length>LIMITS.textChars)break;}text=parts.join('\n\n');coverage=`${parts.length} of ${pdf.numPages} pages inspected; ${ocrCount} pages OCR. ${pdf.numPages>parts.length?'PARTIAL: remaining pages are in the original.':''}`;if(skippedScans.length)coverage+=' PARTIAL: scanned pages '+skippedScans.join(', ')+' were not OCR-read because the four-page OCR limit was reached.';details={pagesInspected:parts.length,totalPages:pdf.numPages,ocrPages:ocrCount,skippedScanPages:skippedScans};}finally{await pdfClose(pdf);}
    } else if(bytes[0]===0x50 && bytes[1]===0x4b) {
      const entries=inspectZip(buffer);await validateZipPayload(buffer);
      if(entries.includes('word/document.xml')){kind='docx';const result=await mammoth.extractRawText({arrayBuffer:buffer});text=result.value;coverage='DOCX plain text; layout, images and tracked-change meaning are not interpreted.';details.warnings=result.messages?.map(m=>m.message).slice(0,10)||[];}
      else if(entries.some(n=>/^xl\//.test(n))){kind=extension==='xlsb'?'xlsb':'xlsx';const book=await SC.parseWorkbook(buffer);const sheets=book.sheets || book;const parts=[];let cellCount=0;for(const [name,cells] of Object.entries(sheets)){const rows=[];for(const [key,value] of Object.entries(cells)){if(++cellCount>50000)throw new Error('Spreadsheet preview exceeds 50,000 cells. Split the workbook.');rows.push(`${key}: ${typeof value==='object'?JSON.stringify(value):String(value)}`);}parts.push(`[Sheet: ${name}]\n${rows.join('\n')}`);}text=parts.join('\n\n');coverage=`${Object.keys(sheets).length} sheets, ${cellCount} cells read locally. Formulas and macros are not executed.`;details={sheetNames:Object.keys(sheets),cells:cellCount};}
      else {status='attachment';coverage='Original ZIP stored. This archive has no supported Office document for extraction.';}
    } else if(isRaster(bytes)) {
      kind='image';const bitmap=await createImageBitmap(f.blob);try{if(bitmap.width*bitmap.height>LIMITS.imagePixels)throw new Error('Image exceeds 20 million pixels. Resize it before OCR.');}finally{bitmap.close();}
      const result=await ocr(f.blob);text=result.text;coverage=`Local OCR, estimated confidence ${result.confidence}%. Review numbers and names against the original.`;details.confidence=result.confidence;
    } else if(String(f.type||f.mime||'').startsWith('audio/') || audioExt.has(extension)){kind='audio';status='transcript-needed';coverage='Audio retained locally. Open Call Desk to transcribe with the local helper or enter a transcript.';}
    else if(textExt.has(extension) || String(f.type||f.mime||'').startsWith('text/') && !['html','htm','svg'].includes(extension)){
      kind=extension; text=new TextDecoder('utf-8',{fatal:true}).decode(buffer);if(extension==='csv'||extension==='tsv'){const rows=parseDelimited(text,extension==='tsv'?'\t':',');details={rows:rows.length,columns:Math.max(0,...rows.map(r=>r.length))};coverage=`${rows.length} rows. Cell values are retained as text; formulas are not executed.`;}else coverage='Plain text extracted locally. Links and markup are not executed.';
    } else {status='attachment';coverage='Original retained as attachment only. Preview/extraction is not supported for this format. Legacy .doc/.xls/.msg, executable content and encrypted files require a supported export.';}
    if(text.length>LIMITS.textChars){text=text.slice(0,LIMITS.textChars);coverage+=' PARTIAL: text preview capped at 200,000 characters.';details.truncated=true;}
    if(!text.trim() && status==='review'){status='attachment';coverage+=' No readable text was found; attach or provide a manual transcript.';}
    if(processingTokens.get(f.id)!==token)throw new Error('This extraction was cancelled after its time limit. Retry with a smaller source.');
    return await update(f,{text,coverage,status,kind,details,error:''});
    }finally{if(processingTokens.get(f.id)===token)processingTokens.delete(f.id);}
  }

  async function storeOne(file,contextView,propertyId){
    if(file.size>LIMITS.fileBytes)throw new Error(`${file.name}: exceeds 25 MB. Split or compress the file.`);
    if(!file.size)throw new Error(`${file.name}: file is empty.`);
    const hash=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',await file.arrayBuffer()))).map(x=>x.toString(16).padStart(2,'0')).join('');
    const f={id:id(),propertyId,hash,name:file.name||'clipboard-file',type:file.type||'application/octet-stream',size:file.size,blob:file,createdAt:now(),updatedAt:now(),text:'',status:'queued',contextView,coverage:'Waiting for local extraction.'};
    const stored=await db.transaction('rw',db.files,async()=>{
      const existing=await db.files.where('hash').equals(hash).filter(row=>row.propertyId===propertyId).first();
      if(existing)return {record:existing,added:false};
      const total=await db.files.toArray();if(total.reduce((n,row)=>n+(row.size||0),0)+file.size>LIMITS.vaultBytes)throw new Error('The 500 MB local attachment budget is full. Export and delete old originals before adding more.');
      await db.files.add(f);return {record:f,added:true};
    });
    if(!stored.added){toast(`${file.name}: already in this hotel’s local inbox.`);return stored.record;}
    if(SC.propertyId===propertyId){files.unshift(f);refresh();}
    try{await update(f,{status:'working'});return await withTimeout(runJob(()=>extract(f)));}catch(e){processingTokens.delete(f.id);return await update(f,{status:'error',error:e.message,coverage:'Original saved. Nothing has been added to your sales records.'});}
  }
  async function intakeFiles(list,opts={}){
    if(SC.storage?.isRestoring?.())throw new Error('Backup restore is running. Wait until it finishes before adding files.');
    const batch=Array.from(list).slice(0,LIMITS.batchFiles);if(Array.from(list).length>LIMITS.batchFiles)toast('Only the first 10 files were queued. Add the rest after these finish.');
    const propertyId=opts.propertyId || SC.propertyId,contextView=opts.contextView || SC.view || location.hash.slice(1)||'home';
    activeJobs+=batch.length;const tasks=batch.map(file=>{const task=queue.then(()=>storeOne(file,contextView,propertyId)).catch(e=>{toast(e.message);return null;}).finally(()=>{activeJobs--;});queue=task.then(()=>{});return task;});
    if(batch.length)toast(`${batch.length} file${batch.length===1?'':'s'} queued locally. Review them in File Inbox.`);
    const result=await Promise.all(tasks);return result.filter(Boolean);
  }
  SC.intakeFiles=intakeFiles;SC.installLocalIntake?.(intakeFiles);SC.extractFile=async file=>{if(SC.storage?.isRestoring?.())throw new Error('Backup restore is running.');return runJob(async()=>extract(typeof file==='string'?await getFile(file):file));};SC.intakeLimits=LIMITS;

  function fileRow(f){return `<article class="sc-card local-file-row" data-file-id="${h(f.id)}"><div class="sc-toolbar"><div><strong>${h(f.name)}</strong><div class="muted local-source-label">${(f.size/1024).toFixed(1)} KB · ${h(f.contextView||'inbox')} · ${h(new Date(f.createdAt).toLocaleString())}</div></div><span class="sc-badge">${h(f.status)}</span></div><p>${h(f.error||f.coverage||'Stored locally')}</p><div class="sc-actions"><button class="btn" data-local-action="review" data-file-id="${h(f.id)}">${f.status==='transcript-needed'?'Add transcript / review':'Review & create draft'}</button><button class="btn" data-local-action="download" data-file-id="${h(f.id)}">Download original</button>${f.status==='error'?`<button class="btn" data-local-action="retry" data-file-id="${h(f.id)}">Retry extraction</button>`:''}<button class="btn ghost danger" data-local-action="delete" data-file-id="${h(f.id)}">Delete local file</button></div></article>`;}
  function storageInfo(){return `<div class="muted">${files.length} files in this hotel · ${(files.reduce((s,f)=>s+f.size,0)/1024/1024).toFixed(1)} MB · Originals stay in this browser. Export a backup before clearing browser data.</div>`;}
  function inbox(){if(!loading && files.some(f=>f.propertyId!==SC.propertyId)){files=[];reload();}return `<section class="sc-page"><div class="sc-card"><h2>Local File Inbox</h2><p>Drop a report, screenshot, contract or recording here or anywhere in the app. Review every proposed change before adding it to your hotel.</p><div class="sc-actions"><button class="btn pri" data-local-action="choose">Choose files</button><button class="btn" data-local-action="refresh">Refresh files</button><button class="btn" data-local-action="persist">Protect browser storage</button><button class="btn" data-go="calls">Open Call Desk</button></div><input hidden id="local-file-input" type="file" multiple><div id="local-uppy" class="local-dropzone"></div><p class="muted">Up to 10 files per batch, 25 MB each. PDF: first 20 pages, OCR for up to 4 scanned pages. Text, CSV, Office, images and audio have different capabilities; other files are attachments only.</p>${storageInfo()}${lastError?`<p role="alert">${h(lastError)}</p>`:''}</div><div class="sc-stack local-file-list">${files.length?files.map(fileRow).join(''):'<div class="sc-card"><p>Your inbox is empty. Originals and extracted text will appear here, scoped to this hotel.</p></div>'}</div></section>`;}
  function calls(){return `<section class="sc-page"><div class="sc-grid"><div class="sc-card"><h2>Call Desk</h2><p>Record your own voice memo or upload a recording. This app does not automatically capture phone, Teams or other app calls.</p><p class="muted">Record only when you have the required permission. Files and transcripts stay local; no cloud transcription is used.</p><div class="sc-actions"><button class="btn pri" data-local-action="record" ${recorder?.state==='recording'?'disabled':''}>Start voice memo</button><button class="btn danger" data-local-action="stop-record" ${recorder?.state==='recording'?'':'disabled'}>Stop & save memo</button><button class="btn" data-local-action="choose-audio">Upload recording</button><button class="btn" data-local-action="manual">Type or paste call notes</button></div><input hidden id="local-audio-input" type="file" accept="audio/*,.m4a,.mp3,.wav,.webm,.ogg,.flac"><p id="local-record-status" class="local-record-status" role="status">${recorder?.state==='recording'?'Recording · '+Math.floor((Date.now()-recordStart)/1000)+' seconds · Stop to save locally.':'Microphone is off.'}</p></div><div class="sc-card"><h3>Local transcription helper</h3><p>The optional helper runs on this computer at <code>http://127.0.0.1:8766</code>. On your Mac, run <code>setup-mac.command</code> once, then <code>start-mac.command</code>. It uses native whisper.cpp. Model files must be downloaded before offline transcription works.</p><label class="sc-field">Local pairing token<input id="local-helper-token" type="password" autocomplete="off" placeholder="Token shown by your local helper" value="${h(helperToken)}"></label><div class="sc-actions"><button class="btn" data-local-action="helper-health">Check local helper</button></div><p class="muted" id="local-helper-status">No recording is sent unless you choose Transcribe locally from its review.</p></div></div><div class="sc-stack">${files.filter(f=>f.kind==='audio'||String(f.type||f.mime||'').startsWith('audio/')||audioExt.has(ext(f.name))).map(fileRow).join('')||'<div class="sc-card">No recordings for this hotel yet.</div>'}</div></section>`;}
  SC.registerView('intake','File Inbox','Local originals, extraction and reviewed drafts',inbox,'up');
  SC.registerView('calls','Call Desk','Voice memos, transcripts and source-linked notes',calls,'mic');

  function closeDialog(){activeDialog?.remove();activeDialog=null;}
  function field(name,label,value='',type='text'){return `<label class="sc-field">${h(label)}<input name="${name}" type="${type}" value="${h(value)}" ${type==='number'?'min="0" step="any"':''}></label>`;}
  async function review(fileId){const f=await getFile(fileId);const d=suggestDraft(f.text||'',f.name);closeDialog();const dialog=document.createElement('dialog');dialog.id='local-review-dialog';dialog.setAttribute('aria-label','Review '+f.name);dialog.className='sc-dialog';dialog.innerHTML=`<form id="local-review-form" class="sc-stack"><div class="sc-toolbar"><h2>Review ${h(f.name)}</h2><button class="btn" type="button" data-local-action="close-review">Close</button></div><p class="muted">${h(f.coverage||'Local source')} · Source hotel: ${h(f.propertyId)}</p>${f.kind==='audio'||audioExt.has(ext(f.name))?'<button type="button" class="btn" data-local-action="transcribe" data-file-id="'+h(f.id)+'">Transcribe locally</button><p id="local-transcribe-status" role="status"></p>':''}<label class="sc-field">Extracted text / editable transcript<textarea id="local-review-text" name="sourceText" rows="9" maxlength="200000">${h(f.text||'')}</textarea></label><p class="muted">Suggestions below come only from labels, emails and numbers found in this text. They are drafts, not verified facts. Fill in missing dates and confirm every value.</p><div class="sc-actions"><button type="button" class="btn" data-local-action="suggest">Refresh suggestions from edited text</button><button type="button" class="btn" data-local-action="save-transcript" data-file-id="${h(f.id)}">Save transcript only</button><button type="button" class="btn pri" data-local-action="deal-package" data-file-id="${h(f.id)}">Build linked Deal Package</button><button type="button" class="btn" data-local-action="contract-transcript" data-file-id="${h(f.id)}">Use whole transcript in Contract Maker</button><button type="button" class="btn" draggable="true" id="local-transcript-drag" data-local-action="copy-transcript" aria-label="Copy or drag the whole transcript">Copy all / drag transcript</button></div><label class="sc-field">Create a reviewed draft for<select name="destination"><option value="activity">Activity Log</option><option value="prospect">Prospect pipeline</option><option value="account">Account</option><option value="rfp">RFP / lead</option><option value="group">Group / pipeline</option></select></label><label class="sc-field">Activity category (used when sending to Activity Log)<select name="activityType">${[['prospecting','Prospecting call'],['existing','Existing account call'],['networking','Networking'],['tour','Site tour'],['rfp','RFP / inquiry'],['other','Other activity / memo']].map(([key,label])=>`<option value="${key}" ${key===((f.contextView==='calls'||f.kind==='audio')?'prospecting':'other')?'selected':''}>${label}</option>`).join('')}</select></label><div class="sc-grid">${field('account','Account / company',d.account)}${field('contact','Contact',d.contact)}${field('email','Email',d.email,'email')}${field('phone','Phone',d.phone||'','tel')}${field('group','Group / event name',d.group)}${field('date','Activity date',dateToday(),'date')}${field('followUp','Follow-up date','','date')}${field('arrival','Arrival','','date')}${field('departure','Departure','','date')}${field('rooms','Rooms (confirm meaning)',d.rooms,'number')}${field('rate','Nightly rate (confirm currency)',d.rate,'number')}</div><label class="sc-field">Notes<textarea name="notes" rows="5" maxlength="20000">${h(d.notes)}</textarea></label><div id="local-evidence" class="sc-card"><strong>Detected evidence</strong><ul>${d.evidence.map(x=>`<li>${h(x)}</li>`).join('')||'<li>No labeled facts detected. Enter fields yourself.</li>'}</ul></div><label><input name="confirmed" type="checkbox" required> I checked these details against the source and want to add this draft to this hotel.</label><p id="local-review-error" role="alert"></p><div class="sc-actions"><button class="btn pri" type="submit">Confirm & add reviewed draft</button><button class="btn" type="button" data-local-action="close-review">Cancel</button></div></form>`;document.body.append(dialog);activeDialog=dialog;dialog.showModal();dialog.addEventListener('cancel',closeDialog);let committing=false;dialog.querySelector('form').addEventListener('submit',async e=>{e.preventDefault();if(committing)return;committing=true;const submit=e.currentTarget.querySelector('[type=submit]');submit.disabled=true;try{await runJob(()=>commitReview(f,e.currentTarget));}catch(err){dialog.querySelector('#local-review-error').textContent=err.message;}finally{committing=false;submit.disabled=false;}});}
  async function commitReview(f,form){if(SC.storage?.isRestoring?.())throw new Error('Backup restore is running. Wait before saving this review.');if(f.propertyId!==SC.propertyId)throw new Error('Hotel changed. Close this review and reopen the file in its hotel.');const values=Object.fromEntries(new FormData(form));if(values.confirmed!=='on')throw new Error('Confirm the details before adding a draft.');const destination=values.destination;if(!['activity','account','rfp','group','prospect'].includes(destination))throw new Error('Select a valid destination.');if(!values.account && !values.contact && !values.group && !values.notes.trim())throw new Error('Add an account, contact, group or note.');if(values.arrival && values.departure && values.departure<=values.arrival)throw new Error('Departure must be after arrival.');if(destination==='prospect'&&!values.account.trim()&&!values.contact.trim())throw new Error('Enter a company or contact name for the prospect.');if(destination==='account'&&!values.account.trim())throw new Error('Enter an account name before creating an account.');if((destination==='group'||destination==='rfp')&&!values.group.trim()&&!values.account.trim()&&!values.contact.trim())throw new Error('Enter an account, group or contact name for this record.');if(!Number.isFinite(Number(values.rooms))||!Number.isFinite(Number(values.rate)))throw new Error('Rooms and rate must be valid numbers.');if(Number(values.rooms)<0||Number(values.rate)<0)throw new Error('Rooms and rate cannot be negative.');
    const source={fileId:f.id,fileHash:f.hash,fileName:f.name,coverage:f.coverage,reviewedAt:now()};const draft={id:id(),propertyId:f.propertyId,type:'reviewed-'+destination,updatedAt:now(),createdAt:now(),data:{...values,sourceText:undefined,confirmed:undefined},source,status:'draft'};
    // The accepted draft is retained in the durable local store before any legacy state is touched.
    await db.records.add(draft);
    if(f.propertyId!==SC.propertyId)throw new Error('Hotel changed while saving the reviewed draft. Nothing was added to the other hotel. Reopen the source hotel to finish.');
    let committed;
    if(destination==='activity')committed=await SC.commitActivity({date:values.date||dateToday(),type:['prospecting','existing','networking','tour','rfp','other'].includes(values.activityType)?values.activityType:'other',account:values.account,contact:values.contact,notes:values.notes,followUp:values.followUp,sourceId:f.id,source,localDraftId:draft.id},f.propertyId);
    if(destination==='account'){if(!values.account.trim())throw new Error('Enter an account name before creating an account.');committed=await SC.commitAccount({name:values.account,notes:values.notes,contacts:values.contact?[{name:values.contact,email:values.email}]:[]});}
    if(destination==='rfp')committed=await SC.commitRfp({name:values.group||values.account||values.contact,account:values.account,contact:values.contact,email:values.email,type:'Other',status:'Invited',due:'',notes:values.notes,phone:values.phone,arrive:values.arrival,depart:values.departure,receivedDate:values.date,source:'Local reviewed file: '+f.name,sourceId:f.id},f.propertyId);
    if(destination==='group')committed=await SC.commitGroup({name:values.group||values.account||values.contact,account:values.account,contact:values.contact,status:'Prospect',statusDate:dateToday(),created:dateToday(),arrival:values.arrival.slice(0,7),arrive:values.arrival,depart:values.departure,rn:0,adr:Number(values.rate)||0,rev:0,revManual:false,notes:values.notes+'\nRoom count mentioned: '+(values.rooms||'not provided')+'. Confirm nightly allocation and room nights in Pipeline.',sourceId:f.id});
    if(destination==='prospect'){SC.salesWorkflows.importProspects([{account:values.account,contact:values.contact,email:values.email,phone:values.phone,arrive:values.arrival,depart:values.departure,nextDate:values.followUp,notes:values.notes,date:values.date,sourceId:'review:'+f.id}],{source:{id:f.id,fileId:f.id,name:f.name,propertyId:f.propertyId}});committed={id:f.id};}
    if(destination==='activity'&&committed&&(f.contextView==='calls'||f.kind==='audio'||audioExt.has(ext(f.name))))SC.salesWorkflows?.recordCall({...values,arrive:values.arrival,depart:values.departure},{source:{id:f.id,fileId:f.id,name:f.name,propertyId:f.propertyId,activityId:committed.id}});
    if(committed){committed.sourceId=f.id;committed.localDraftId=draft.id;SC.save();await db.records.update(draft.id,{status:'committed',committedId:committed.id,updatedAt:now()});}
    await update(f,{text:values.sourceText,status:'reviewed',lastDraftId:draft.id});closeDialog();toast('Reviewed '+destination+' added to '+({activity:'Activity Log',account:'Accounts',rfp:'RFPs & Leads',group:'Pipeline',prospect:'Prospect Pipeline'}[destination])+'. Original remains in File Inbox.');SC.render();}

  async function startRecording(){if(!navigator.mediaDevices?.getUserMedia||!window.MediaRecorder)throw new Error('Voice recording is unavailable in this browser. Upload a recording or type notes.');const stream=await navigator.mediaDevices.getUserMedia({audio:true});try{const options=MediaRecorder.isTypeSupported('audio/webm;codecs=opus')?{mimeType:'audio/webm;codecs=opus'}:MediaRecorder.isTypeSupported('audio/mp4')?{mimeType:'audio/mp4'}:{};recorder=new MediaRecorder(stream,options);recordChunks=[];recordStart=Date.now();recordProperty=SC.propertyId;recorder.ondataavailable=e=>{if(e.data.size)recordChunks.push(e.data);};recorder.onstop=async()=>{clearInterval(recordTimer);stream.getTracks().forEach(t=>t.stop());const blob=new Blob(recordChunks,{type:recorder.mimeType});const extension=recorder.mimeType.includes('mp4')?'m4a':'webm';const file=new File([blob],`Voice memo ${new Date(recordStart).toISOString().replace(/[:.]/g,'-')}.${extension}`,{type:blob.type});recorder=null;recordChunks=[];await intakeFiles([file],{contextView:'calls',propertyId:recordProperty});refresh();};recorder.start(1000);recordTimer=setInterval(()=>{const element=document.getElementById('local-record-status');if(element)element.textContent='Recording · '+Math.floor((Date.now()-recordStart)/1000)+' seconds. Stop to save locally.';if(Date.now()-recordStart>10*60*1000 || recordChunks.reduce((s,b)=>s+b.size,0)>LIMITS.fileBytes-1024*1024){recorder.stop();toast('Recording stopped at the 10-minute / 24 MB limit and saved locally.');}},1000);refresh();}catch(e){stream.getTracks().forEach(t=>t.stop());throw e;}}
  async function helperFetch(path,options={}){const response=await fetch('http://127.0.0.1:8766'+path,{...options,signal:AbortSignal.timeout(path==='/health'?4000:240000),headers:{...(options.headers||{}),'X-Sales-Command-Token':helperToken}});const result=await response.json();if(!response.ok)throw new Error(result.error||'Local helper rejected the request.');return result;}
  async function transcribe(fileId){if(!helperToken)helperToken=document.getElementById('local-helper-token')?.value||'';if(!helperToken)throw new Error('Enter your local helper pairing token in Call Desk first.');const f=await getFile(fileId),targetDialog=activeDialog,targetProperty=SC.propertyId;const status=targetDialog?.querySelector('#local-transcribe-status');if(status)status.textContent='Transcribing on this computer. This can take several minutes.';const result=await helperFetch('/transcribe',{method:'POST',headers:{'Content-Type':'application/octet-stream','X-File-Name':encodeURIComponent(f.name)},body:f.blob});if(!result.text?.trim())throw new Error('No speech was recognized. Type or correct the transcript yourself.');await update(f,{text:result.text,segments:result.segments,status:'review',coverage:'Local whisper.cpp transcript. Verify names, dates, numbers and the ending against the audio.'});if(activeDialog===targetDialog && SC.propertyId===targetProperty && targetDialog?.isConnected){targetDialog.querySelector('#local-review-text').value=result.text;if(status)status.textContent='Local transcript ready. Review it and refresh the field suggestions.';}toast('Transcript saved locally. No sales fields were changed.');}

  document.addEventListener('change',e=>{if(e.target.id==='local-file-input'||e.target.id==='local-audio-input'){const selected=Array.from(e.target.files||[]);e.target.value='';intakeFiles(selected).catch(err=>toast(err.message));}if(e.target.id==='local-helper-token')helperToken=e.target.value;},true);
  document.addEventListener('click',async e=>{const button=e.target.closest('[data-local-action]');if(!button)return;e.preventDefault();e.stopPropagation();const action=button.dataset.localAction,fileId=button.dataset.fileId;let counted=false;try{
    if(SC.storage?.isRestoring?.()&&['retry','delete','save-transcript','manual','record','transcribe'].includes(action))throw new Error('Backup restore is running. Wait until it finishes.');
    if(['retry','delete','save-transcript','manual','record','transcribe'].includes(action)){activeJobs++;counted=true;}
    if(action==='copy-transcript'){
      const text=activeDialog?.querySelector('#local-review-text')?.value||'';
      if(!text.trim())throw new Error('Add a transcript first.');
      try{await navigator.clipboard.writeText(text);toast('Whole transcript copied. Paste it into Contract Maker.');}
      catch{const area=activeDialog.querySelector('#local-review-text');area.focus();area.select();toast('Whole transcript selected. Press Command+C to copy it.');}
    }
    if(action==='deal-package'){
      const dialog=activeDialog,text=dialog?.querySelector('#local-review-text')?.value||'';if(!text.trim())throw new Error('Add a transcript first.');const f=await getFile(fileId);if(dialog!==activeDialog||f.propertyId!==SC.propertyId)throw new Error('Hotel or source changed. Reopen this transcript.');if(!SC.dealPackage?.open)throw new Error('Deal Package is unavailable. Reload the app.');closeDialog();await SC.dealPackage.open(text,{sourceId:f.id,sourceName:f.name,propertyId:f.propertyId});
    }
    if(action==='contract-transcript'){
      const dialog=activeDialog,text=dialog?.querySelector('#local-review-text')?.value||'';
      if(!text.trim())throw new Error('Add a transcript first.');
      const f=await getFile(fileId);
      if(dialog!==activeDialog||f.propertyId!==SC.propertyId)throw new Error('The selected hotel or transcript changed. Reopen its review.');
      if(!SC.contractImport?.reviewTranscript)throw new Error('Contract review is not available. Reload the app.');
      closeDialog();SC.navigate('contracts');SC.contractImport.reviewTranscript(text,{sourceId:f.id,sourceName:f.name,propertyId:f.propertyId});
    }
    if(action==='choose')document.getElementById('local-file-input')?.click();
    if(action==='choose-audio')document.getElementById('local-audio-input')?.click();
    if(action==='refresh')await reload();
    if(action==='persist'){const kept=await navigator.storage?.persist?.();toast(kept?'Persistent browser storage granted. Keep external backups too.':'Browser did not grant persistent storage. Export regular backups.');}
    if(action==='review')await review(fileId);
    if(action==='close-review')closeDialog();
    if(action==='download'){const f=await getFile(fileId);SC.download(f.blob,f.name);}
    if(action==='retry'){const f=await getFile(fileId);queue=queue.then(()=>runJob(()=>extract(f))).catch(err=>update(f,{status:'error',error:err.message}));await queue;}
    if(action==='delete'){if(!window.confirm('Delete this local original and its extracted text? Reviewed drafts are kept.'))return;const f=await getFile(fileId);await db.files.delete(f.id);files=files.filter(x=>x.id!==f.id);refresh();toast('Local file deleted.');}
    if(action==='suggest'){const form=activeDialog?.querySelector('form');const d=suggestDraft(form.elements.sourceText.value);for(const key of ['account','contact','email','group','rooms','rate'])if(d[key])form.elements[key].value=d[key];if(!form.elements.notes.value.trim())form.elements.notes.value=d.notes;form.querySelector('#local-evidence').innerHTML='<strong>Detected evidence</strong><ul>'+d.evidence.map(x=>'<li>'+h(x)+'</li>').join('')+'</ul>';}
    if(action==='save-transcript'){const f=await getFile(fileId);await update(f,{text:activeDialog.querySelector('#local-review-text').value,status:'review',coverage:(f.coverage||'')+' Transcript edited by owner.'});toast('Transcript saved. No sales records changed.');}
    if(action==='manual'){const file=new File([''],`Call notes ${dateToday()}.txt`,{type:'text/plain'});const f={id:id(),propertyId:SC.propertyId,hash:'manual-'+id(),name:file.name,type:file.type,size:0,blob:file,createdAt:now(),text:'',status:'review',kind:'txt',contextView:'calls',coverage:'Manual call notes; no recording or AI extraction.'};await db.files.add(f);files.unshift(f);refresh();await review(f.id);}
    if(action==='record')await runJob(startRecording);
    if(action==='stop-record')recorder?.stop();
    if(action==='helper-health'){helperToken=document.getElementById('local-helper-token').value;const result=await helperFetch('/health');document.getElementById('local-helper-status').textContent=result.ready?(result.modelValidated?'Local whisper.cpp is ready; model '+result.model+'.':'Local engine and model found. The first transcription will validate the model.'):'Helper is running but model is missing. '+(result.message||'See tools/README.md.');}
    if(action==='transcribe'){button.disabled=true;try{await runJob(()=>transcribe(fileId));}finally{button.disabled=false;}}
  }catch(err){const status=activeDialog?.querySelector('#local-transcribe-status')||document.getElementById('local-helper-status');if(status)status.textContent=err.message;toast(err.message);}finally{if(counted)activeJobs--;}},true);
  document.addEventListener('dragstart',event=>{
    if(event.target.id!=='local-transcript-drag'||!activeDialog)return;
    const text=activeDialog.querySelector('#local-review-text')?.value||'';
    event.dataTransfer.setData('text/plain',text);
    event.dataTransfer.setData('application/x-sales-command-transcript',JSON.stringify({propertyId:SC.propertyId}));
    event.dataTransfer.effectAllowed='copy';
  });
  // Capture the transfer before legacy universal-import handlers can invoke host AI.
  document.addEventListener('dragover',e=>{if(Array.from(e.dataTransfer?.types||[]).includes('Files')){e.preventDefault();e.stopImmediatePropagation();e.dataTransfer.dropEffect='copy';}},true);
  document.addEventListener('drop',e=>{const list=Array.from(e.dataTransfer?.files||[]);if(!list.length)return;e.preventDefault();e.stopImmediatePropagation();if(SC.view==='needDates'&&SC.needDates?.receiveFile&&list.length===1){SC.needDates.receiveFile(list[0]).catch(err=>toast(err.message));return;}if(SC.view==='captureStation'&&SC.salesImport?.receiveFiles){SC.salesImport.receiveFiles(list).catch(err=>toast(err.message));return;}intakeFiles(list,{contextView:SC.view||location.hash.slice(1)}).catch(err=>toast(err.message));},true);
  document.addEventListener('paste',e=>{const list=Array.from(e.clipboardData?.files||[]);if(!list.length)return;e.preventDefault();e.stopImmediatePropagation();if(SC.view==='needDates'&&SC.needDates?.receiveFile&&list.length===1){SC.needDates.receiveFile(list[0]).catch(err=>toast(err.message));return;}if(SC.view==='captureStation'&&SC.salesImport?.receiveFiles){SC.salesImport.receiveFiles(list).catch(err=>toast(err.message));return;}intakeFiles(list,{contextView:SC.view||location.hash.slice(1)}).catch(err=>toast(err.message));},true);
  window.addEventListener('beforeunload',e=>{if(recorder?.state==='recording'){e.preventDefault();e.returnValue='A voice memo is recording.';}});
  let previousProperty=SC.propertyId;
  new MutationObserver(()=>{if(previousProperty!==SC.propertyId){previousProperty=SC.propertyId;files=[];closeDialog();reloadSequence++;loading=false;reload();}const mount=document.getElementById('local-uppy');if(mount&&!mount.dataset.mounted){mount.dataset.mounted='1';if(uppy)uppy.destroy();uppy=new Uppy({autoProceed:false,restrictions:{maxFileSize:LIMITS.fileBytes,maxNumberOfFiles:LIMITS.batchFiles}}).use(Dashboard,{inline:true,target:mount,height:260,hideUploadButton:true,proudlyDisplayPoweredByUppy:false,note:'Local processing only. No files are uploaded to a server.'});uppy.on('file-added',file=>{intakeFiles([new File([file.data],file.name,{type:file.type})]).finally(()=>{try{uppy.removeFile(file.id);}catch{}});});uppy.on('restriction-failed',(_,error)=>toast(error.message));}}).observe(document.body,{childList:true,subtree:true});
  SC.on?.('restore',()=>{files=[];closeDialog();reloadSequence++;loading=false;reload();});
  await reload();
  return {reload,intakeFiles};
}
