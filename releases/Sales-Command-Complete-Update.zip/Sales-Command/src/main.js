import '@fontsource/inter/latin-400.css';
import '@fontsource/inter/latin-600.css';
import '@fontsource/inter/latin-700.css';
import '@fontsource/caveat/latin-400.css';
import '@fontsource/allura/latin-400.css';
import '@fontsource/great-vibes/latin-400.css';
import './design.css';
import { initTransactions } from './transactions.js';
import { initStorage } from './storage.js';
import { initWorkspaces } from './workspaces.js';
import { initIntake } from './intake.js';
import { initDesign } from './design.js';
import { initContractDesign } from './contracts-design.js';
import { initContractImport } from './contracts-import.js';
import './contracts.css';
import { initSalesWorkflows } from './sales-workflows.js';
import { initSalesImport } from './sales-import.js';
import { initDealChecker } from './deal-checker.js';
import { initPittsburghDesign } from './pittsburgh-design.js';
import './sales-import.css';
import './sales-workflows.css';
import './deal-checker.css';
import './pittsburgh-design.css';
import { initFollowUps } from './follow-ups.js';
import { initDealPackage } from './deal-package.js';
import { initNeedDateMatchmaker } from './need-date-matchmaker.js';
import { initRepeatBusiness } from './repeat-business.js';
import './deal-package.css';
import './need-date-matchmaker.css';
import './repeat-business.css';
import './innovation-design.css';

const SC = window.SC;
if (!SC) throw new Error('Sales Command could not initialize its application adapter.');
const storage = initStorage(SC);
SC.storage = storage;
SC.ready = (async () => {
  await storage.ready;
  SC.installPersistence(storage);
  initTransactions({ SC });
  await SC.migrateLegacyFiles(storage.db);
  await initWorkspaces({ SC, db: storage.db });
  initContractDesign({ SC });
  await initContractImport({ SC, db: storage.db });
  initSalesWorkflows({ SC, db: storage.db });
  initSalesImport({ SC, db: storage.db });
  initDealChecker({ SC });
  await initIntake({ SC, db: storage.db });
  initDealPackage({ SC, db: storage.db });
  initNeedDateMatchmaker({ SC });
  initRepeatBusiness({ SC, db: storage.db });
  initFollowUps({ SC });
  SC.configureLocalRoutes();
  initSafety();
  initDesign(SC);
  initPittsburghDesign({ SC });
  const requested = location.hash.slice(1);
  SC.navigate(requested || 'home');
  window.dispatchEvent(new Event('sc-ready'));
  return SC;
})().catch(error => {
  console.error('Application startup failed',error);
  const notice = document.createElement('div'); notice.className='sc-startup-error'; notice.setAttribute('role','alert');
  notice.textContent='Sales Command could not open its local workspace: '+error.message+'. Your existing data has not been deleted. Reload, or check browser storage permissions.';
  document.body.prepend(notice);
  throw error;
});

function initSafety() {
  const e = SC.escape;
  let stats = { files:0,records:0,usage:null,persisted:false,lastBackup:'' };
  const update = async () => {
    stats.files = await storage.db.files.where('propertyId').equals(SC.propertyId).count();
    stats.records = await storage.db.records.where('propertyId').equals(SC.propertyId).count();
    stats.usage = await navigator.storage?.estimate?.();
    stats.persisted = await navigator.storage?.persisted?.();
    stats.lastBackup = (await storage.db.settings.get('last-backup'))?.value || '';
    if (SC.view==='deviceSafety') SC.render();
  };
  SC.registerView('deviceSafety','Device & Backups','Your files stay here. Keep a recovery copy.',()=>`<section class="sc-page">
    <div class="card sc-hero"><span class="pill">LOCAL FIRST</span><h2>Your workspace, on this device</h2><p>Files, OCR and records are stored in this browser. There is no automatic cloud sync. A second device has its own workspace until you transfer a backup.</p></div>
    <div class="grid"><article class="card"><h3>Storage health</h3><p id="sc-save-status" role="status">${e(storage.status.message)}</p><p>${stats.files} attachments · ${stats.records} library records at this hotel</p><p>${stats.usage ? `${Math.round((stats.usage.usage||0)/1024/1024)} MB used on this origin` : 'Storage estimate unavailable'}</p><p>${stats.persisted ? 'Browser persistence granted. A backup is still needed.' : 'Browser storage can be cleared. Keep a separate backup.'}</p><button class="btn" id="sc-persist">Request persistent storage</button></article>
    <article class="card"><h3>Encrypted backup</h3><p>Includes all hotels, library records, attachments and saved production. Use a passphrase of at least 12 characters. It cannot be recovered if lost.</p><p>Last backup: ${e(stats.lastBackup ? new Date(stats.lastBackup).toLocaleString() : 'None exported yet')}</p><label class="field"><span>Backup passphrase</span><input id="sc-backup-pass" type="password" minlength="12" autocomplete="new-password"></label><label class="field"><span>Confirm passphrase</span><input id="sc-backup-confirm" type="password" minlength="12" autocomplete="new-password"></label><button class="btn primary" id="sc-backup">Download encrypted backup</button></article>
    <article class="card"><h3>Restore a backup</h3><p>Restore replaces this device’s workspace with the backup. Export your current workspace first. Nothing changes if the passphrase is wrong.</p><label class="field"><span>Encrypted backup file</span><input id="sc-restore-file" type="file" accept=".json,application/json"></label><label class="field"><span>Backup passphrase</span><input id="sc-restore-pass" type="password" autocomplete="current-password"></label><label class="field"><span><input id="sc-restore-agree" type="checkbox"> I understand this replaces all local hotels and files</span></label><button class="btn" id="sc-restore">Restore selected backup</button></article>
    <article class="card"><h3>Start your hotel</h3><p>The original dashboards include labeled sample records. Create a blank hotel to start your own work while preserving the sample workspace.</p><label class="field"><span>Hotel name</span><input id="sc-hotel-name" placeholder="Your hotel name"></label><label class="field"><span>Room count</span><input id="sc-hotel-rooms" type="number" min="1" max="10000" value="100"></label><button class="btn" id="sc-blank-hotel">Create blank hotel</button></article></div>
    <div class="card"><h3>Processing choices</h3><p>Document parsing and OCR run on this device. Call transcription uses your separately configured local companion. No file or transcript is sent to a cloud AI provider by this application.</p><p>Local storage is protected by your device and browser access controls. Encrypted backup protection applies to the exported backup; it does not encrypt the unlocked application database.</p><p>Work email, PEP, OnQ, Lobby and other systems are accessed separately. Import authorized exports; this app does not hold their passwords or write records back automatically.</p></div>
    <div id="sc-safety-result" class="card" role="status" hidden></div></section>`,'set');
  document.addEventListener('click', async event => {
    const button=event.target.closest('button'); if(!button?.id?.startsWith('sc-')) return;
    const id=button.id;
    if(!['sc-backup','sc-restore','sc-persist','sc-blank-hotel'].includes(id))return;
    const result=document.getElementById('sc-safety-result');
    const say=text=>{if(result){result.hidden=false;result.textContent=text;}SC.toast(text);};
    button.disabled=true;
    try {
      if(id==='sc-persist') { const granted=await navigator.storage?.persist?.();say(granted?'Persistent storage granted. Keep exporting backups.':'Browser did not grant persistence. Backups remain available.');await update(); }
      if(id==='sc-backup') {
        const pass=document.getElementById('sc-backup-pass').value;
        if(pass!==document.getElementById('sc-backup-confirm').value)throw new Error('Passphrases do not match.');
        storage.capture();const blob=await storage.backup(pass);
        SC.download(blob,`Sales-Command-Encrypted-${new Date().toISOString().slice(0,10)}.json`);
        await storage.db.settings.put({id:'last-backup',value:new Date().toISOString()});
        say('Encrypted backup exported. Keep the file and passphrase somewhere safe.'); await update();
      }
      if(id==='sc-restore') {
        if(!document.getElementById('sc-restore-agree').checked)throw new Error('Confirm replacement before restoring.');
        const file=document.getElementById('sc-restore-file').files[0];if(!file)throw new Error('Choose an encrypted backup file.');
        const count=await storage.restore(file,document.getElementById('sc-restore-pass').value);
        SC.navigate('deviceSafety');SC.toast(`Restored ${count.properties} hotels and ${count.files} attachments.`);await update();
      }
      if(id==='sc-blank-hotel') {
        const name=document.getElementById('sc-hotel-name').value.trim();
        const rooms=Number(document.getElementById('sc-hotel-rooms').value);
        if(!name||!Number.isInteger(rooms)||rooms<1||rooms>10000)throw new Error('Enter a hotel name and room count from 1 to 10,000.');
        await SC.createProperty({name,short:name,rooms});await update();
      }
    } catch(error){say(error.message||'Operation failed. Your existing data is still available.');}
    finally {button.disabled=false;}
  });
  SC.on('propertychange',update);SC.on('navigate',()=>{if(SC.view==='deviceSafety')update();});
  window.addEventListener('sc-storage-status',()=>{
    const el=document.getElementById('sc-save-status');if(el)el.textContent=storage.status.message;
    const status=document.getElementById('saved');if(status){status.textContent=storage.status.message;status.title='Device storage; backup separately';}
  });
  update();
}

if (import.meta.env.PROD && 'serviceWorker' in navigator) {
  addEventListener('load',()=>navigator.serviceWorker.register('/service-worker.js').catch(error=>console.warn('Offline setup unavailable',error)));
}
