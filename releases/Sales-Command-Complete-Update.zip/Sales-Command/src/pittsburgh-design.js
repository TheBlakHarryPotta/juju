const PALETTES = [
  { id: 'steel', name: 'Steel City', detail: 'Midnight steel. Pittsburgh gold.', colors: ['#111416', '#f1c75b', '#394146'], mode: 'dark' },
  { id: 'river', name: 'Three Rivers', detail: 'Riverfront stadiums. Deep blue & teal.', colors: ['#0c1d2b', '#74d9cc', '#24455a'], mode: 'dark' },
  { id: 'copper', name: 'Foundry', detail: 'Warm charcoal. A copper glow.', colors: ['#211a19', '#ecb38a', '#66514b'], mode: 'dark' },
  { id: 'daylight', name: 'Sunday Morning', detail: 'Warm paper. Quiet gold.', colors: ['#f3f1eb', '#87651c', '#dedacf'], mode: 'light' },
];
const ICONS = {
  bridge: '<path d="M2 17h28M4 17V8m24 9V8M4 9c7-7 17-7 24 0M4 9c7 7 17 7 24 0M9 6v11M15 4v13M21 6v11"/>',
  palette: '<circle cx="12" cy="12" r="8"/><path d="M12 4c0 6 8 3 8 8M6.5 8h.01M10.5 6.5h.01M6.5 12h.01M10 15h.01"/>',
  arrow: '<path d="M5 12h14m-6-6 6 6-6 6"/>',
  record: '<rect x="9" y="3" width="6" height="12" rx="3"/><path d="M6 10v2a6 6 0 0 0 12 0v-2M12 18v3m-3 0h6"/>',
  folder: '<path d="M3 6h7l2 3h9v11H3zM3 6V4h7l2 2h7v3"/>',
  radar: '<circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="4"/><path d="m12 12 7-7"/><circle cx="10" cy="8" r="1"/>',
  key: '<circle cx="8" cy="9" r="4"/><path d="m11 12 9 9m-4-4 3-3m-6 0 3-3"/>',
};
const icon = (name, box = '0 0 24 24') => `<svg viewBox="${box}" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICONS[name] || ICONS.arrow}</svg>`;

// Original line illustration inspired by Pittsburgh's rivers, hills and bridges.
// No third-party photographs, logos, maps, or copied illustrations are used.
const CITY = `<svg class="pg-city" viewBox="0 0 650 320" fill="none" aria-hidden="true">
 <defs><linearGradient id="pgRiver" x1="310" y1="260" x2="310" y2="320" gradientUnits="userSpaceOnUse"><stop stop-color="currentColor" stop-opacity=".16"/><stop offset="1" stop-color="currentColor" stop-opacity="0"/></linearGradient><linearGradient id="pgSkyline" x1="310" y1="70" x2="310" y2="250" gradientUnits="userSpaceOnUse"><stop stop-color="currentColor" stop-opacity=".25"/><stop offset="1" stop-color="currentColor" stop-opacity=".035"/></linearGradient></defs>
 <g class="pg-city-orbit" opacity=".2"><circle cx="370" cy="150" r="115"/><circle cx="370" cy="150" r="145" stroke-dasharray="2 10"/></g>
 <path d="M75 225 130 182 181 190 230 155 270 165 330 128 375 145 422 115 485 158 535 150 610 210" stroke="currentColor" stroke-opacity=".11"/>
 <g class="pg-city-buildings" fill="url(#pgSkyline)" stroke="currentColor" stroke-opacity=".36" stroke-width="1.1"><path d="M148 248V170h33v78M190 248V142h27v106M224 248V116h34v132M266 248V134h23v114M296 248V101h23v147M328 248V75l15-25 15 25v173M367 248V116h31v132M406 248V151h28v97M441 248V133h25v115M474 248V175h35v73M518 248V194h30v54"/></g>
 <g class="pg-city-windows" stroke="currentColor" stroke-width="2.2"><path class="pg-window-light" d="M236 128v4m10 5v4m-10 9v4"/><path class="pg-window-light" d="M246 163v4m-10 9v4m10 9v4"/><path class="pg-window-light" d="M305 114v4m0 12v4"/><path class="pg-window-light" d="M305 146v4m0 12v4m0 12v4"/><path class="pg-window-light" d="M339 85v5m9 7v5m-9 7v5"/><path class="pg-window-light" d="M348 121v5m-9 7v5m9 7v5"/><path class="pg-window-light" d="M339 157v5m9 7v5"/><path class="pg-window-light" d="M377 130v4m10 9v4"/><path class="pg-window-light" d="M377 156v4m10 9v4"/><path class="pg-window-light" d="M450 147v4m7 9v4m-7 9v4"/><path class="pg-window-light" d="M486 186v4m10 9v4"/><path class="pg-window-light" d="M160 181v4m9 9v4m32-44v4m0 11v4m76-26v4"/></g>
 <path d="M35 261H635v59H35z" fill="url(#pgRiver)"/>
 <g class="pg-stadium-district" stroke="currentColor" stroke-linejoin="round">
  <g class="pg-ballpark">
   <path class="pg-stadium-shell" d="M69 225C75 190 109 174 153 175c43 1 75 18 81 52l-21 10c-7-27-30-41-60-42-30 0-53 14-62 42z"/>
   <path class="pg-stadium-tier" d="M79 222c13-48 132-51 145 1M87 226c18-38 116-42 130 1"/>
   <path class="pg-stadium-seats" d="m89 203 9 8m9-21 6 12m15-19 3 13m23-14v13m20-10-3 13m21-7-6 12m22-1-9 8"/>
   <path class="pg-ballpark-grass" d="m153 244-38-37c21-20 55-20 76 0z"/>
   <path class="pg-ballpark-diamond" d="m153 242-23-18 23-18 23 18z"/>
   <path class="pg-field-lines" d="m153 242-42-41m42 41 42-41M153 229v-4"/>
   <g class="pg-ballpark-bases" fill="var(--pg-text)" stroke="none"><rect x="151.5" y="204.5" width="3" height="3" transform="rotate(45 153 206)"/><rect x="128.5" y="222.5" width="3" height="3" transform="rotate(45 130 224)"/><rect x="174.5" y="222.5" width="3" height="3" transform="rotate(45 176 224)"/><path d="m151 240 4 0v3l-2 2-2-2z"/></g>
   <g class="pg-stadium-light"><path d="M80 215v-39m-3 39 3-11 3 11"/><rect x="72" y="172" width="16" height="5" rx="1"/><path class="pg-stadium-beam" d="m73 177 34 32-10-32z"/></g>
   <g class="pg-stadium-light"><path d="M113 192v-36"/><rect x="105" y="152" width="16" height="5" rx="1"/><path class="pg-stadium-beam" d="m105 157 17 51 12-51z"/></g>
   <g class="pg-stadium-light"><path d="M191 196v-37"/><rect x="183" y="155" width="16" height="5" rx="1"/><path class="pg-stadium-beam" d="m184 160-19 47 34-47z"/></g>
   <g class="pg-stadium-light"><path d="M224 216v-37"/><rect x="216" y="175" width="16" height="5" rx="1"/></g>
  </g>
  <g class="pg-football-stadium">
   <path class="pg-stadium-shell" d="M479 225c0-22 34-38 77-38s78 16 78 38v12c-9 17-41 27-78 27s-69-10-77-27z"/>
   <ellipse class="pg-stadium-tier" cx="556" cy="222" rx="70" ry="27"/>
   <ellipse class="pg-stadium-tier" cx="556" cy="225" rx="62" ry="21"/>
   <path class="pg-football-field" d="m513 228 42-19 58 19-42 20z"/>
   <path class="pg-football-yard-lines" d="m523 224 58 19m-46-25 58 19m-46-24 58 19m-71-8 42-19m-31 23 42-19m-30 23 42-20"/>
   <g class="pg-football-goalposts"><path d="M521 231v-14m-5-5v6h10v-6M602 228v-14m-5-5v6h10v-6"/></g>
   <path class="pg-stadium-seats" d="m492 225 9 2m3-19 6 4m16-14 3 5m24-9v6m23-3-2 6m23 2-5 5m22 4-7 4m-107 24 8-4m16 13 3-5m25 9v-6m25 4-3-6m23-1-6-5"/>
   <g class="pg-stadium-light"><path d="M488 213v-33"/><rect x="479" y="175" width="18" height="5" rx="1"/><path class="pg-stadium-beam" d="m480 181 44 36-25-36z"/></g>
   <g class="pg-stadium-light"><path d="M621 213v-33"/><rect x="612" y="175" width="18" height="5" rx="1"/><path class="pg-stadium-beam" d="m613 181-33 36 51-36z"/></g>
  </g>
 </g>
 <g class="pg-bridge" stroke="currentColor"><path d="M20 259H637" stroke-width="3"/><path d="M82 260V111h9v149m409 0V111h9v149" stroke-width="2.3"/><path d="M86 124Q295 258 504 124" stroke-width="3"/><path d="M77 123h18m400 0h18M86 124 20 259m484-135 133 135" stroke-width="2"/><path d="M135 152v107m51-86v86m51-73v73m52-68v68m52-71v71m52-82v82m52-103v103" stroke-width="1.3"/><path d="M85 260 36 287m468-27 80 27" stroke-width="2"/></g>
 <g class="pg-traffic pg-car-forward"><rect width="11" height="3.5" rx="1.2" fill="var(--pg-text)"/><path d="M3 0 4-2h4l2 2" stroke="currentColor" stroke-width="1.3"/><circle cx="2" cy="4" r="1" fill="currentColor"/><circle cx="9" cy="4" r="1" fill="currentColor"/></g>
 <g class="pg-traffic pg-car-reverse"><rect width="10" height="3" rx="1" fill="currentColor"/><path d="M2 0 3-2h4l2 2" stroke="currentColor" stroke-width="1.2"/></g>
 <g class="pg-plane" fill="currentColor"><path d="m-10 0 8-2-1-7 2-1 3 7 8-1 2 2-10 2-2 6-2 1 1-7-7 1z"/></g>
 <g class="pg-water-reflection" stroke="currentColor" stroke-opacity=".22" stroke-width="2"><path d="M153 269v17m15-17v30m35-30v13m35-13v35m39-35v20m26-20v39m34-39v45m11-45v28m35-28v32m38-32v20m35-20v36m39-36v17m35-17v28"/></g>
 <g class="pg-river-lines" stroke="currentColor" stroke-opacity=".3"><path d="M80 281h140m60 4h155m34-10h110M138 299h120m43 3h187m34-13h60M53 310h98m205 7h210"/></g>
 <g class="pg-river-current" stroke="currentColor" stroke-opacity=".42" stroke-width="1.2"><path d="M50 276c35-4 48 4 85 0s55-4 90 0m53 2c35-4 60 4 95 0s50-4 83 0M128 292c37-4 55 4 94 0s56-4 94 0m51 1c38-4 58 4 98 0s62-4 103 0M67 309c33-3 51 3 86 0m94-1c40-3 63 3 102 0s65-3 109 0"/></g>
 <circle class="pg-city-star" cx="520" cy="70" r="3" fill="currentColor"/><path d="M102 96h8m-4-4v8M573 122h7m-3.5-3.5v7" stroke="currentColor" stroke-opacity=".45"/>
</svg>`;

export function initPittsburghDesign({ SC }) {
  if (document.documentElement.dataset.pittsburghReady) return;
  document.documentElement.dataset.pittsburghReady = 'true';
  const root = document.documentElement;
  document.body.classList.add('pg-shell');
  const read = (key, fallback) => { try { return localStorage.getItem(key) || fallback; } catch { return fallback; } };
  const write = (key, value) => { try { localStorage.setItem(key, value); } catch {} };
  let palette = read('sc.pittsburgh.palette', 'steel');
  let motion = read('sc.pittsburgh.motion', 'on') !== 'off';
  let collapsed = {};
  try { collapsed = JSON.parse(read('sc.pittsburgh.nav', '{"Revenue":true,"Reports":true,"Growth":true}')); } catch {}
  if (!PALETTES.some(item => item.id === palette)) palette = 'steel';
  const reduced = () => !motion || matchMedia('(prefers-reduced-motion: reduce)').matches;
  let lastRoute = '';
  let scheduled = false;
  const sceneLabel = () => `Original Pittsburgh riverfront illustration inspired by the Roberto Clemente Bridge${palette === 'river' ? ', with a baseball ballpark and football stadium inspired by Pittsburgh’s riverfront sports venues' : ''}, gentle river reflections, window lights, bridge traffic and an occasional aircraft.`;

  function applyPalette() {
    root.dataset.pittsburghPalette = palette;
    root.dataset.pgMotion = document.hidden || reduced() ? 'off' : 'on';
    root.dataset.theme = PALETTES.find(item => item.id === palette).mode;
    document.querySelectorAll('.pg-city-wrap').forEach(scene => scene.setAttribute('aria-label', sceneLabel()));
    document.querySelectorAll('[data-pg-palette]').forEach(button => button.setAttribute('aria-pressed', String(button.dataset.pgPalette === palette)));
  }
  function paletteCards() {
    return `<div class="pg-palette-grid">${PALETTES.map(item => `<button type="button" class="pg-palette-card" data-pg-palette="${item.id}" aria-pressed="${item.id === palette}"><span class="pg-palette-preview" style="--pg-preview-bg:${item.colors[0]};--pg-preview-accent:${item.colors[1]};--pg-preview-line:${item.colors[2]}">${icon('bridge', '0 0 32 24')}<i></i><i></i><i></i></span><strong>${item.name}</strong><span>${item.detail}</span></button>`).join('')}</div>`;
  }
  function openAppearance() {
    SC.modal(`<section class="pg-appearance"><div class="pg-dialog-heading"><div><span class="pg-eyebrow">MAKE IT YOURS</span><h2>Your city. Your colors.</h2></div><button type="button" class="btn ghost" data-act="xClose" aria-label="Close appearance">Close</button></div><p class="muted">A different atmosphere for the same workspace. Your files and records stay as they are.</p>${paletteCards()}<label class="pg-motion-setting"><span><strong>A little movement</strong><small>Gentle entrances, bridge details and responsive feedback. Your device's reduced-motion preference always takes priority.</small></span><input id="pgMotionEnabled" type="checkbox"${motion ? ' checked' : ''}></label><div class="pg-appearance-footer"><span class="pg-local-dot"></span>Appearance saved on this device</div></section>`);
  }
  function groupNavigation(side) {
    if (side.querySelector('.pg-nav-group')) return;
    const children = [...side.children];
    let group;
    let index = 0;
    for (const node of children) {
      if (node.classList.contains('nav-label')) {
        group = null;
        node.dataset.pgSection = node.textContent.trim();
        node.hidden = true;
        continue;
      }
      if (!node.classList.contains('nav')) continue;
      if (node.dataset.go === 'settings') group = null;
      if (!group) {
        const previousLabel = [...children.slice(0, children.indexOf(node))].reverse().find(item => item.classList.contains('nav-label'));
        const name = node.dataset.go === 'settings' ? 'Settings' : index === 0 ? 'Your workday' : previousLabel?.textContent.trim() || 'More';
        const details = document.createElement('details'); details.className = 'pg-nav-group';
        details.dataset.pgGroup = name;
        details.open = collapsed[name] !== true || node.classList.contains('on');
        const summary = document.createElement('summary'); summary.textContent = name;
        summary.append(Object.assign(document.createElement('span'), { className: 'pg-nav-chevron', textContent: '⌄' }));
        details.append(summary);
        const body = document.createElement('div'); body.className = 'pg-nav-items'; details.append(body);
        node.before(details); group = { details, body }; index++;
        details.addEventListener('toggle', () => {
          collapsed[name] = !details.open; write('sc.pittsburgh.nav', JSON.stringify(collapsed));
        });
      }
      group.body.append(node);
      if (node.classList.contains('on')) group.details.open = true;
    }
    const foot = side.querySelector('.side-foot');
    if (foot && !side.querySelector('.pg-sidebar-studio')) {
      const studio = document.createElement('button'); studio.className = 'pg-sidebar-studio'; studio.type = 'button';
      studio.dataset.pgAction = 'appearance'; studio.innerHTML = `${icon('palette')}<span>Make it yours<small>Colors & movement</small></span>${icon('arrow')}`;
      foot.before(studio);
    }
  }
  function decorateHeader() {
    const top = document.getElementById('top');
    if (!top) return;
    const themeButton = top.querySelector('[data-act="theme"]');
    if (themeButton) {
      if (!themeButton.dataset.pgStyled) { themeButton.innerHTML = icon('palette'); themeButton.dataset.pgStyled = 'true'; } themeButton.title = 'Colors & appearance'; themeButton.setAttribute('aria-label', 'Choose site appearance');
    }
    const importButton = top.querySelector('[data-act="xImport"]');
    if (importButton) { importButton.setAttribute('aria-label', 'Capture files or screenshots'); importButton.title = 'Capture files or screenshots'; const label = importButton.querySelector('span'); if (label && label.textContent !== 'Capture') label.textContent = 'Capture'; }
    const title = top.querySelector('h1');
    if (title && !title.previousElementSibling?.classList.contains('pg-top-eyebrow')) {
      const label = document.createElement('span'); label.className = 'pg-top-eyebrow'; label.textContent = 'SALES COMMAND / PITTSBURGH'; title.before(label);
    }
  }
  function decorateHome(view) {
    const today = view.querySelector('#scToday');
    if (!today || today.dataset.pgReady) return;
    today.dataset.pgReady = 'true';
    const copy = today.querySelector('.sc-today-copy');
    const fileButton = [...today.querySelectorAll('.sc-actions button')].find(button => /import a file/i.test(button.textContent));
    if (fileButton) fileButton.dataset.pgGo = 'captureStation';
    if (copy) {
      const eyebrow = copy.querySelector('.sc-eyebrow'); if (eyebrow) eyebrow.innerHTML = '<span class="pg-live-dot"></span> A STEEL CITY STATE OF MIND';
      const title = copy.querySelector('h2'); if (title) title.innerHTML = 'Build relationships.<br><span>Move business forward.</span>';
      const text = copy.querySelector('p'); if (text) text.textContent = 'Your accounts, conversations and contracts. One clear place to keep the next move in sight.';
    }
    const city = document.createElement('div'); city.className = 'pg-city-wrap'; city.setAttribute('role', 'img'); city.setAttribute('aria-label', sceneLabel()); city.innerHTML = CITY;
    today.append(city);
    const stamp = document.createElement('div'); stamp.className = 'pg-city-stamp'; stamp.innerHTML = '<span>40.4406° N</span><strong>THREE RIVERS.<br>ENDLESS POSSIBILITIES.</strong><span>80.0000° W</span>'; city.append(stamp);
    const shortcuts = document.createElement('div'); shortcuts.className = 'pg-task-grid'; shortcuts.setAttribute('aria-label', 'Sales workspace shortcuts');
    const destinations = [
      ['srpVault', 'key', 'The right code. Right here.', 'SRP & group codes', '01'],
      ['contracts', 'folder', 'From conversation to contract.', 'Contract Maker', '02'],
      ['accountRadar', 'radar', 'Find your next opportunity.', 'Account Radar', '03'],
      ['calls', 'record', 'Capture the important parts.', 'Call Desk', '04'],
    ];
    shortcuts.innerHTML = destinations.map(([route, glyph, title, label, number]) => `<button type="button" class="pg-task-card" data-pg-go="${route}"><span class="pg-task-top"><span class="pg-task-icon">${icon(glyph)}</span><span class="pg-task-number">${number}</span></span><span class="pg-task-title">${title}</span><span class="pg-task-bottom">${label}${icon('arrow')}</span></button>`).join('');
    today.after(shortcuts);
    const greeting = view.querySelector('.sc-home-greeting');
    if (greeting && !greeting.querySelector('.pg-progress-label')) {
      const label = document.createElement('span'); label.className = 'pg-progress-label'; label.textContent = 'YOUR WEEK, IN MOTION'; greeting.prepend(label);
    }
  }
  function enhanceSettings(view) {
    if ((SC.currentView || SC.view) !== 'settings') return;
    const appearance = [...view.querySelectorAll('.card')].find(card => card.querySelector('h3')?.textContent.trim() === 'Appearance');
    if (!appearance || appearance.querySelector('.pg-settings-palette')) return;
    [...appearance.children].filter(el => !el.matches('h3')).forEach(el => el.classList.add('pg-previous-appearance'));
    const content = document.createElement('div'); content.className = 'pg-settings-palette';
    content.innerHTML = `<p class="muted">Pittsburgh-inspired colors for your entire workspace.</p>${paletteCards()}<button type="button" class="btn" data-pg-action="appearance">Colors & motion settings</button>`;
    appearance.append(content);
  }
  function enhance() {
    scheduled = false;
    const expectedMode = PALETTES.find(item => item.id === palette).mode;
    if (root.dataset.theme !== expectedMode) root.dataset.theme = expectedMode;
    const side = document.getElementById('side');
    if (side) {
      const logo = side.querySelector('.logo'); if (logo && !logo.dataset.pgLogo) { logo.dataset.pgLogo = 'true'; logo.innerHTML = icon('bridge', '0 0 32 24'); }
      const brand = side.querySelector('.brand b'); if (brand && !brand.parentElement.querySelector('.pg-brand-edition')) { const tag = document.createElement('span'); tag.className = 'pg-brand-edition'; tag.textContent = 'THE PITTSBURGH EDITION'; brand.after(tag); }
      groupNavigation(side);
    }
    decorateHeader();
    const view = document.getElementById('view');
    if (view) {
      const route = SC.currentView || SC.view || 'home'; root.dataset.pgRoute = route;
      if (route === 'home') decorateHome(view);
      enhanceSettings(view);
      if (route !== lastRoute) {
        lastRoute = route;
        if (!reduced()) [...view.querySelectorAll('.sc-card,.card,.pg-task-card')].filter(card => !card.closest('.kdoc')).slice(0, 12).forEach((card, index) => card.animate([{ opacity: .35, transform: 'translateY(12px)' }, { opacity: 1, transform: 'translateY(0)' }], { duration: 360, delay: Math.min(index * 28, 180), easing: 'cubic-bezier(.2,.7,.2,1)' }));
      }
    }
  }
  const schedule = () => { if (!scheduled) { scheduled = true; requestAnimationFrame(enhance); } };
  new MutationObserver(schedule).observe(document.body, { childList: true, subtree: true });
  SC.on?.('navigate', schedule); SC.on?.('render', schedule); SC.on?.('propertychange', schedule);
  document.addEventListener('click', event => {
    const side = document.getElementById('side');
    if (matchMedia('(max-width:820px)').matches && side?.classList.contains('open')) {
      if (event.target.closest('#side .nav')) side.classList.remove('open');
      else if (event.target.closest('.app') && !event.target.closest('#side,.menu-btn')) {
        side.classList.remove('open'); document.querySelector('.menu-btn')?.setAttribute('aria-expanded', 'false');
        event.preventDefault(); event.stopImmediatePropagation(); return;
      }
    }
    const button = event.target.closest('[data-pg-action],[data-pg-palette],[data-pg-go],#top [data-act="theme"],#top [data-act="xImport"]');
    if (!button) return;
    event.preventDefault(); event.stopPropagation(); event.stopImmediatePropagation();
    if (button.dataset.pgGo) return SC.navigate(button.dataset.pgGo);
    if (button.matches('#top [data-act="xImport"]')) return SC.navigate('captureStation');
    if (button.dataset.pgPalette) {
      palette = button.dataset.pgPalette; write('sc.pittsburgh.palette', palette); applyPalette();
      SC.toast(`${PALETTES.find(item => item.id === palette).name} appearance saved.`); return;
    }
    openAppearance();
  }, true);
  document.addEventListener('change', event => {
    if (event.target.id !== 'pgMotionEnabled') return;
    motion = event.target.checked; write('sc.pittsburgh.motion', motion ? 'on' : 'off'); applyPalette();
    if (reduced()) document.getAnimations().forEach(animation => animation.cancel());
  });
  matchMedia('(prefers-reduced-motion: reduce)').addEventListener('change', applyPalette);
  document.addEventListener('visibilitychange', () => { root.dataset.pgMotion = document.hidden || reduced() ? 'off' : 'on'; });
  applyPalette(); enhance();
}
