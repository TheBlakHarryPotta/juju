import { parseTable } from './sales-import-parser.js';
import './repeat-business.css';

const DAY = 86400000;
const MAX_MEMORIES = 500;
const text = (value, max = 2000) => typeof value === 'string' || typeof value === 'number' ? String(value).trim().slice(0, max) : '';
const dateText = value => typeof value === 'string' ? value.trim() : '';
const stamp = () => new Date().toISOString();
const uuid = () => crypto.randomUUID();
export const localDay = () => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; };
export function validRepeatDate(value) { if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return false; const d = new Date(value + 'T00:00:00Z'); return Number.isFinite(d.valueOf()) && d.toISOString().slice(0, 10) === value; }
const dayDiff = (a, b) => (Date.parse(b + 'T00:00:00Z') - Date.parse(a + 'T00:00:00Z')) / DAY;
const shiftDay = (date, days) => new Date(Date.parse(date + 'T00:00:00Z') + days * DAY).toISOString().slice(0, 10);
function number(value, label, { integer = false, max = 1e10 } = {}) {
  if (value === null || value === undefined || typeof value === 'string' && value.trim() === '') return null;
  if (!['string', 'number'].includes(typeof value) || typeof value === 'string' && !/^(?:\d{1,3}(?:,\d{3})+|\d+)(?:\.\d+)?$/.test(value.trim())) throw Error(`${label}: enter an explicit nonnegative number, or leave it blank when unknown.`);
  const n = Number(String(value).replaceAll(',', ''));
  if (!Number.isFinite(n) || n < 0 || n > max || integer && !Number.isInteger(n)) throw Error(`${label}: check the ${integer ? 'whole-number ' : ''}value.`);
  return n;
}
function production(rn, revenue, rate, label, { quotedRate = false } = {}) {
  const r = number(rn, label + ' room nights', { integer: true, max: 1e7 });
  const v = number(revenue, label + ' room revenue');
  const a = number(rate, label + ' ADR', { max: 100000 });
  if (r === 0 && v !== null && v > 0) throw Error(`${label}: room revenue cannot be positive with zero room nights. Separate cancellation fees and non-room revenue.`);
  if (!quotedRate && r === 0 && a !== null && a > 0) throw Error(`${label}: ADR is undefined with zero actual room nights. Do not substitute a quoted rate.`);
  const calculated = r !== null && r > 0 && v !== null ? v / r : null;
  if (calculated !== null && a !== null && Math.abs(calculated - a) > .02) throw Error(`${label}: ADR disagrees with room revenue / room nights. Review the source figures.`);
  return { rn: r, revenue: v, adr: !quotedRate && r === 0 ? null : calculated ?? a, adrBasis: !quotedRate && r === 0 ? 'Undefined at zero actual room nights' : calculated !== null ? 'Revenue divided by room nights' : a !== null ? 'Explicit source ADR' : 'Unknown' };
}
export function repeatVariance(memory) {
  const a = memory.actuals || {}, c = memory.contracted || {};
  const delta = key => Number.isFinite(a[key]) && Number.isFinite(c[key]) ? a[key] - c[key] : null;
  return { rn: delta('rn'), revenue: delta('revenue'), adr: delta('adr'), pickupPct: Number.isFinite(a.rn) && Number.isFinite(c.rn) && c.rn > 0 ? a.rn / c.rn * 100 : null };
}
export function normalizeCloseout(input, { today = localDay() } = {}) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) throw Error('Review the closeout fields.');
  if (input.reviewed !== true) throw Error('Confirm that the actual production was reviewed against its source.');
  const arrive = dateText(input.arrive), depart = dateText(input.depart), asOf = dateText(input.asOf);
  if (!validRepeatDate(arrive) || !validRepeatDate(depart) || depart <= arrive || dayDiff(arrive, depart) > 366) throw Error('Enter the completed stay dates, with checkout after arrival and no more than 366 occupied nights.');
  if (depart > today) throw Error('A closeout is for a completed stay. Future dates belong in a new prospect.');
  if (!validRepeatDate(asOf) || asOf > today || asOf < shiftDay(depart, -1)) throw Error('Choose an actual-production as-of date covering the completed stay, no later than today.');
  const actuals = production(input.actualRn, input.actualRevenue, input.actualAdr, 'Actual production');
  if (actuals.rn === null && actuals.revenue === null) throw Error('Enter at least one reviewed actual room-night or room-revenue figure. Contracted figures are not actual production.');
  const nightly = [];
  if (input.nightly !== undefined && !Array.isArray(input.nightly)) throw Error('Nightly pickup must be a reviewed list.');
  if ((input.nightly || []).length > 366) throw Error('Use at most 366 nightly pickup rows.');
  const seen = new Set();
  for (const row of input.nightly || []) {
    if (!row || typeof row !== 'object') throw Error('Check the nightly pickup rows.');
    const date = dateText(row.date);
    if (!validRepeatDate(date) || date < arrive || date >= depart || seen.has(date)) throw Error('Each pickup date must be a unique occupied night within the completed stay. Checkout is not an occupied night.');
    seen.add(date);
    const values = production(row.rn, row.revenue, row.adr, 'Night ' + date);
    if (values.rn === null && values.revenue === null) throw Error('Each nightly row needs explicit actual room nights or room revenue.');
    nightly.push({ date, ...values });
  }
  if (nightly.length && nightly.length !== dayDiff(arrive, depart)) throw Error('Nightly pickup must cover every occupied night, including explicit zero nights. Use a reviewed summary instead of an incomplete nightly extract.');
  for (const key of ['rn', 'revenue']) if (nightly.length && nightly.every(row => row[key] !== null)) {
    const total = nightly.reduce((s, row) => s + row[key], 0);
    if (actuals[key] !== null && Math.abs(actuals[key] - total) > (key === 'revenue' ? .02 : 0)) throw Error('The nightly ' + (key === 'rn' ? 'room nights' : 'room revenue') + ' do not reconcile to the reviewed actual total.');
  }
  const account = text(input.account, 300), event = text(input.event, 300), sourceName = text(input.sourceName, 500);
  if (!account || !event) throw Error('Enter the company / group and event name.');
  if (!sourceName) throw Error('Name the actual-production source, such as an approved stayed-production report.');
  const email = text(input.email, 254);
  if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) throw Error('Check the organizer email.');
  const sourceKind = ['booking', 'contract', 'manual'].includes(input.sourceKind) ? input.sourceKind : 'manual';
  const sourceId = sourceKind === 'manual' ? '' : text(input.sourceId, 200);
  if (sourceKind !== 'manual' && !sourceId) throw Error('Choose the past group / opportunity or contract to link.');
  return {
    account, event, arrive, depart, actuals: { ...actuals, nightly: nightly.sort((a, b) => a.date.localeCompare(b.date)) },
    contracted: production(input.contractedRn, input.contractedRevenue, input.contractedAdr, 'Contracted comparison', { quotedRate: true }),
    organizer: text(input.organizer, 200), email, phone: text(input.phone, 80), segment: text(input.segment, 120),
    serviceNotes: text(input.serviceNotes, 6000), preferences: text(input.preferences, 6000), outcome: text(input.outcome, 3000),
    actualSource: { name: sourceName, asOf, reviewedDate: localDay(), fileId: text(input.fileId, 200), hash: /^[a-f0-9]{64}$/i.test(input.hash || '') ? input.hash : '', reviewedAt: stamp(), method: input.fileId ? 'Reviewed CSV' : 'Reviewed manual entry' },
    source: { kind: sourceKind, id: sourceId }, reviewed: true
  };
}
export function parseActualCSV(csv) {
  const table = parseTable(csv), norm = s => String(s).toLowerCase().replace(/[^a-z0-9]/g, '');
  const headers = table.headers.map(norm);
  const col = names => headers.findIndex(h => names.includes(h));
  const date = col(['date', 'staydate', 'night']);
  if (date < 0 && headers.includes('rooms') && !headers.some(h => ['actualroomnights', 'actualrn', 'roomnights', 'rn'].includes(h))) throw Error('A summary Rooms column is ambiguous. Use Actual room nights totals, or dated nightly room rows.');
  const rn = col(['actualroomnights', 'actualrn', 'roomnights', 'rn', ...(date >= 0 ? ['rooms'] : [])]), revenue = col(['actualroomrevenue', 'actualrevenue', 'roomrevenue', 'revenue']), adr = col(['actualadr', 'adr']);
  if (rn < 0 && revenue < 0) throw Error('CSV needs Actual room nights and/or Actual room revenue columns.');
  if (table.rows.length > 366) throw Error('Import at most 366 nightly rows or one summary row.');
  const seen = new Set(), rows = table.rows.map(row => {
    const d = date >= 0 ? dateText(row[date]) : '';
    if (date >= 0 && (!validRepeatDate(d) || seen.has(d))) throw Error('Nightly CSV dates must be unique YYYY-MM-DD dates.');
    seen.add(d);
    const p = production(rn < 0 ? null : row[rn], revenue < 0 ? null : row[revenue], adr < 0 ? null : row[adr], d ? 'Night ' + d : 'CSV total');
    if (p.rn === null && p.revenue === null) throw Error('CSV row needs explicit actual production.');
    return { date: d, ...p };
  });
  if (date < 0 && rows.length !== 1) throw Error('A summary CSV must have one data row. Add a Date column for nightly pickup; do not combine multiple groups silently.');
  const total = key => rows.every(row => row[key] !== null) ? rows.reduce((sum, row) => sum + row[key], 0) : null;
  return { rn: total('rn'), revenue: total('revenue'), adr: rows.length === 1 ? rows[0].adr : null, nightly: date >= 0 ? rows : [], rows: rows.length };
}
export function normalizeRepeatCycle(input, { today = localDay() } = {}) {
  if (input?.confirmedNewDates !== true) throw Error('Confirm the new stay dates with the organizer before creating a new opportunity.');
  const arrive = dateText(input.arrive), depart = dateText(input.depart), label = text(input.label, 200);
  if (!label) throw Error('Name this new planning cycle, such as 2027 regional tournament.');
  if (!validRepeatDate(arrive) || !validRepeatDate(depart) || depart <= arrive || arrive < today || dayDiff(arrive, depart) > 120) throw Error('Enter confirmed new arrival and checkout dates for a future stay of 120 nights or fewer. Last year’s dates are not reused.');
  return { label, labelKey: label.normalize('NFKC').toLowerCase().replace(/\s+/g, ' '), arrive, depart, notes: text(input.notes, 3000) };
}

export function initRepeatBusiness({ SC, db }) {
  const e = SC.escape, pid = () => String(SC.propertyId);
  const empty = () => ({ version: 1, memories: [], cycles: [], settings: { planningLeadDays: 180 } });
  const data = () => SC.state.repeatBusiness || empty();
  let context = null, busy = false, csvProduction = null, csvSource = null;
  const noticeKeys = new Set();
  function guard(propertyId) { SC.assertProperty(propertyId); if (busy && context && context.propertyId !== propertyId) throw Error('Reopen this record in its original hotel.'); }
  function store(state) { state.repeatBusiness ||= empty(); if (!Array.isArray(state.repeatBusiness.memories) || !Array.isArray(state.repeatBusiness.cycles)) throw Error('Repeat Business data needs recovery from a known backup.'); state.repeatBusiness.settings ||= {}; if (state.repeatBusiness.settings.planningLeadDays === undefined) state.repeatBusiness.settings.planningLeadDays = 180; state.repeatBusiness.version = 1; return state.repeatBusiness; }
  async function mutate(propertyId, label, apply, source) {
    guard(propertyId);
    if (typeof SC.atomicMutation !== 'function') throw Error('The local transaction service is not ready. Reload after startup completes.');
    let result;
    await SC.atomicMutation({ propertyId, expectedStateJSON: JSON.stringify(SC.state), label, source, apply: draft => { result = apply(draft); } });
    return structuredClone(result);
  }
  function sourceIn(state, kind, id, propertyId) {
    if (kind === 'manual') return null;
    const row = (kind === 'contract' ? state.contracts || [] : state.bookings || []).find(r => r.id === id && (!r.propertyId || r.propertyId === propertyId));
    if (!row) throw Error('The linked past record is not available in this hotel. Reopen the closeout and choose its source.');
    return row;
  }
  async function closeout(input, { propertyId = pid(), memoryId = '', baseJSON = '' } = {}) {
    if (input?.propertyId !== undefined && String(input.propertyId) !== propertyId) throw Error('This closeout belongs to another hotel.');
    const values = normalizeCloseout(input), id = memoryId || uuid();
    const expectedSource = input?.sourceFingerprint;
    if (values.actualSource.fileId) {
      const original = await db.files.get(values.actualSource.fileId); guard(propertyId);
      if (!original || original.propertyId !== propertyId || values.actualSource.hash && original.hash !== values.actualSource.hash) throw Error('The actual-production source is unavailable or belongs to another hotel. Reopen the source in this hotel.');
    }
    return mutate(propertyId, memoryId ? 'Update reviewed repeat-business closeout' : 'Save reviewed repeat-business closeout', state => {
      const w = store(state), old = memoryId ? w.memories.find(m => m.id === memoryId && m.propertyId === propertyId) : null;
      if (memoryId && (!old || baseJSON && JSON.stringify(old) !== baseJSON)) throw Error('This closeout changed. Reopen its latest version.');
      if (!old && w.memories.length >= MAX_MEMORIES) throw Error('This hotel has 500 closeouts. Keep an encrypted archive before adding more.');
      const linked = sourceIn(state, values.source.kind, values.source.id, propertyId);
      if (linked && expectedSource && JSON.stringify(linked) !== expectedSource) throw Error('The linked group / contract changed during review. Reopen it before saving the closeout.');
      const canonical = v => v.normalize('NFKC').toLowerCase().replace(/\s+/g, ' ');
      const key = JSON.stringify([values.source.kind, values.source.id || canonical(values.account), canonical(values.event), values.arrive, values.depart]);
      if (w.memories.some(m => m.id !== memoryId && m.closeoutKey === key)) throw Error('A closeout already exists for this source, event and stay. Edit that memory instead.');
      const memory = { ...(old || {}), ...values, id, propertyId, closeoutKey: key, source: { ...values.source, propertyId, label: linked ? text(linked.type === 'group' ? linked.data?.event || linked.data?.org : linked.name || linked.data?.account, 300) : 'Manual historical closeout' }, reminder: old?.reminder || { date: '', windowStart: '', windowEnd: '', leadDays: w.settings.planningLeadDays, state: 'Not scheduled' }, createdAt: old?.createdAt || stamp(), updatedAt: stamp() };
      if (old) w.memories[w.memories.indexOf(old)] = memory; else w.memories.push(memory);
      return memory;
    }, { kind: 'repeat-business-closeout', fileId: values.actualSource.fileId, hash: values.actualSource.hash });
  }
  async function planReminder(memoryId, input, { propertyId = pid(), baseJSON = '' } = {}) {
    const leadDays = number(input.leadDays, 'Planning lead days', { integer: true, max: 730 });
    if (leadDays === null) throw Error('Choose planning lead days, including explicit 0 if appropriate.');
    const date = dateText(input.date), windowStart = dateText(input.windowStart), windowEnd = dateText(input.windowEnd);
    if (!validRepeatDate(date) || windowStart && !validRepeatDate(windowStart) || windowEnd && !validRepeatDate(windowEnd) || windowStart && windowEnd && windowEnd < windowStart) throw Error('Review the reminder date and planning window. These are planning dates, not confirmed stay dates.');
    return mutate(propertyId, 'Schedule repeat-business reminder', state => {
      const w = store(state), m = w.memories.find(m => m.id === memoryId && m.propertyId === propertyId);
      if (!m || baseJSON && JSON.stringify(m) !== baseJSON) throw Error('This memory changed. Reopen its reminder settings.');
      m.reminder = { date, windowStart, windowEnd, leadDays, state: 'Scheduled' }; m.updatedAt = stamp(); w.settings.planningLeadDays = leadDays; return m;
    }, { kind: 'repeat-business-reminder', memoryId });
  }
  async function createCycle(memoryId, input, { propertyId = pid() } = {}) {
    guard(propertyId);
    const values = normalizeRepeatCycle(input), bookingId = uuid(), prospectId = uuid(), cycleId = uuid();
    const existingCycle = data().cycles.find(c => c.memoryId === memoryId && c.propertyId === propertyId && c.cycleKey === memoryId + ':' + values.labelKey);
    if (existingCycle) {
      if (!(SC.state.bookings || []).some(b => b.id === existingCycle.bookingId && (!b.propertyId || b.propertyId === propertyId)) || !(SC.state.salesWorkflows?.prospects || []).some(p => p.id === existingCycle.prospectId && p.propertyId === propertyId)) throw Error('This cycle already exists, but a linked record was removed. Review its history or restore the missing record before retrying.');
      return { ...structuredClone(existingCycle), existing: true };
    }
    return mutate(propertyId, 'Create confirmed-date repeat-business prospect', state => {
      const w = store(state), m = w.memories.find(m => m.id === memoryId && m.propertyId === propertyId);
      if (!m) throw Error('The past-business memory is not available in this hotel.');
      const cycleKey = m.id + ':' + values.labelKey, existing = w.cycles.find(c => c.cycleKey === cycleKey);
      if (existing) {
        if (!(state.bookings || []).some(b => b.id === existing.bookingId && (!b.propertyId || b.propertyId === propertyId)) || !(state.salesWorkflows?.prospects || []).some(p => p.id === existing.prospectId && p.propertyId === propertyId)) throw Error('This cycle already exists, but a linked record was removed. Review its history or restore the missing record before retrying.');
        throw Error('This planning cycle was created while reviewing it. Reopen the linked opportunity; no duplicate was created.');
      }
      if (w.cycles.length >= 1000) throw Error('This hotel has 1,000 retained planning cycles. Keep an encrypted archive before adding more.');
      state.bookings ||= [];
      state.salesWorkflows ||= { tours: [], networking: [], prospects: [], reportPins: [] };
      if (!Array.isArray(state.bookings) || !Array.isArray(state.salesWorkflows.prospects)) throw Error('Recover the pipeline data before creating a new cycle.');
      const source = { kind: 'repeat-business', propertyId, memoryId: m.id, cycleKey, previousSourceId: m.source.id };
      const notes = `Repeat-business planning from ${m.event} (${m.arrive} to ${m.depart}). Prior closeout as reviewed when this cycle was created: actual room nights ${m.actuals.rn ?? 'unknown'}; room revenue ${m.actuals.revenue ?? 'unknown'}. New dates were explicitly confirmed. Rate, room allocation and commercial terms are not copied from the old stay.${values.notes ? '\n' + values.notes : ''}`;
      state.bookings.push({ id: bookingId, propertyId, name: values.label, account: m.account, contact: m.organizer, email: m.email, phone: m.phone, segment: m.segment || 'Other', status: 'Prospect', statusDate: localDay(), created: localDay(), arrival: values.arrive.slice(0, 7), arrive: values.arrive, depart: values.depart, rn: 0, adr: 0, rev: 0, revManual: false, notes, source: 'Other', sourceRef: source, repeatMemoryId: m.id, repeatCycleId: cycleId, unquoted: true });
      state.salesWorkflows.prospects.push({ id: prospectId, propertyId, account: m.account, contact: m.organizer, email: m.email, phone: m.phone, arrive: values.arrive, depart: values.depart, nextStep: 'Confirm room allocation, current needs and an approved rate', nextDate: '', notes: values.notes, status: 'New', contacted: false, identifiedDate: localDay(), sourceId: m.id, sourceKey: 'repeat:' + cycleKey, source: { ...source, bookingId }, sourceKind: 'Repeat-business planning', createdAt: stamp(), updatedAt: stamp() });
      const cycle = { id: cycleId, memoryId: m.id, propertyId, cycleKey, label: values.label, arrive: values.arrive, depart: values.depart, bookingId, prospectId, datesConfirmedAt: stamp(), createdAt: stamp() };
      w.cycles.push(cycle); m.reminder = { ...m.reminder, state: 'Linked opportunity' }; m.updatedAt = stamp(); return { ...cycle, existing: false };
    }, { kind: 'repeat-business-cycle', memoryId });
  }
  function queue(today = localDay()) { return data().memories.filter(m => m.propertyId === pid() && m.reminder?.state === 'Scheduled' && validRepeatDate(m.reminder.date) && m.reminder.date <= today); }
  const n = value => Number.isFinite(value) ? new Intl.NumberFormat('en-US', { maximumFractionDigits: 2 }).format(value) : 'Unknown';
  const money = value => Number.isFinite(value) ? new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(value) : 'Unknown';
  const signed = (value, monetary = false) => value === null ? 'Not comparable' : (value > 0 ? '+' : '') + (monetary ? money(value) : n(value));
  const button = (action, label, memory) => `<button type="button" class="btn" data-rb-action="${action}"${memory ? ` data-id="${e(memory.id)}"` : ''}>${label}</button>`;
  const field = (label, html) => `<label class="sc-field innovation-field"><span>${label}</span>${html}</label>`;
  const input = (name, value = '', extra = '') => `<input name="${name}" value="${e(value ?? '')}" ${extra}>`;
  const area = (name, value = '') => `<textarea name="${name}" rows="4" maxlength="6000">${e(value ?? '')}</textarea>`;
  function sourceOptions() { return [{ value: 'manual:', name: 'Manual historical closeout' }, ...(SC.state.bookings || []).filter(b => !b.propertyId || b.propertyId === pid()).map(b => ({ value: 'booking:' + b.id, name: 'Group / opportunity: ' + (b.name || b.account || 'Untitled') })), ...(SC.state.contracts || []).filter(c => !c.propertyId || c.propertyId === pid()).map(c => ({ value: 'contract:' + c.id, name: 'Contract: ' + (c.data?.event || c.data?.org || c.data?.account || 'Untitled') }))]; }
  function sourceDefaults(kind, id) {
    const row = sourceIn(SC.state, kind, id, pid()); if (!row) return {};
    if (kind === 'booking') return { event: row.name, account: row.account || row.name, organizer: row.contact, segment: row.segment, arrive: validRepeatDate(row.arrive) ? row.arrive : '', depart: validRepeatDate(row.depart) ? row.depart : '', contractedRn: Number(row.rn) > 0 ? row.rn : '', contractedRevenue: Number(row.rev) > 0 ? row.rev : '', contractedAdr: Number(row.adr) > 0 ? row.adr : '', fingerprint: JSON.stringify(row) };
    const d = row.data || {}, nights = Array.isArray(d.rooms) ? d.rooms.flatMap(r => Object.entries(r.nights || {}).map(([date, count]) => ({ date, count: Number(count), rate: Number(r.rate) }))).filter(r => validRepeatDate(r.date) && r.date >= d.arrive && r.date < d.depart && Number.isFinite(r.count) && r.count >= 0) : [];
    const rn = nights.reduce((s, x) => s + x.count, 0), revenue = nights.length && nights.every(x => Number.isFinite(x.rate) && x.rate >= 0) ? nights.reduce((s, x) => s + x.count * x.rate, 0) : null;
    return { event: d.event || d.org || d.account, account: d.org || d.account, organizer: d.contact, phone: d.phone, email: d.email, arrive: d.arrive, depart: d.depart, contractedRn: rn || '', contractedRevenue: revenue ?? '', contractedAdr: rn && revenue !== null ? revenue / rn : '', fingerprint: JSON.stringify(row) };
  }
  function card(m) {
    const v = repeatVariance(m), cycles = data().cycles.filter(c => c.memoryId === m.id && c.propertyId === pid());
    return `<article class="sc-card innovation-card rb-memory" data-rb-memory="${e(m.id)}"><div class="sc-toolbar"><span class="sc-badge">REVIEWED CLOSEOUT</span><span>${e(m.arrive)} → ${e(m.depart)}</span></div><h3>${e(m.event)}</h3><p>${e(m.account)} · ${e(m.organizer || 'Organizer not entered')}</p><div class="rb-comparison"><div><span>Actual room nights</span><strong>${n(m.actuals.rn)}</strong><small>Contracted ${n(m.contracted.rn)} · variance ${signed(v.rn)}</small></div><div><span>Actual room revenue</span><strong>${money(m.actuals.revenue)}</strong><small>Contracted ${money(m.contracted.revenue)} · variance ${signed(v.revenue, true)}</small></div><div><span>Actual ADR</span><strong>${money(m.actuals.adr)}</strong><small>Contracted ${money(m.contracted.adr)} · variance ${signed(v.adr, true)}</small></div></div><p class="innovation-evidence">${v.pickupPct === null ? 'Pickup % unavailable without a positive contracted room-night figure.' : `${n(v.pickupPct)}% of declared contracted room nights actualized.`} Source: ${e(m.actualSource.name)} · as of ${e(m.actualSource.asOf)} · ${m.actuals.nightly.length} supplied nightly rows.</p>${m.outcome ? `<p><b>Previous outcome:</b> ${e(m.outcome)}</p>` : ''}${m.preferences ? `<p><b>Business preferences:</b> ${e(m.preferences)}</p>` : ''}${m.serviceNotes ? `<p><b>Service follow-through:</b> ${e(m.serviceNotes)}</p>` : ''}<p class="muted">Linked source: ${e(m.source.label || m.source.kind)}</p>${m.source.id ? `<details class="rb-source-detail"><summary>Source reference</summary><p>${e(m.source.kind)} · ${e(m.source.id)}</p></details>` : ''}<p>${m.reminder.date ? `Reminder ${e(m.reminder.date)} · ${e(m.reminder.state)}` : 'No reminder scheduled.'}${m.reminder.windowStart ? ` Planning window ${e(m.reminder.windowStart)}${m.reminder.windowEnd ? ' to ' + e(m.reminder.windowEnd) : ''} (unconfirmed stay dates).` : ''}</p>${cycles.length ? `<details><summary>${cycles.length} next-cycle link${cycles.length === 1 ? '' : 's'}</summary>${cycles.map(c => `<p>${e(c.label)} · confirmed ${e(c.arrive)} to ${e(c.depart)} · opportunity ${e(c.bookingId)}</p>`).join('')}</details>` : ''}<div class="sc-actions innovation-actions">${button('edit', 'Edit reviewed closeout', m)}${m.actualSource.fileId ? button('source', 'Download actual source', m) : ''}${button('reminder', 'Plan reminder', m)}${button('cycle', 'Create next-cycle prospect', m)}</div></article>`;
  }
  function weeklyHighlights(range) {
    if (!range || !validRepeatDate(range.start) || !validRepeatDate(range.end)) return [];
    const seen = new Set(), rows = [];
    for (const m of data().memories) {
      if (m.propertyId !== pid() || seen.has(m.id)) continue;
      const date = m.actualSource.reviewedDate || (m.actualSource.reviewedAt ? (() => { const d = new Date(m.actualSource.reviewedAt); return Number.isFinite(d.valueOf()) ? `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}` : ''; })() : '');
      if (!validRepeatDate(date) || date < range.start || date > range.end) continue;
      seen.add(m.id); const v = repeatVariance(m);
      rows.push(`Closeout reviewed ${date}: ${m.event} / ${m.account}; PAST stay ${m.arrive} to ${m.depart}. Actual room nights ${n(m.actuals.rn)} (declared contracted ${n(m.contracted.rn)}; variance ${signed(v.rn)}); actual room revenue ${money(m.actuals.revenue)} (declared contracted ${money(m.contracted.revenue)}; variance ${signed(v.revenue, true)}); actual ADR ${money(m.actuals.adr)}. Source ${m.actualSource.name}, as of ${m.actualSource.asOf}. This is a closeout review, not a new completed call or current-week stay production.`);
    }
    return rows;
  }
  function view() {
    const due = queue();
    return `<section class="sc-page innovation-page rb-page"><article class="sc-card innovation-hero"><span class="sc-eyebrow">REMEMBER THE WORK. RE-EARN THE BUSINESS.</span><h2>Repeat Business Memory</h2><p>Close out a past group with reviewed actual production. Keep the organizer’s business preferences and plan your next conversation without treating last year’s booking as this year’s commitment.</p><div class="sc-actions innovation-actions">${button('new', 'Review a past-group closeout')}</div><p class="muted">No guest roster, payment data or sensitive guest notes. Keep business contact and service information only.</p></article><article class="sc-card" id="rb-reminder-queue"><h3>Ready to reconnect <span class="sc-badge">${due.length}</span></h3><p class="muted">Local reminders appear when this app is open. No background notifications, calls or emails are sent.</p>${due.map(m => `<div class="rb-reminder"><strong>${e(m.event)}</strong><span>${e(m.account)} · due ${e(m.reminder.date)}</span>${button('cycle', 'Review new dates', m)}${button('reminder', 'Reschedule', m)}</div>`).join('') || '<p>No due reminders at this hotel. Set a planning window and reminder date on a closeout.</p>'}</article><div class="innovation-grid rb-grid">${data().memories.filter(m => m.propertyId === pid()).slice().sort((a, b) => b.depart.localeCompare(a.depart)).map(card).join('') || '<article class="sc-card rb-empty"><h3>Start with one completed group</h3><p>Choose its old opportunity or contract, then enter actual production from your reviewed stayed-production source. Contracted room nights do not fill actuals automatically.</p></article>'}</div></section>`;
  }
  function openCloseout(id) {
    const m = data().memories.find(m => m.id === id && m.propertyId === pid());
    context = { kind: 'closeout', propertyId: pid(), memoryId: m?.id || '', baseJSON: m ? JSON.stringify(m) : '', sourceFingerprint: '', sourceKind: m?.source.kind || 'manual', sourceId: m?.source.id || '' }; csvProduction = m?.actuals.nightly || []; csvSource = m?.actualSource || null;
    const d = m || {}, a = d.actuals || {}, c = d.contracted || {};
    SC.modal(`<section class="sc-card rb-dialog"><h2>${m ? 'Update' : 'Review'} past-group closeout</h2><form id="rb-closeout-form"><div class="sc-grid">${field('Link a past group / opportunity or contract', `<select name="linkedSource" id="rb-source">${sourceOptions().map(o => `<option value="${e(o.value)}"${o.value === context.sourceKind + ':' + context.sourceId ? ' selected' : ''}>${e(o.name)}</option>`).join('')}</select>`)}${field('Event / group name', input('event', d.event, 'required maxlength="300"'))}${field('Company / account', input('account', d.account, 'required maxlength="300"'))}${field('Organizer / business contact', input('organizer', d.organizer, 'maxlength="200"'))}${field('Business email', input('email', d.email, 'type="email" maxlength="254"'))}${field('Business phone', input('phone', d.phone, 'type="tel" maxlength="80"'))}${field('Segment', input('segment', d.segment, 'maxlength="120"'))}${field('Past arrival', input('arrive', d.arrive, 'type="date" required'))}${field('Past checkout', input('depart', d.depart, 'type="date" required'))}</div><h3>Declared / contracted comparison</h3><p>These figures are context, never actual production. Review any prefilled source values.</p><div class="sc-grid">${field('Contracted room nights (unknown may stay blank)', input('contractedRn', c.rn, 'type="number" min="0" step="1"'))}${field('Contracted room revenue', input('contractedRevenue', c.revenue, 'type="number" min="0" step="0.01"'))}${field('Contracted ADR', input('contractedAdr', c.adr, 'type="number" min="0" step="0.01"'))}</div><h3>Reviewed actual production</h3><p>Enter actuals from a stayed-production source. Blank means unknown; explicit 0 means a reported zero.</p><div class="sc-actions">${field('Optional actual-production CSV', '<input id="rb-actual-csv" type="file" accept=".csv,text/csv">')}<span id="rb-csv-status" role="status">${a.nightly?.length || 0} supplied nightly pickup rows.</span></div><div class="sc-grid">${field('Actual room nights', input('actualRn', a.rn, 'type="number" min="0" step="1"'))}${field('Actual room revenue', input('actualRevenue', a.revenue, 'type="number" min="0" step="0.01"'))}${field('Actual ADR (optional; checked against totals)', input('actualAdr', a.adr, 'type="number" min="0" step="0.01"'))}${field('Actual source / report name', input('sourceName', d.actualSource?.name, 'required maxlength="500"'))}${field('Report as of', input('asOf', d.actualSource?.asOf, 'type="date" required'))}</div><p class="muted">CSV accepts one summary row with Actual room nights / Actual room revenue, or dated nightly rows with Date, Room nights, Room revenue. Supply every occupied night, including explicit zero nights, or use a complete summary row. No missing night is invented.</p>${field('Outcome / what to change next time', area('outcome', d.outcome))}${field('Organizer’s business preferences', area('preferences', d.preferences))}${field('Service follow-through (work notes only)', area('serviceNotes', d.serviceNotes))}<label class="rb-confirm"><input type="checkbox" name="reviewed" required> I reviewed these actual figures and source coverage. Contracted figures are not evidence of actual pickup.</label><div class="sc-actions"><button class="btn pri" type="submit">Save reviewed closeout</button>${button('close', 'Cancel')}</div><p class="rb-error" role="alert"></p></form></section>`);
    if (m && m.source.kind !== 'manual') context.sourceFingerprint = JSON.stringify(sourceIn(SC.state, m.source.kind, m.source.id, pid()));
  }
  function memory(id) { const m = data().memories.find(m => m.id === id && m.propertyId === pid()); if (!m) throw Error('This memory is not available in the current hotel.'); return m; }
  function openReminder(id) {
    const m = memory(id), r = m.reminder; context = { kind: 'reminder', propertyId: pid(), memoryId: id, baseJSON: JSON.stringify(m) };
    SC.modal(`<section class="sc-card rb-dialog"><h2>Plan the next conversation</h2><p>${e(m.event)} · ${e(m.account)}. A planning window is not a confirmed booking.</p><form id="rb-reminder-form"><div class="sc-grid">${field('Planning window begins (optional)', input('windowStart', r.windowStart, 'type="date"'))}${field('Planning window ends (optional)', input('windowEnd', r.windowEnd, 'type="date"'))}${field('Lead days before that window', input('leadDays', r.leadDays, 'type="number" min="0" max="730" step="1" required'))}${field('Reminder date', input('date', r.date, 'type="date" required'))}</div>${button('suggest-date', 'Suggest reminder from planning window')}<p class="muted">You choose and save the date. Reminders are shown while this app is open; there is no background scheduler.</p><div class="sc-actions"><button class="btn pri" type="submit">Save reminder</button>${button('close', 'Cancel')}</div><p class="rb-error" role="alert"></p></form></section>`);
  }
  async function downloadSource(id) {
    const propertyId = pid(), m = memory(id); guard(propertyId);
    const file = await db.files.get(m.actualSource.fileId); guard(propertyId);
    if (!file || file.propertyId !== propertyId || m.actualSource.hash && file.hash !== m.actualSource.hash) throw Error('The original actual-production source is unavailable or changed. Review File Inbox or restore a known backup.');
    SC.download(file.blob, file.name || 'actual-production-source.csv');
  }
  function openCycle(id) {
    const m = memory(id); context = { kind: 'cycle', propertyId: pid(), memoryId: id, baseJSON: JSON.stringify(m) };
    SC.modal(`<section class="sc-card rb-dialog"><h2>Re-earn this account</h2><p>Previous outcome: ${e(m.outcome || 'Not entered')}. Previous actual production: ${n(m.actuals.rn)} room nights; ${money(m.actuals.revenue)}. Old dates: ${e(m.arrive)} to ${e(m.depart)}.</p><form id="rb-cycle-form">${field('Next event / season name', input('label', '', 'required maxlength="200" placeholder="2027 regional tournament"'))}<div class="sc-grid">${field('Confirmed NEW arrival', input('arrive', '', 'type="date" required'))}${field('Confirmed NEW checkout', input('depart', '', 'type="date" required'))}</div>${field('Current notes / next step', area('notes', ''))}<label class="rb-confirm"><input name="confirmedNewDates" type="checkbox" required> The organizer confirmed these new dates. I am not carrying last year’s dates forward as fact.</label><p class="muted">Creates a fresh Prospect opportunity and a linked, not-contacted prospect. Old room counts, rates, revenue, contract clauses and signatures are not copied. Using the same cycle name twice does not create another opportunity.</p><div class="sc-actions"><button class="btn pri" type="submit">Create fresh opportunity & prospect</button>${button('close', 'Cancel')}</div><p class="rb-error" role="alert"></p></form></section>`);
  }
  async function loadCSV(file) {
    const ctx = context, propertyId = pid(); if (!ctx || ctx.kind !== 'closeout') return;
    guard(propertyId); if (!file.size || file.size > 2 * 1024 * 1024) throw Error('Use a nonempty actual-production CSV of at most 2 MB.');
    const csv = await file.text(); guard(propertyId); if (context !== ctx) throw Error('The closeout review changed. Reopen the source.');
    const parsed = parseActualCSV(csv);
    const [stored] = await SC.intakeFiles([file], { propertyId, contextView: 'repeatBusiness' }); guard(propertyId); if (context !== ctx) throw Error('The closeout changed while its original was saved. Reopen it.');
    if (!stored) throw Error('The original could not be retained. Review File Inbox before saving.');
    csvProduction = parsed.nightly; csvSource = { fileId: stored.id, hash: stored.hash };
    const form = document.getElementById('rb-closeout-form');
    for (const [name, value] of Object.entries({ actualRn: parsed.rn, actualRevenue: parsed.revenue, actualAdr: parsed.adr, sourceName: file.name })) form.elements[name].value = value ?? '';
    form.elements.reviewed.checked = false; document.getElementById('rb-csv-status').textContent = `${parsed.rows} reviewed source rows ready. Confirm the event dates, totals and as-of date before saving.`;
  }
  async function receiveFile(file, { propertyId = pid() } = {}) {
    guard(propertyId); if (busy) throw Error('Wait for the current closeout operation to finish.');
    if (!(file instanceof Blob) || !/\.csv$/i.test(file.name || '')) throw Error('Repeat Business actuals need a CSV summary or nightly report. Export the Excel report as CSV first.');
    busy = true;
    try { SC.navigate('repeatBusiness'); openCloseout(); await loadCSV(file); }
    finally { busy = false; }
  }
  function fail(error, form) { const msg = error?.message || String(error), el = form?.querySelector('.rb-error'); if (el) el.textContent = msg; SC.toast(msg); }
  async function submit(form) {
    const ctx = context; if (!ctx || !form.isConnected) throw Error('Reopen the latest Repeat Business form.'); guard(ctx.propertyId);
    const values = Object.fromEntries(new FormData(form));
    if (ctx.kind === 'closeout') {
      const [sourceKind, ...sourceId] = values.linkedSource.split(':');
      await closeout({ ...values, sourceKind, sourceId: sourceId.join(':'), sourceFingerprint: context.sourceFingerprint, reviewed: values.reviewed === 'on', nightly: csvProduction || [], fileId: csvSource?.fileId || '', hash: csvSource?.hash || '' }, ctx);
    } else if (ctx.kind === 'reminder') await planReminder(ctx.memoryId, values, ctx);
    else if (ctx.kind === 'cycle') {
      if (JSON.stringify(memory(ctx.memoryId)) !== ctx.baseJSON) throw Error('This memory changed. Reopen the new-cycle review.');
      const cycle = await createCycle(ctx.memoryId, { ...values, confirmedNewDates: values.confirmedNewDates === 'on' }, ctx); SC.toast(cycle.existing ? 'This planning cycle already has a linked opportunity. No duplicate was created.' : 'Fresh opportunity and not-contacted prospect created.');
    }
    if (context === ctx) { context = null; SC.closeModal(); SC.render(); }
  }
  document.addEventListener('click', event => {
    const b = event.target.closest('[data-rb-action]'); if (!b) return; event.preventDefault(); event.stopImmediatePropagation();
    if (busy) return; try {
      guard(pid()); const action = b.dataset.rbAction;
      if (action === 'new') openCloseout(); if (action === 'edit') openCloseout(b.dataset.id); if (action === 'reminder') openReminder(b.dataset.id); if (action === 'cycle') openCycle(b.dataset.id);
      if (action === 'source') { busy = true; void downloadSource(b.dataset.id).catch(error => fail(error)).finally(() => { busy = false; }); }
      if (action === 'close') { context = null; SC.closeModal(); }
      if (action === 'suggest-date') { const f = document.getElementById('rb-reminder-form'), d = f.elements.windowStart.value, lead = number(f.elements.leadDays.value, 'Lead days', { integer: true, max: 730 }); if (!validRepeatDate(d) || lead === null) throw Error('Choose a planning-window start and lead days first.'); f.elements.date.value = shiftDay(d, -lead); }
    } catch (error) { fail(error); }
  }, true);
  document.addEventListener('submit', event => {
    const form = event.target; if (!['rb-closeout-form', 'rb-reminder-form', 'rb-cycle-form'].includes(form.id)) return; event.preventDefault(); event.stopImmediatePropagation(); if (busy || !form.reportValidity()) return;
    busy = true; const b = form.querySelector('[type="submit"]'); b.disabled = true; void submit(form).catch(error => fail(error, form)).finally(() => { busy = false; b.disabled = false; });
  }, true);
  document.addEventListener('change', event => {
    if (event.target.id === 'rb-source') {
      try {
        const ctx = context; if (!ctx || ctx.propertyId !== pid()) throw Error('Hotel changed. Reopen this closeout.');
        const [kind, ...parts] = event.target.value.split(':'), id = parts.join(':'), defaults = sourceDefaults(kind, id), f = document.getElementById('rb-closeout-form');
        for (const key of ['event', 'account', 'organizer', 'phone', 'email', 'segment', 'arrive', 'depart', 'contractedRn', 'contractedRevenue', 'contractedAdr']) f.elements[key].value = defaults[key] ?? '';
        ctx.sourceKind = kind; ctx.sourceId = id; ctx.sourceFingerprint = defaults.fingerprint || ''; f.elements.reviewed.checked = false;
      } catch (error) { fail(error); }
    }
    if (event.target.id === 'rb-actual-csv' && event.target.files?.[0]) {
      if (busy) return; busy = true; void loadCSV(event.target.files[0]).catch(error => fail(error, document.getElementById('rb-closeout-form'))).finally(() => { busy = false; });
    }
  }, true);
  function announce() {
    const list = queue(), key = pid() + ':' + localDay(); if (!list.length || noticeKeys.has(key)) return; noticeKeys.add(key); SC.toast(`${list.length} repeat-business reminder${list.length === 1 ? '' : 's'} ready. Open Repeat Business Memory.`);
  }
  SC.registerView('repeatBusiness', 'Repeat Business Memory', 'Reviewed closeouts, business preferences and the next planning cycle', view, 'users');
  SC.repeatBusiness = { closeout, planReminder, createCycle, receiveFile, queue, weeklyHighlights, memories: () => structuredClone(data().memories.filter(m => m.propertyId === pid())), view, busy: () => busy, isBusy: () => busy };
  SC.salesReport?.registerProvider(range => ({ hl: weeklyHighlights(range), bt: [] }));
  const reset = () => { context = null; csvProduction = null; csvSource = null; announce(); };
  SC.on('propertychange', reset); SC.on('restore', reset); SC.on('navigate', () => { if (SC.view === 'repeatBusiness') announce(); });
  document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') announce(); });
  announce();
  return SC.repeatBusiness;
}
