// Deliberately maps fixed fields; source headers are never executable object paths.
export const PROSPECT_FIELDS=[['account','Company / account'],['contact','Contact / name'],['email','Email'],['phone','Phone'],['arrive','Arrival date'],['depart','Departure date'],['nextStep','Next step'],['nextDate','Follow-up date'],['notes','Notes']];
export const BT_FIELDS=[['account','Account / segment'],['rn','Current room nights'],['revenue','Current room revenue'],['adr','Current ADR (optional)'],['lyRn','Comparison room nights'],['lyRevenue','Comparison revenue']];
const normalize=s=>String(s??'').toLowerCase().replace(/[^a-z0-9]/g,'');
const aliases={account:['account','company','companyname','business','organization','organisation','accountname','segment','segmentname'],contact:['contact','name','contactname','fullname','person'],email:['email','emailaddress','contactemail'],phone:['phone','phonenumber','telephone','mobile','contactphone'],arrive:['arrival','arrivaldate','arrive','checkin','checkindate','startdate'],depart:['departure','departuredate','depart','checkout','checkoutdate','enddate'],nextStep:['nextstep','nextsteps','action'],nextDate:['followup','followupdate','nextdate'],notes:['notes','comments','description'],rn:['rn','rns','roomnights','currentroomnights','actualroomnights','roomsold','roomssold','currentrn'],revenue:['revenue','roomrevenue','currentrevenue','actualrevenue','currentroomrevenue'],adr:['adr','currentadr','averagedailyrate'],lyRn:['lyrn','lyroomnights','lastyearroomnights','comparisonroomnights','priorroomnights','stlyrn','stlyroomnights','lastyearrn'],lyRevenue:['lyrevenue','lastyearrevenue','comparisonrevenue','priorrevenue','stlyrevenue','stlyroomrevenue','lyroomrevenue']};
export function guessMapping(headers,fields=PROSPECT_FIELDS){return Object.fromEntries(fields.map(([field])=>[field,headers.findIndex(h=>(aliases[field]||[]).includes(normalize(h)))]));}
export function parseTable(text){
  text=String(text).replace(/^\uFEFF/,'');if(text.length>2_000_000)throw Error('Use a table under 2 MB.');
  const first=text.split(/\r?\n/,1)[0];const delimiter=first.includes('\t')?'\t':first.split(';').length>first.split(',').length?';':',';
  const result=[];let row=[],cell='',quoted=false,closed=false;
  for(let i=0;i<text.length;i++){
    const c=text[i];
    if(c==='"'){if(quoted&&text[i+1]==='"'){cell+='"';i++;}else if(quoted){quoted=false;closed=true;}else if(!cell&&!closed)quoted=true;else throw Error('Unexpected quote. Export a fresh CSV or paste a tab-separated table.');}
    else if(!quoted&&(c===delimiter||c==='\n'||c==='\r')){row.push(cell);cell='';closed=false;if(c!==delimiter){if(c==='\r'&&text[i+1]==='\n')i++;if(row.some(v=>v.trim()))result.push(row);row=[];}}
    else {if(closed&&!/\s/.test(c))throw Error('Unexpected characters after a quoted cell.');cell+=c;}
    if(result.length>5000||row.length>100||cell.length>20000)throw Error('Import limit: 5,000 rows, 100 columns, 20,000 characters per cell.');
  }
  if(quoted)throw Error('The table has an unfinished quoted cell.');row.push(cell);if(row.some(v=>v.trim()))result.push(row);
  return matrixTable(result);
}
export function matrixTable(matrix){
  if(!Array.isArray(matrix)||matrix.length<2||matrix.length>5001)throw Error('Choose a table with a header and 1–5,000 data rows.');
  // Export reports often start with titles. Choose the first recognisable field row.
  let at=matrix.findIndex(r=>r.filter(v=>Object.values(aliases).flat().includes(normalize(v))).length>=2);if(at<0)at=0;
  const headers=matrix[at].map(v=>String(v??'').trim());
  if(!headers.length||headers.length>100)throw Error('Use no more than 100 columns.');
  if(headers.some(h=>h.length>200))throw Error('Header text is too long.');
  const rows=matrix.slice(at+1).filter(r=>r.some(v=>String(v??'').trim()));
  if(!rows.length)throw Error('No data rows follow the header.');
  if(rows.some(r=>r.length>headers.length&&r.slice(headers.length).some(v=>String(v??'').trim())))throw Error('Rows have extra columns. Check the table header.');
  return {headers:headers.map((h,i)=>h||`Column ${i+1}`),rows:rows.map(r=>headers.map((_,i)=>{const v=String(r[i]??'');if(v.length>20000)throw Error('A table cell exceeds 20,000 characters.');return v;})),headerRow:at+1};
}
export function workbookTables(book){
  return Object.entries(book.sheets||book).map(([name,cells])=>{
    const matrix=[];let count=0;
    for(const [key,value] of Object.entries(cells)){
      if(++count>50000)throw Error('Spreadsheet exceeds 50,000 cells. Split the workbook.');
      const m=key.match(/^([A-Z]+)([1-9]\d*)$/);if(!m)continue;
      let col=0;for(const c of m[1])col=col*26+c.charCodeAt(0)-64;const row=Number(m[2])-1;
      if(col>100||row>10000)throw Error('Spreadsheet table exceeds 100 columns or 10,000 row positions.');
      matrix[row]||=[];matrix[row][col-1]=value&&typeof value==='object'?value.v??'':value;
    }
    return {name,matrix:Array.from(matrix,r=>r||[])};
  });
}
export function dateValue(value,format='ISO'){
  const s=String(value??'').trim();if(!s)return '';
  let iso=s;
  if(['MDY','DMY'].includes(format)){const m=s.match(/^(\d{1,2})[\/.-](\d{1,2})[\/.-](\d{4})$/);if(m){const month=format==='MDY'?m[1]:m[2],day=format==='MDY'?m[2]:m[1];iso=`${m[3]}-${month.padStart(2,'0')}-${day.padStart(2,'0')}`;}}
  if(/^\d{5}(?:\.0+)?$/.test(s)){const serial=Number(s);if(serial<20000||serial>100000)throw Error('Confirm this Excel date.');iso=new Date(Date.UTC(1899,11,30)+serial*86400000).toISOString().slice(0,10);}
  if(!/^\d{4}-\d{2}-\d{2}$/.test(iso)||new Date(iso+'T00:00:00Z').toISOString().slice(0,10)!==iso)throw Error('Use full dates as YYYY-MM-DD. Ambiguous slash dates require correction in the source.');
  return iso;
}
export function mappedProspects(table,mapping,{dateFormat='ISO'}={}){
  const used=PROSPECT_FIELDS.map(([k])=>Number(mapping[k])).filter(n=>Number.isInteger(n)&&n>=0);if(new Set(used).size!==used.length)throw Error('Map each source column to only one field.');
  return table.rows.map((row,i)=>{
    const out={sourceId:`row:${i+table.headerRow+1}`};for(const [key]of PROSPECT_FIELDS){const n=Number(mapping[key]);out[key]=Number.isInteger(n)&&n>=0&&n<table.headers.length?String(row[n]??'').trim():'';}
    if(!out.account&&!out.contact)throw Error(`Row ${i+2}: map a company or contact name.`);
    if(out.email&&!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(out.email))throw Error(`Row ${i+2}: review the email address.`);
    for(const k of ['arrive','depart','nextDate'])out[k]=dateValue(out[k],dateFormat);
    if(out.arrive&&out.depart&&out.depart<=out.arrive)throw Error(`Row ${i+2}: departure must be after arrival.`);
    return out;
  });
}
export function nonnegative(value,label,{optional=false,integer=false}={}){
  const s=String(value??'').trim();if(!s){if(optional)return null;throw Error(`${label} is missing.`);}
  if(!/^(?:\$\s*)?(?:\d{1,3}(?:,\d{3})+|\d+)(?:\.\d+)?$/.test(s))throw Error(`${label} must be an explicit nonnegative number.`);
  const n=Number(s.replace(/[$,\s]/g,''));if(!Number.isFinite(n)||n>1e12||integer&&!Number.isInteger(n))throw Error(`${label} is out of range${integer?' or not a whole room-night count':''}.`);return n;
}
export function mappedBT(table,mapping){
  if(Number(mapping.account)<0||Number(mapping.rn)<0||Number(mapping.revenue)<0)throw Error('Map account / segment, current room nights, and current room revenue.');
  const used=BT_FIELDS.map(([k])=>Number(mapping[k])).filter(n=>n>=0);if(new Set(used).size!==used.length)throw Error('Map each source column once.');
  const seen=new Set();return table.rows.map((row,i)=>{
    const val=k=>row[Number(mapping[k])]??'',account=String(val('account')).trim();
    if(!account)throw Error(`Row ${i+2}: account / segment is blank.`);
    if(/^(grand\s*)?total(?:\s|$)/i.test(account))return null;
    const key=normalize(account);if(seen.has(key))throw Error(`Duplicate account / segment '${account}'. Filter the source to one row per account before importing.`);seen.add(key);
    const rn=nonnegative(val('rn'),`${account} room nights`,{integer:true}),revenue=nonnegative(val('revenue'),`${account} revenue`),lyRn=nonnegative(val('lyRn'),`${account} comparison room nights`,{optional:true,integer:true}),lyRevenue=nonnegative(val('lyRevenue'),`${account} comparison revenue`,{optional:true});
    const adr=rn?revenue/rn:0;if(!rn&&revenue)throw Error(`${account}: revenue exists but room nights are zero. Review the mapping.`);
    if(Number(mapping.adr)>=0){const sourceADR=nonnegative(val('adr'),`${account} ADR`,{optional:true});if(sourceADR!==null&&Math.abs(adr-sourceADR)>Math.max(1,adr*.02))throw Error(`${account}: ADR disagrees with revenue / room nights. Review the columns.`);}
    return {account,rn,revenue,adr,lyRn,lyRevenue};
  }).filter(Boolean);
}
export function btSummary(row,period,comparison='Same period last year'){
  const money=n=>new Intl.NumberFormat('en-US',{style:'currency',currency:'USD',maximumFractionDigits:2}).format(n);
  let text=`${row.account} · ${period.start} to ${period.end}: ${row.rn} room nights; room revenue ${money(row.revenue)}; ADR ${money(row.adr)}.`;
  if(row.lyRn!==null){const diff=row.rn-row.lyRn;text+=` ${comparison}: ${row.lyRn} room nights (${diff>=0?'+':''}${diff}${row.lyRn?`, ${(diff/row.lyRn*100).toFixed(1)}%`:', percentage unavailable from zero baseline'}).`;}
  if(row.lyRevenue!==null){const delta=row.revenue-row.lyRevenue;text+=` Comparison revenue ${money(row.lyRevenue)}; revenue change ${delta>=0?'+':''}${money(delta)}${row.lyRevenue?` (${(delta/row.lyRevenue*100).toFixed(1)}%)`:' (percentage unavailable from zero baseline)'}.`;if(row.lyRn>0)text+=` Comparison ADR ${money(row.lyRevenue/row.lyRn)}.`;}return text;
}
