export const PROSPECT_STATUSES=['New','Contacted','Follow-up','Qualified','Proposal','Won','Lost','Do not contact'];
export const cleanText=(v,max=2000)=>typeof v==='string'||typeof v==='number'?String(v).trim().slice(0,max):'';
export const normalizedName=v=>cleanText(v,500).normalize('NFKC').toLocaleLowerCase('en-US').replace(/\s+/g,' ');
export function validISODate(value){if(typeof value!=='string'||!/^\d{4}-\d{2}-\d{2}$/.test(value))return false;const d=new Date(value+'T00:00:00Z');return Number.isFinite(d.getTime())&&d.toISOString().slice(0,10)===value;}
export function normalizeProspect(row={}){
  const account=cleanText(row.account||row.company||row.name,300),contact=cleanText(row.contact||row.contactName,200),email=cleanText(row.email,254),phone=cleanText(row.phone,80);
  if(!account&&!contact&&!email)throw Error('A prospect needs a company, contact name or email.');
  if(email&&!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))throw Error('Check the prospect email address.');
  const arrive=cleanText(row.arrive||row.arrival,10),depart=cleanText(row.depart||row.departure,10),nextDate=cleanText(row.nextDate||row.followUp,10);
  for(const [label,d]of [['Arrival',arrive],['Departure',depart],['Next step date',nextDate]])if(d&&!validISODate(d))throw Error(label+' needs a full YYYY-MM-DD date.');
  if(arrive&&depart&&depart<=arrive)throw Error('Prospect departure must be after arrival.');
  return {account,contact,email,phone,arrive,depart,nextStep:cleanText(row.nextStep||row.nextSteps),nextDate,notes:cleanText(row.notes,20000),status:PROSPECT_STATUSES.includes(row.status)?row.status:'New'};
}
export function prospectSourceKey(row,source={}){
  const sourceRoot=cleanText(source.hash||source.id||source.fileId||source.name||'manual',500),rowId=cleanText(row.sourceId||row.externalId||row.id,500);
  const identity=[row.account||row.company||row.name,row.contact,row.email,row.phone,row.arrive||row.arrival,row.depart||row.departure].map(normalizedName).join('|');
  return sourceRoot+'::'+(rowId||identity);
}
export function findProspectDuplicates(rows){
  const buckets=new Map(),pairs=new Map();
  for(const r of rows){const scope=String(r.propertyId||''),keys=[],email=normalizedName(r.email),phone=String(r.phone||'').replace(/\D/g,'').replace(/^1(?=\d{10}$)/,'');
    if(email)keys.push(['email:'+email,'Same email']);if(phone.length>=7)keys.push(['phone:'+phone,'Same phone']);if(r.account)keys.push(['name:'+normalizedName(r.account)+'|'+normalizedName(r.contact),'Same company and contact']);
    for(const [key,reason]of keys){const scoped=scope+'::'+key,prior=buckets.get(scoped)||[];
      for(const other of prior){if(other.id===r.id)continue;const id=[String(other.id),String(r.id)].sort().join('::');if(!pairs.has(id))pairs.set(id,{leftId:other.id,rightId:r.id,reasons:[],warning:'Potential match only. A shared contact can represent different accounts; no records were merged.'});const match=pairs.get(id);if(!match.reasons.includes(reason))match.reasons.push(reason);}
      prior.push(r);buckets.set(scoped,prior);
    }if(pairs.size>=100)return [...pairs.values()].slice(0,100);
  }return [...pairs.values()];
}
const inRange=(date,start,end)=>validISODate(date)&&date>=start&&date<=end;
const dateOf=r=>[r.receivedDate,r.date,r.identifiedDate,r.created].find(validISODate)||'';
export function buildWeeklyItems({activities=[],rfps=[],bookings=[],bt=[],workflows={},propertyId,start,end}={}){
  if(!validISODate(start)||!validISODate(end)||end<start)throw Error('Choose a valid report period.');
  const items=new Map(),activityKeys=new Map(),canonical=new Map();
  const add=(item,isPin=false)=>{if(item.planned||item.propertyId&&item.propertyId!==propertyId)return;if(!isPin)canonical.set(item.key,item);if(!inRange(item.date,start,end))return;if(!items.has(item.key))items.set(item.key,item);};
  for(const a of activities){if(a.propertyId&&a.propertyId!==propertyId)continue;if(a.planned&&!a.done)continue;const key=a.source?.salesKey||'activity:'+a.id,label=a.source?.workflowKind==='tour'?cleanText(a.notes||'Site tour',100).split('\n')[0]:({prospecting:'Prospecting call',existing:'Existing account call',networking:'Networking',tour:'Site tour',rfp:'RFP / inquiry',followup:'Follow-up',other:'Sales activity'}[a.type]||'Sales activity');activityKeys.set(a.id,key);add({key,date:a.date,kind:a.type||'activity',account:cleanText(a.account),contact:cleanText(a.contact),summary:`${a.date}: ${label} — ${cleanText(a.account||a.contact||'Account not entered')}: ${cleanText(a.outcome||a.notes||a.type,2000)}`,sourceId:a.sourceId||a.id,activityId:a.id,propertyId:a.propertyId,planned:false});}
  for(const [kind,list]of [['tour',workflows.tours||[]],['networking',workflows.networking||[]]])for(const r of list){if(r.status!=='Completed'||r.activityId)continue;const key=r.activityId&&activityKeys.get(r.activityId)||'workflow:'+kind+':'+r.id;add({key,date:r.date,kind,account:r.account||r.organization||r.event||'',contact:r.contact||'',summary:`${r.date}: ${kind==='tour'?r.direction+' tour':'Networking'} — ${r.account||r.organization||r.event||r.contact||'Meeting'}${r.outcome?': '+r.outcome:''}${r.nextStep?'; next: '+r.nextStep:''}`,sourceId:r.sourceId||r.id,activityId:r.activityId,propertyId:r.propertyId,planned:false});}
  for(const r of workflows.prospects||[]){if(r.packageSourceKey&&(activities.some(a=>a.source?.salesKey===r.packageSourceKey&&!(a.planned&&!a.done)&&(!a.propertyId||a.propertyId===propertyId))||(workflows.reportPins||[]).some(p=>p.item?.key==='manual:'+r.packageSourceKey&&inRange(p.item.date,start,end))))continue;if(r.sourceKind==='Reviewed call'&&r.contactActivityId&&activities.some(a=>a.id===r.contactActivityId&&(!a.propertyId||a.propertyId===propertyId)))continue;if(r.sourceKind==='Reviewed RFP'&&rfps.some(x=>'rfp:'+x.id===r.sourceKey&&(!x.propertyId||x.propertyId===propertyId)))continue;const date=r.identifiedDate;if(!date)continue;add({key:'prospect:'+r.id,date,kind:'prospect',account:r.account,contact:r.contact,summary:`${date}: Prospect identified — ${r.account||r.contact}; ${r.status||'New'}${r.nextStep?'; next: '+r.nextStep:''}. Identification is not a completed contact.`,sourceId:r.sourceId||r.id,propertyId:r.propertyId,planned:false});}
  for(const r of rfps){if(r.propertyId&&r.propertyId!==propertyId)continue;const date=dateOf(r);if(!date)continue;const linked=activities.find(a=>a.type==='rfp'&&!(a.planned&&!a.done)&&(!a.propertyId||a.propertyId===propertyId)&&(a.source?.rfpId===r.id||a.sourceId==='rfp:'+r.id||a.source?.salesRfpId===r.id||r.sourceId&&a.sourceId===r.sourceId));if(linked)continue;const key='rfp:'+r.id;add({key,date,kind:'rfp',account:r.account||r.name,contact:r.contact,summary:`${date}: RFP / inquiry — ${r.name||r.account}; ${r.status||'Received'}${r.due?'; due '+r.due:''}.`,sourceId:r.id,activityId:linked?.id,propertyId:r.propertyId,planned:false});}
  // Manual sends preserve actual source dates and stable keys; they cannot move work into another week.
  for(const pin of workflows.reportPins||[])if(pin.reportEnd===end||pin.item?.key?.startsWith('manual:deal-package:')&&inRange(pin.item.date,start,end)){const latest=canonical.get(pin.item.key);if(latest)add({...latest,manual:true},true);else if(/^(?:manual|booking|bt):/.test(pin.item.key))add({...pin.item,manual:true},true);}
  return [...items.values()].sort((a,b)=>a.date.localeCompare(b.date)||a.key.localeCompare(b.key));
}
