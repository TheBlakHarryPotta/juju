import Dexie from 'dexie';

const TABLES = ['properties', 'snapshots', 'files', 'records', 'production', 'settings'];
const encoder = new TextEncoder();
const MAX_BACKUP_BYTES = 512 * 1024 * 1024;
const forbiddenKeys = new Set(['__proto__', 'prototype', 'constructor']);
const clone = value => structuredClone(value);

function assertSafe(value, depth = 0) {
  if (depth > 80) throw new Error('Backup data is nested too deeply.');
  if (!value || typeof value !== 'object' || value instanceof Blob || value instanceof ArrayBuffer || ArrayBuffer.isView(value)) return;
  for (const key of Object.keys(value)) {
    if (forbiddenKeys.has(key)) throw new Error('Backup contains an unsafe field name.');
    assertSafe(value[key], depth + 1);
  }
}
function base64(bytes) {
  let result = '';
  for (let i = 0; i < bytes.length; i += 32768) result += String.fromCharCode(...bytes.subarray(i, i + 32768));
  return btoa(result);
}
function unbase64(value) {
  if (typeof value !== 'string' || value.length > MAX_BACKUP_BYTES * 1.4 || !/^[A-Za-z0-9+/]*={0,2}$/.test(value)) throw new Error('Invalid backup encoding.');
  return Uint8Array.from(atob(value), ch => ch.charCodeAt(0));
}
async function encodeBinary(value) {
  if (value instanceof Blob) return { __scBinary: 'blob', type: value.type, bytes: base64(new Uint8Array(await value.arrayBuffer())) };
  if (value instanceof ArrayBuffer) return { __scBinary: 'arraybuffer', bytes: base64(new Uint8Array(value)) };
  if (ArrayBuffer.isView(value)) return { __scBinary: 'uint8array', bytes: base64(new Uint8Array(value.buffer, value.byteOffset, value.byteLength)) };
  if (Array.isArray(value)) return Promise.all(value.map(encodeBinary));
  if (value && typeof value === 'object') {
    if (value instanceof Date) return { __scDate: value.toISOString() };
    return Object.fromEntries(await Promise.all(Object.entries(value).map(async ([key, item]) => [key, await encodeBinary(item)])));
  }
  return value;
}
function decodeBinary(value) {
  if (!value || typeof value !== 'object') return value;
  if (value.__scBinary) {
    const bytes = unbase64(value.bytes);
    if (value.__scBinary === 'blob') return new Blob([bytes], { type: value.type || '' });
    if (value.__scBinary === 'arraybuffer') return bytes.buffer;
    if (value.__scBinary === 'uint8array') return bytes;
    throw new Error('Unsupported binary format in backup.');
  }
  if (value.__scDate) return new Date(value.__scDate);
  if (Array.isArray(value)) return value.map(decodeBinary);
  return Object.fromEntries(Object.entries(value).map(([key, item]) => [key, decodeBinary(item)]));
}
async function deriveKey(passphrase, salt, iterations) {
  if (typeof passphrase !== 'string' || passphrase.length < 12) throw new Error('Use a backup passphrase with at least 12 characters. Keep it somewhere safe; it cannot be reset.');
  const material = await crypto.subtle.importKey('raw', encoder.encode(passphrase), 'PBKDF2', false, ['deriveKey']);
  return crypto.subtle.deriveKey({ name: 'PBKDF2', salt, iterations, hash: 'SHA-256' }, material, { name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']);
}

/** Local durable data. capture() must run synchronously when save is requested. */
export function initStorage(SC) {
  const db = new Dexie('sales-command-local-v1');
  db.version(1).stores({
    properties: '&id', snapshots: '&id,updatedAt', files: '&id,propertyId,hash,createdAt',
    records: '&id,propertyId,type,updatedAt', production: '&id,propertyId,periodStart,periodEnd', settings: '&id'
  });
  const revisions = new Map();
  const pending = new Map();
  const status = { state: 'opening', message: 'Opening local storage', error: null, conflicts: new Map() };
  let queue = Promise.resolve();
  let timer;
  let restoring = false;
  const notify = () => window.dispatchEvent(new CustomEvent('sc-storage-status', { detail: { state: status.state, message: status.message } }));
  const fail = error => { status.state = 'error'; status.message = error.message || 'Local save failed'; status.error = error; notify(); };
  const registry = () => clone(SC.registry || { active: SC.propertyId, list: [{ id: SC.propertyId }] });
  const snapshotNow = () => {
    const id = String(SC.propertyId || 'h0');
    const state = clone(SC.state);
    assertSafe(state);
    return { id, state, registry: registry(), updatedAt: Date.now() };
  };
  const ready = (async () => {
    await db.open();
    const storedRegistry = await db.settings.get('property-registry');
    if (storedRegistry?.value?.list?.length) SC.setRegistry?.(clone(storedRegistry.value));
    const currentRegistry = registry();
    await db.transaction('rw', db.properties, db.snapshots, db.settings, async () => {
      for (const property of currentRegistry.list || []) {
        if (!property.id) continue;
        if (!(await db.properties.get(property.id))) await db.properties.put(clone(property));
        if (!(await db.snapshots.get(property.id))) {
          let imported;
          const legacyKey = property.id === 'h0' ? 'scc.v1' : 'scc.v1.' + property.id;
          try { imported = JSON.parse(localStorage.getItem(legacyKey) || 'null'); } catch { /* preserve malformed legacy data untouched */ }
          if (property.id === SC.propertyId && !imported) imported = clone(SC.state);
          if (imported && imported.settings) {
            assertSafe(imported);
            await db.snapshots.put({ id: property.id, state: imported, revision: 1, updatedAt: Date.now() });
          }
        }
      }
      if (!(await db.settings.get('property-registry'))) await db.settings.put({ id: 'property-registry', value: currentRegistry });
    });
    for (const row of await db.snapshots.toArray()) revisions.set(row.id, row.revision || 0);
    const latest = await db.snapshots.get(String(SC.propertyId || 'h0'));
    if (latest?.state && !pending.has(latest.id)) { SC.setState(clone(latest.state)); SC.render?.(); }
    status.state = 'saved'; status.message = 'Saved on this device'; notify();
    return db;
  })().catch(error => { fail(error); throw error; });

  function capture() {
    if (restoring) throw new Error('Wait for backup restore to finish before editing.');
    const item = snapshotNow();
    pending.set(item.id, item);
    status.state = 'pending'; status.message = 'Saving on this device'; notify();
    clearTimeout(timer);
    timer = setTimeout(() => { flush().catch(() => {}); }, 180);
    return item.id;
  }
  function flush() {
    clearTimeout(timer);
    const operation = async () => {
      await ready;
      const batch = [...pending.values()];
      for (const item of batch) {
        try {
          await db.transaction('rw', db.snapshots, db.properties, db.settings, async () => {
            const previous = await db.snapshots.get(item.id);
            const expected = revisions.get(item.id) || 0;
            if ((previous?.revision || 0) !== expected) {
              status.conflicts.set(item.id, clone(item));
              throw new Error('Another tab saved newer changes for this hotel. Your unsaved copy is kept in this tab. Export a backup before reloading; no newer data was overwritten.');
            }
            const revision = expected + 1;
            await db.snapshots.put({ id: item.id, state: item.state, revision, updatedAt: item.updatedAt });
            for (const property of item.registry.list || []) if (property.id) await db.properties.put(clone(property));
            await db.settings.put({ id: 'property-registry', value: item.registry });
            revisions.set(item.id, revision);
          });
          if (pending.get(item.id) === item) pending.delete(item.id);
        } catch (error) { fail(error); throw error; }
      }
      if (!pending.size) { status.state = 'saved'; status.message = 'Saved on this device'; status.error = null; notify(); }
    };
    queue = queue.catch(() => {}).then(operation);
    return queue;
  }
  async function commitPropertyState({propertyId,expectedStateJSON,nextState}) {
    const id=String(propertyId);await ready;await flush();
    const check=()=>{if(restoring)throw Error('Wait for backup restore to finish.');if(SC.propertyId!==id||JSON.stringify(SC.state)!==expectedStateJSON)throw Error('The hotel or sales records changed. Review the latest values before saving.');};
    check();const next=clone(nextState);assertSafe(next);if(!next.settings||typeof next.settings!=='object')throw Error('Invalid hotel state.');
    const expected=revisions.get(id)||0,revision=expected+1;
    try{
      await db.transaction('rw',db.snapshots,async()=>{
        const previous=await db.snapshots.get(id);check();
        if((previous?.revision||0)!==expected)throw Error('Another tab saved newer hotel data. Reload before applying this review.');
        await db.snapshots.put({id,state:next,revision,updatedAt:Date.now()});check();
      });
      revisions.set(id,revision);status.state='saved';status.message='Linked sales records saved on this device';status.error=null;notify();return next;
    }catch(error){fail(error);throw error;}
  }
  async function loadProperty(id) {
    await flush();
    const row = await db.snapshots.get(String(id));
    if (row) revisions.set(String(id), row.revision || 0);
    return row?.state ? clone(row.state) : null;
  }
  async function backup(passphrase) {
    await ready;
    // If a stale-tab conflict exists, preserve that tab's edits in recoveryCopies.
    if (!status.conflicts.size) await flush();
    const payload = { format: 'sales-command-data', version: 1, createdAt: new Date().toISOString(), tables: {}, recoveryCopies: [...new Map([...pending.entries(), ...status.conflicts.entries()]).values()] };
    await db.transaction('r', TABLES.map(name => db.table(name)), async () => {
      for (const name of TABLES) payload.tables[name] = await db.table(name).toArray();
    });
    const bytes = encoder.encode(JSON.stringify(await encodeBinary(payload)));
    if (bytes.length > MAX_BACKUP_BYTES) throw new Error('This backup is too large for a browser export. Remove unneeded recordings after saving separate copies.');
    const salt = crypto.getRandomValues(new Uint8Array(16));
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const iterations = 310000;
    const key = await deriveKey(passphrase, salt, iterations);
    const ciphertext = await crypto.subtle.encrypt({ name: 'AES-GCM', iv, additionalData: encoder.encode('sales-command-backup-v1') }, key, bytes);
    return new Blob([JSON.stringify({ format: 'sales-command-encrypted', version: 1, kdf: 'PBKDF2-SHA256', iterations, cipher: 'AES-256-GCM', salt: base64(salt), iv: base64(iv), ciphertext: base64(new Uint8Array(ciphertext)) })], { type: 'application/json' });
  }
  async function restore(envelope, passphrase) {
    await ready;
    if (restoring) throw new Error('A restore is already running.');
    if (SC.hasActiveJobs?.()) throw new Error('Wait for file processing, recording, transcription and document operations to finish before restoring a backup.');
    let value;
    if (envelope instanceof Blob) {
      if (envelope.size > MAX_BACKUP_BYTES * 1.5) throw new Error('Backup file is too large.');
      value = JSON.parse(await envelope.text());
    } else value = typeof envelope === 'string' ? JSON.parse(envelope) : envelope;
    if (!value || value.format !== 'sales-command-encrypted' || value.version !== 1 || value.kdf !== 'PBKDF2-SHA256' || value.cipher !== 'AES-256-GCM' || value.iterations !== 310000) throw new Error('Unsupported backup format.');
    const salt = unbase64(value.salt), iv = unbase64(value.iv);
    if (salt.length !== 16 || iv.length !== 12) throw new Error('Invalid backup encryption metadata.');
    const key = await deriveKey(passphrase, salt, value.iterations);
    let decrypted;
    try { decrypted = await crypto.subtle.decrypt({ name: 'AES-GCM', iv, additionalData: encoder.encode('sales-command-backup-v1') }, key, unbase64(value.ciphertext)); }
    catch { throw new Error('The passphrase is incorrect or this backup was changed. No data was restored.'); }
    if (decrypted.byteLength > MAX_BACKUP_BYTES) throw new Error('Backup contents are too large.');
    const decoded = JSON.parse(new TextDecoder().decode(decrypted));
    assertSafe(decoded);
    if (decoded.format !== 'sales-command-data' || decoded.version !== 1 || !decoded.tables) throw new Error('Invalid backup contents.');
    const tables = decodeBinary(decoded.tables);
    for (const name of TABLES) {
      if (!Array.isArray(tables[name]) || tables[name].some(row => !row || typeof row.id !== 'string' || !row.id)) throw new Error('Invalid records in backup table: ' + name);
      if (new Set(tables[name].map(row => row.id)).size !== tables[name].length) throw new Error('Duplicate record IDs in backup.');
    }
    for (const row of tables.snapshots) {
      if (!row.state || typeof row.state !== 'object' || !row.state.settings || typeof row.state.settings !== 'object') throw new Error('Backup contains an invalid hotel snapshot.');
      for (const key of ['bookings', 'rfps', 'bt', 'history', 'activities', 'accounts', 'contracts', 'xImports', 'xChat']) {
        if (row.state[key] !== undefined && !Array.isArray(row.state[key])) throw new Error('Backup contains an invalid ' + key + ' list.');
      }
    }
    const restoredRegistry = tables.settings.find(row => row.id === 'property-registry')?.value;
    const activeId = restoredRegistry?.active || tables.snapshots[0]?.id;
    const active = tables.snapshots.find(row => row.id === activeId);
    if (!active?.state?.settings || !restoredRegistry?.list?.length) throw new Error('Backup is missing its active hotel or property registry.');
    if (SC.hasActiveJobs?.()) throw new Error('A local job started while the backup was opening. Finish it before restoring. No data was restored.');
    restoring = true;
    clearTimeout(timer);
    try {
      await queue.catch(() => {});
      await db.transaction('rw', TABLES.map(name => db.table(name)), async () => {
        if (SC.hasActiveJobs?.()) throw new Error('A local job started before restore could apply. Finish it and retry.');
        const previousRevisions = new Map((await db.snapshots.toArray()).map(row => [row.id, Number(row.revision) || 0]));
        for (const name of TABLES) { await db.table(name).clear(); await db.table(name).bulkPut(tables[name]); }
        if (Array.isArray(decoded.recoveryCopies) && decoded.recoveryCopies.length) await db.settings.put({ id: 'recovery-copies', value: decodeBinary(decoded.recoveryCopies), restoredAt: Date.now() });
        // Bump revisions to invalidate older tabs rather than reusing backup revisions.
        for (const row of tables.snapshots) {
          row.revision = Math.max(Date.now(), previousRevisions.get(row.id) || 0, Number(row.revision) || 0) + 1;
          await db.snapshots.put(row);
        }
      });
      pending.clear(); revisions.clear(); status.conflicts.clear();
      for (const row of tables.snapshots) revisions.set(row.id, row.revision);
      let mirrorWarning = false;
      try {
        for (const row of tables.snapshots) localStorage.setItem(row.id === 'h0' ? 'scc.v1' : 'scc.v1.' + row.id, JSON.stringify(row.state));
        localStorage.setItem('scc.hotels', JSON.stringify(restoredRegistry));
      } catch { mirrorWarning = true; }
      SC.setRegistry?.(clone(restoredRegistry));
      SC.setState(clone(active.state)); SC.emit?.('restore'); SC.render?.();
      status.state = 'saved'; status.message = mirrorWarning ? 'Backup restored to database; browser cache mirror is full' : 'Backup restored on this device'; status.error = null; notify();
      return { properties: tables.properties.length, files: tables.files.length, recoveryCopies: decoded.recoveryCopies?.length || 0 };
    } finally { restoring = false; }
  }
  window.addEventListener('pagehide', () => { if (pending.size) flush().catch(() => {}); });
  window.addEventListener('beforeunload', event => { if (pending.size || status.state === 'error') { event.preventDefault(); event.returnValue = ''; } });
  return { db, ready, capture, flush, backup, restore, status, loadProperty, commitPropertyState, isRestoring: () => restoring };
}
