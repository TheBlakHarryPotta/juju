// Linked business records use one revision-checked durable snapshot, published only after commit.
const ROOTS=new Set(['salesWorkflows','bookings','contracts','plannedTasks','activities','repeatBusiness','needDateMatcher']);
const unsafe=new Set(['__proto__','prototype','constructor']);
const clone=x=>structuredClone(x);
const own=(o,k)=>o!==null&&o!==undefined&&Object.hasOwn(o,k);
export function stableJSON(value){
  const sort=v=>Array.isArray(v)?v.map(sort):v&&typeof v==='object'?Object.fromEntries(Object.keys(v).sort().map(k=>{if(unsafe.has(k))throw Error('Unsafe record field.');return[k,sort(v[k])];})):v;
  return JSON.stringify(sort(value));
}
const equal=(a,b)=>stableJSON(a)===stableJSON(b);
const object=v=>v&&typeof v==='object'&&!Array.isArray(v);
const recordArray=v=>Array.isArray(v)&&v.every(r=>object(r)&&typeof r.id==='string'&&r.id)&&new Set(v.map(r=>r.id)).size===v.length;
export function statePatches(before,after){
  const patches=[];
  function walk(a,b,path,ae=true,be=true){
    if(ae===be&&equal(a,b))return;
    if((recordArray(a)||a===undefined)&&(recordArray(b)||b===undefined)&&(Array.isArray(a)||Array.isArray(b))){
      const left=a||[],right=b||[],ids=new Set([...left.map(r=>r.id),...right.map(r=>r.id)]);
      for(const id of ids){const ai=left.findIndex(r=>r.id===id),bi=right.findIndex(r=>r.id===id);if(ai>=0&&bi>=0&&equal(left[ai],right[bi]))continue;patches.push({path,id,beforeExists:ai>=0,afterExists:bi>=0,before:ai>=0?clone(left[ai]):null,after:bi>=0?clone(right[bi]):null,beforeIndex:ai,afterIndex:bi});}return;
    }
    if((object(a)||a===undefined)&&(object(b)||b===undefined)&&(object(a)||object(b))){for(const k of new Set([...Object.keys(a||{}),...Object.keys(b||{})])){if(unsafe.has(k))throw Error('Unsafe record path.');walk(a?.[k],b?.[k],[...path,k],own(a,k),own(b,k));}return;}
    patches.push({path,beforeExists:ae,afterExists:be,before:ae?clone(a):null,after:be?clone(b):null});
  }
  for(const key of new Set([...Object.keys(before),...Object.keys(after)])){
    if(equal(before[key],after[key]))continue;
    if(!ROOTS.has(key))throw Error('A linked update cannot change hotel settings, reporting dates or its own receipts.');
    walk(before[key],after[key],[key],own(before,key),own(after,key));
  }
  return patches;
}
function at(state,path){let value=state;for(const key of path){if(unsafe.has(key))throw Error('Unsafe record path.');value=value?.[key];}return value;}
function parent(state,path){let value=state;for(const key of path.slice(0,-1)){if(unsafe.has(key))throw Error('Unsafe record path.');if(!object(value[key]))value[key]={};value=value[key];}return value;}
function entry(state,patch){if(patch.id){const list=at(state,patch.path);const found=Array.isArray(list)?list.find(r=>r.id===patch.id):undefined;return {exists:found!==undefined,value:found};}const p=at(state,patch.path.slice(0,-1)),key=patch.path.at(-1);return {exists:own(p,key),value:p?.[key]};}
function reverse(state,patch){
  if(patch.id){const p=parent(state,patch.path),key=patch.path.at(-1);if(!Array.isArray(p[key]))p[key]=[];const list=p[key],index=list.findIndex(r=>r.id===patch.id);if(index>=0)list.splice(index,1);if(patch.beforeExists)list.splice(Math.min(Math.max(0,patch.beforeIndex),list.length),0,clone(patch.before));}
  else {const p=parent(state,patch.path),key=patch.path.at(-1);if(patch.beforeExists)p[key]=clone(patch.before);else delete p[key];}
}
function externalReference(state,patches){
  const removed=new Set(patches.filter(p=>p.id&&!p.beforeExists&&p.afterExists).map(p=>p.id));if(!removed.size)return '';
  const skip=new Set(patches.filter(p=>p.id).map(p=>p.path.join('.')+'#'+p.id));
  const scan=(value,path=[])=>{
    if(!value||typeof value!=='object')return '';
    if(Array.isArray(value)){for(const row of value){if(row?.id&&skip.has(path.join('.')+'#'+row.id))continue;const found=scan(row,path);if(found)return found;}return '';}
    for(const [key,v]of Object.entries(value)){if(typeof v==='string'&&removed.has(v)&&(key!=='id'||path.at(-1)==='source'))return v;const found=scan(v,[...path,key]);if(found)return found;}return '';
  };
  for(const [key,value]of Object.entries(state)){if(key==='innovationReceipts')continue;const result=scan(value,[key]);if(result)return result;}return '';
}
export function initTransactions({SC}){
  let busy=false;
  const list=()=>SC.state.innovationReceipts||[];
  const externalJobs=()=>!!(SC.intakeBusy?.()||SC.workspaceBusy?.()||SC.legacyFileBusy||SC.salesImport?.isBusy?.()||SC.salesReport?.isBusy?.()||SC.needDates?.isBusy?.());
  const guard=propertyId=>{if(SC.isPropertySwitching?.())throw Error('This hotel is still loading. Wait before applying a linked update.');if(busy)throw Error('Another linked update is saving.');if(String(propertyId)!==SC.propertyId)throw Error('Hotel changed. Reopen this review in its original hotel.');if(SC.storage.isRestoring())throw Error('Wait for backup restore.');};
  async function locked(operation){busy=true;const was=document.body.inert;document.body.inert=true;SC.prepareAtomic?.();try{return await operation();}finally{document.body.inert=was;busy=false;}}
  async function publish(propertyId,expectedStateJSON,next){
    const durable=await SC.storage.commitPropertyState({propertyId,expectedStateJSON,nextState:next});
    if(SC.propertyId===propertyId){SC.setState(durable);SC.mirrorAtomic?.();}return durable;
  }
  async function commit({propertyId=SC.propertyId,expectedStateJSON,label='Linked sales update',source={},changes}={}){
    guard(propertyId);if(source?.propertyId!==undefined&&String(source.propertyId)!==propertyId)throw Error('The source belongs to another hotel.');if(externalJobs())throw Error('Finish active file or document work before applying a linked update.');if(typeof changes!=='function')throw Error('Provide a reviewed change set.');
    const expected=expectedStateJSON??JSON.stringify(SC.state);if(JSON.stringify(SC.state)!==expected)throw Error('Sales data changed after review opened. Review the latest records.');
    const before=clone(SC.state),next=clone(before),returned=changes(next);if(returned&&typeof returned.then==='function')throw Error('Prepare all source data before the synchronous record update.');
    const patches=statePatches(before,next);for(const p of patches)if(p.path[0]==='contracts'&&(p.before?.status==='Signed'||p.before?.data?.signed||p.after?.status==='Signed'||p.after?.data?.signed))throw Error('Linked reviews cannot sign or alter a signed contract.');if(!patches.length)throw Error('This review has no new changes.');
    const receipt={id:crypto.randomUUID(),propertyId,label:String(label).slice(0,300),source:clone(source),createdAt:new Date().toISOString(),status:'applied',patches};
    if(stableJSON(receipt).length>2_000_000)throw Error('This linked update is too large. Split the review into a smaller package.');
    next.innovationReceipts=[...(before.innovationReceipts||[]),receipt];next._at=Date.now();
    await locked(()=>publish(propertyId,expected,next));SC.emit('linkedchange');SC.render();return clone(receipt);
  }
  async function undo(id,{propertyId=SC.propertyId}={}){
    guard(propertyId);if(externalJobs())throw Error('Finish active work before undoing a linked update.');
    const expected=JSON.stringify(SC.state),receipt=list().find(r=>r.id===id&&r.propertyId===propertyId);if(!receipt||receipt.status!=='applied')throw Error('This receipt is not available to undo in this hotel.');
    if(!Array.isArray(receipt.patches)||!receipt.patches.length||receipt.patches.length>1000||receipt.patches.some(p=>!Array.isArray(p.path)||!ROOTS.has(p.path[0])||p.path.some(k=>typeof k!=='string'||unsafe.has(k))||p.id!==undefined&&typeof p.id!=='string'))throw Error('This receipt contains invalid record paths.');
    for(const patch of receipt.patches){const current=entry(SC.state,patch);if(current.exists!==patch.afterExists||current.exists&&!equal(current.value,patch.after))throw Error('A linked record changed after this package. Undo would overwrite later work; review it manually.');}
    if(externalReference(SC.state,receipt.patches))throw Error('Other work now refers to a linked record. Keep that history and resolve it before undoing this package.');
    const next=clone(SC.state);for(const patch of [...receipt.patches].reverse())reverse(next,patch);
    const changed=next.innovationReceipts.find(r=>r.id===id);changed.status='undone';changed.undoneAt=new Date().toISOString();next._at=Date.now();
    await locked(()=>publish(propertyId,expected,next));SC.emit('linkedchange');SC.render();return clone(changed);
  }
  SC.transactions={commit,undo,list,isBusy:()=>busy};
  SC.atomicMutation=({propertyId=SC.propertyId,label,apply,source,expectedStateJSON}={})=>commit({propertyId,label,source,expectedStateJSON,changes:apply});
  return SC.transactions;
}
