export function parseCSV(text) {
  const rows = []; let row = [], value = '', quoted = false;
  const input = String(text).replace(/^\uFEFF/, '');
  for (let i = 0; i < input.length; i++) {
    const c = input[i];
    if (c === '"') {
      if (quoted && input[i + 1] === '"') { value += '"'; i++; }
      else if (!value || quoted) quoted = !quoted;
      else throw new Error('Quote inside an unquoted field. Export this file as CSV again.');
    } else if (c === ',' && !quoted) { row.push(value); value = ''; }
    else if ((c === '\n' || c === '\r') && !quoted) {
      if (c === '\r' && input[i + 1] === '\n') i++;
      row.push(value); if (row.some(x => x.trim())) rows.push(row); row = []; value = '';
    } else value += c;
    if (rows.length > 20000) throw new Error('Use a CSV with 20,000 rows or fewer per import.');
  }
  if (quoted) throw new Error('CSV has an unfinished quoted field.');
  row.push(value); if (row.some(x => x.trim())) rows.push(row);
  if (rows.length < 2) throw new Error('CSV needs a header row and at least one account row.');
  const headers = rows.shift().map(x => x.trim());
  if (new Set(headers).size !== headers.length || headers.some(x => !x)) throw new Error('Each CSV header must be unique and nonempty.');
  if (rows.some(x => x.length !== headers.length)) throw new Error('CSV rows have different column counts. Check comma quoting in the export.');
  return {headers, rows};
}
export const accountKey = name => String(name).normalize('NFKC').trim().toLocaleLowerCase('en-US').replace(/\s+/g, ' ');
export function safeCSV(value) {
  let s = String(value ?? '');
  if (typeof value !== 'number' && (/^[\s\u0000-\u001f]*[=+\-@]/.test(s) || /^[\t\r\n]/.test(s))) s = "'" + s;
  return '"' + s.replace(/"/g, '""') + '"';
}
export function mergeText(template, fields) {
  return String(template).replace(/\{\{\s*([\w.-]+)\s*\}\}/g, (_, key) => {
    if (!Object.hasOwn(fields, key)) throw new Error('Missing merge field: ' + key);
    const v = fields[key];
    if (v !== null && typeof v === 'object') throw new Error('Merge fields must be text, numbers, or true/false.');
    return String(v ?? '');
  });
}
export function periodDays(p) {
  const a = Date.parse(p?.periodStart + 'T00:00:00Z'), b = Date.parse(p?.periodEnd + 'T00:00:00Z');
  return Number.isFinite(a) && Number.isFinite(b) && b >= a ? (b - a) / 86400000 + 1 : 0;
}
export function analyzeRadar(current, baseline, history = [], comparable = false) {
  if (!current) return {ready:false,reason:'Import a production CSV to begin.',rows:[]};
  const len = periodDays(current);
  const ready = !!(baseline && comparable && current.complete && baseline.complete && current.basis === baseline.basis && len > 0 && len === periodDays(baseline) && current.periodStart > baseline.periodEnd);
  let reason = ready ? 'Comparable complete periods; explicit account rows only.' : 'Trend alerts need two complete nonoverlapping periods of equal length, the same basis, and your comparable-period confirmation.';
  const old = new Map((baseline?.rows || []).map(r => [r.key || accountKey(r.account), r]));
  const currentKeys = new Set(current.rows.map(r => r.key || accountKey(r.account)));
  const rows = current.rows.map(r => {
    const key = r.key || accountKey(r.account), b = old.get(key);
    const earlier = history.filter(p => p.id !== current.id && p.periodEnd < current.periodStart && p.basis === current.basis).flatMap(p => p.rows || []).filter(x => (x.key || accountKey(x.account)) === key);
    let status = 'Observed', why = 'No comparable explicit baseline row; absence is not zero.';
    let delta = null, change = null;
    if (ready && b) {
      delta = r.rn - b.rn; change = b.rn > 0 ? delta / b.rn : null;
      status = 'Stable'; why = 'No configured trend threshold met.';
      if (b.rn >= 20 && delta <= -10 && change <= -.25) { status = 'Declining'; why = 'At least 20 baseline RNs; down at least 10 RNs and 25%.'; }
      else if (b.rn > 0 && delta >= 10 && change >= .25) { status = 'Growing'; why = 'Up at least 10 RNs and 25%.'; }
      else if (b.rn === 0 && r.rn > 0 && earlier.some(x => x.rn > 0)) { status = 'Reactivated'; why = 'Explicit zero baseline, positive current RNs, and earlier positive production.'; }
      else if (b.rn === 0 && r.rn > 0) { status = 'First positive observed'; why = 'Positive now after an explicit zero; available history does not prove a new company or account.'; }
      else if (r.rn === 0 && b.rn >= 20) { status = 'Declining'; why = 'Explicit current zero and at least 20 baseline RNs; verify project/seasonality before outreach.'; }
    } else if (!earlier.length && r.rn > 0) { status = 'First observed'; why = 'First in imported records only; not proof of a newly founded company or newly won account.'; }
    return {...r, baseline:b?.rn ?? null,delta,change,status,why};
  });
  for (const b of baseline?.rows || []) if (!currentKeys.has(b.key || accountKey(b.account))) rows.push({...b,rn:null,rev:null,baseline:b.rn,delta:null,change:null,status:'Missing current row',why:'Absent from current import. Missing data is not zero and does not prove lost business.'});
  return {ready,reason,rows};
}
