import {inspectZip,validateZipPayload} from './intake.js';
import { Document, Packer, Paragraph, TextRun, HeadingLevel } from 'docx';
import Docxtemplater from 'docxtemplater';
import PizZip from 'pizzip';
import SignaturePad from 'signature_pad';
import {parseCSV, accountKey, safeCSV, mergeText, periodDays, analyzeRadar} from './workspaces-model.js';
export {parseCSV, safeCSV, mergeText, analyzeRadar} from './workspaces-model.js';

const uid = () => crypto.randomUUID();
const date = () => new Date().toISOString().slice(0,10);
const stamp = () => new Date().toISOString();
const num = n => Number(n).toLocaleString('en-US',{maximumFractionDigits:2});
const limit = 25 * 1024 * 1024;
export async function initWorkspaces({SC,db}) {
  const esc = SC.escape || (s => String(s ?? '').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])));
  const property = () => String(typeof SC.propertyId === 'function' ? SC.propertyId() : SC.propertyId);
  let activeJobs=0;SC.workspaceBusy=()=>activeJobs>0;
  let cacheProperty = '', records = [], production = [], loading = false, loadToken = 0;
  let followupDraft=null;
  let editSRP = null, editTemplate = null, preview = null, csvDraft = null, currentId = '', baselineId = '', comparable = false, signaturePad;
  const blankStudio = () => ({title:'Contract draft', text:'Paste your approved contract text here.\n\nHotel representative: ____________________\n\nClient representative: ____________________',marks:[],font:'Allura',name:'',markData:null});
  let studio = blankStudio();
  const cleanupUrls = new Set();
  const get = (type) => records.filter(r=>r.type===type);
  const find = (id,type) => records.find(r=>r.id===id && (!type || r.type===type));
  const showError = e => SC.toast(e?.message || String(e));
  const refresh = async () => {
    const p = property(), token = ++loadToken; loading = true;
    try {
      const [r,b] = await Promise.all([db.records.where('propertyId').equals(p).toArray(),db.production.where('propertyId').equals(p).toArray()]);
      if (token !== loadToken || p !== property()) return;
      if (cacheProperty !== p) { editSRP=null;editTemplate=null;preview=null;csvDraft=null;currentId='';baselineId='';comparable=false;studio=blankStudio();followupDraft=null; }
      records=r;production=b.sort((a,b)=>b.periodEnd.localeCompare(a.periodEnd)||b.importedAt.localeCompare(a.importedAt));cacheProperty=p;
    } catch(e) { showError(e); } finally { if(token===loadToken) {loading=false;SC.render();} }
  };
  const ensure = () => {
    if (cacheProperty !== property()) { if(!loading) void refresh();return false;} return true;
  };
  const frame = (body) => `<section class="sc-page ws-root">${body}</section>`;
  const pending = () => frame('<div class="sc-card">Loading this hotel’s local workspace…</div>');
  const field = (label,input) => `<label class="sc-field"><span>${esc(label)}</span>${input}</label>`;
  const input = (name,value='',extra='') => `<input name="${name}" value="${esc(value)}" ${extra}>`;
  const area = (name,value='',extra='') => `<textarea name="${name}" rows="5" ${extra}>${esc(value)}</textarea>`;
  const button = (action,label,extra='',cls='') => `<button type="button" class="btn ${cls}" data-ws-act="${action}" ${extra}>${label}</button>`;
  const options = (values,selected) => values.map(v=>`<option value="${esc(Array.isArray(v)?v[0]:v)}" ${(Array.isArray(v)?v[0]:v)===selected?'selected':''}>${esc(Array.isArray(v)?v[1]:v)}</option>`).join('');
  const saveRecord = async (type,data,id,p=property()) => {
    const expected=id?records.find(r=>r.id===id)?.updatedAt:null;
    try {await db.transaction('rw',db.records,async()=>{const existing=id?await db.records.get(id):null;
      if(existing&&(existing.propertyId!==p||existing.updatedAt!==expected))throw Error('Another tab changed this record. Reopen the latest version and try again.');
      if(id&&!existing)throw Error('This record was removed in another tab. Add a new record instead.');
      await db.records.put({id:id||uid(),propertyId:p,type,data,updatedAt:stamp()});
    });}catch(e){await refresh();throw e;}await refresh();
  };
  const saveFile = async (file,p) => {
    if(!file.size)throw Error('Choose a nonempty original file.');if(file.size>limit)throw Error('This workspace accepts files up to 25 MB.');
    const hash=await digest(await file.arrayBuffer());
    return db.transaction('rw',db.files,async()=>{const files=await db.files.toArray(),existing=files.find(f=>f.propertyId===p&&f.hash===hash);if(existing)return existing.id;
      if(files.reduce((sum,f)=>sum+(f.size||0),0)+file.size>500*1024*1024)throw Error('The 500 MB local file budget is full. Export a backup and manage old originals before adding more.');
      const id=uid();await db.files.put({id,propertyId:p,hash,createdAt:stamp(),updatedAt:stamp(),name:file.name,mime:file.type||'application/octet-stream',type:file.type||'application/octet-stream',size:file.size,blob:file,status:'attachment',contextView:'templateLibrary',coverage:'Original saved locally by sales workspace. No automatic field extraction was performed.'});return id;
    });
  };
  const download = (blob,name) => SC.download(blob,name);
  const fileFor = async (id,p) => {const f=await db.files.get(id);if(!f||f.propertyId!==p) throw Error('This file is not available in this hotel workspace.');return f;};

  function srpView() {
    if(!ensure())return pending();
    const d = find(editSRP,'srp')?.data || {};
    return frame(`<div class="sc-card"><h3>SRP & Group Code Vault</h3><p class="muted">Store verified booking instructions for this hotel. Codes are local reference records; live PEP availability is not checked.</p><div class="sc-toolbar">${input('ws-srp-search','','id="ws-srp-search" placeholder="Search code, company, group or notes" aria-label="Search booking codes"')}${button('new-srp','New code')}</div></div>
      <div class="sc-grid"><div class="sc-card"><h3>${editSRP?'Edit code':'Add a code'}</h3><form id="ws-srp-form"><div class="sc-grid">${field('Code',input('code',d.code,'required maxlength="100"'))}${field('Code type',`<select name="codeType">${options(['SRP','Group code','Rate plan','Solicitation ID'],d.codeType||'SRP')}</select>`)}${field('Company / group',input('account',d.account,'required maxlength="200"'))}${field('Display name',input('name',d.name,'maxlength="200"'))}${field('Valid from',input('validFrom',d.validFrom,'type="date"'))}${field('Valid through',input('validTo',d.validTo,'type="date"'))}${field('Status',`<select name="status">${options(['Needs verification','Verified','Expired','Inactive'],d.status||'Needs verification')}</select>`)}${field('Last verified',input('verifiedAt',d.verifiedAt,'type="date"'))}${field('Booking URL',input('url',d.url,'type="url" placeholder="https://…"'))}${field('Source / agreement reference',input('source',d.source,'maxlength="400"'))}</div>${field('Restrictions / approved booking instructions',area('notes',d.notes))}<div class="sc-actions"><button class="btn pri" type="submit">Save code</button>${editSRP?button('new-srp','Cancel edit'):''}</div></form></div>
      <div class="sc-card"><h3>Saved codes <span class="sc-badge">${get('srp').length}</span></h3><div id="ws-srp-list">${srpRows('')}</div></div></div>`);
  }
  function srpRows(q) {
    const list=get('srp').filter(r=>Object.values(r.data).join(' ').toLowerCase().includes(q.toLowerCase()));
    return list.map(r=>{const d=r.data,expired=d.validTo&&d.validTo<date();return `<article class="sc-card" data-ws-record="${esc(r.id)}"><div class="sc-toolbar"><h4>${esc(d.account)} · <code>${esc(d.code)}</code></h4><span class="sc-badge">${expired?'Expired':esc(d.status)}</span></div><p>${esc(d.name||d.codeType)} · ${esc(d.validFrom||'No start date')} to ${esc(d.validTo||'No expiry entered')}</p><p class="muted">Source: ${esc(d.source||'Not entered')} · Verified: ${esc(d.verifiedAt||'Not verified')}</p><p style="white-space:pre-wrap">${esc(d.notes)}</p><div class="sc-actions">${button('copy-srp','Copy code',`data-id="${esc(r.id)}"`)}${button('copy-instructions','Copy instructions',`data-id="${esc(r.id)}"`)}${button('edit-srp','Edit',`data-id="${esc(r.id)}"`)}${button('verify-srp','Mark verified today',`data-id="${esc(r.id)}"`)}${button('delete-record','Delete',`data-id="${esc(r.id)}"`)}</div></article>`;}).join('')||'<p class="muted">No matching codes. Add one from an approved source.</p>';
  }

  function templateView() {
    if(!ensure())return pending();
    const r=find(editTemplate,'template'),d=r?.data||{};
    return frame(`<div class="sc-card"><h3>Templates & RFP Library</h3><p class="muted">Keep approved templates, bid answers and source files locally. Use {{fieldName}} for merge fields. Each save preserves the previous text version.</p><div class="sc-actions">${button('new-template','New template')}</div></div><div class="sc-grid"><div class="sc-card"><h3>${r?'Edit template':'Add a template'}</h3><form id="ws-template-form">${field('Name',input('name',d.name,'required maxlength="200"'))}${field('Category',`<select name="category">${options(['Group contract','Corporate agreement','RFP bid','Proposal','RFP answer','Other'],d.category||'Group contract')}</select>`)}${field('Approved by / source',input('approvedBy',d.approvedBy,'maxlength="200"'))}${field('Text / notes',area('body',d.body,'rows="12" placeholder="Dear {{contact}}, …"'))}${field('Attach an original file (up to 25 MB)',input('file','','type="file"'))}<p class="muted">${d.fileName?'Attached: '+esc(d.fileName):'PDF, DOCX and other originals can be retained. Text edits do not rewrite the attached source.'}</p><button class="btn pri" type="submit">Save template</button></form></div><div class="sc-stack"><div class="sc-card"><h3>Your library</h3>${get('template').map(t=>`<article class="sc-card"><h4>${esc(t.data.name)}</h4><p class="muted">${esc(t.data.category)} · version ${t.data.version||1} · ${esc(t.data.approvedBy||'Approval not recorded')}</p><div class="sc-actions">${button('preview-template','Preview / merge',`data-id="${esc(t.id)}"`)}${button('edit-template','Edit',`data-id="${esc(t.id)}"`)}${button('history-template','History',`data-id="${esc(t.id)}"`)}${button('delete-record','Delete',`data-id="${esc(t.id)}"`)}</div></article>`).join('')||'<p class="muted">No templates yet.</p>'}</div>${previewTemplate()}</div></div>`);
  }
  function previewTemplate() {
    const r=find(preview,'template');if(!r)return '';
    const d=r.data;
    return `<div class="sc-card" id="ws-template-preview"><h3>${esc(d.name)}</h3><pre style="white-space:pre-wrap;overflow-wrap:anywhere">${esc(d.body||'This template has an attached original. Download or open it below.')}</pre><form id="ws-merge-form" data-id="${esc(r.id)}">${templateFields(d).map(key=>field(key.replace(/([a-z])([A-Z])/g,'$1 $2').replace(/[_-]/g,' '),input('merge:'+key,key==='hotel'?((typeof SC.state==='function'?SC.state():SC.state)?.settings?.hotel||''):'','required'))).join('')||'<p class="muted">No merge fields found. This exports the saved text without substitutions.</p>'}<div class="sc-actions"><button class="btn pri" type="submit">Export merged DOCX</button>${button('print-template','Print / save PDF',`data-id="${esc(r.id)}"`)}${button('studio-template','Use text in Signature Studio',`data-id="${esc(r.id)}"`)}${d.fileId?button('open-template','Open original',`data-id="${esc(r.id)}"`)+button('download-template','Download original',`data-id="${esc(r.id)}"`):''}</div></form><p class="muted">DOCX sources merge in their original layout. Other attachments remain source files; DOCX export uses the text above. Review all commercial terms before signing.</p></div>`;
  }

  function radarView() {
    if(!ensure())return pending();
    const current=production.find(x=>x.id===currentId)||production[0],baseline=production.find(x=>x.id===baselineId);
    const result=analyzeRadar(current,baseline,production,comparable);
    return frame(`<div class="sc-card"><h3>Account Radar</h3><p class="muted">See changes backed by your imported hotel records. First observed here does not mean a new company. Missing rows never count as zero.</p><form id="ws-production-file-form">${field('Select a production CSV (up to 5 MB)',input('csv','','type="file" accept=".csv,text/csv" required'))}<button class="btn" type="submit">Read CSV & map columns</button></form></div>${csvForm()}<div class="sc-card"><h3>Compare production</h3><div class="sc-grid">${field('Current period',`<select id="ws-current">${options(production.map(p=>[p.id,`${p.name}: ${p.periodStart} to ${p.periodEnd}`]),current?.id)}</select>`)}${field('Baseline period',`<select id="ws-baseline"><option value="">Choose an earlier period</option>${options(production.map(p=>[p.id,`${p.name}: ${p.periodStart} to ${p.periodEnd}`]),baseline?.id)}</select>`)}</div><label class="sc-field"><span><input id="ws-comparable" type="checkbox" ${comparable?'checked':''}> I confirm these periods have comparable seasonality, account definitions and reporting basis. For OTB I checked equal lead time.</span></label><p class="sc-badge">${esc(result.reason)}</p><p class="muted">${current?'Current source: '+esc(current.sourceName)+' · '+esc(current.periodStart)+' to '+esc(current.periodEnd)+' · report as of '+esc(current.asOf)+' · '+esc(current.basis)+' · '+(current.complete?'complete':'partial')+' coverage':''}</p><div class="sc-actions">${button('export-radar','Export comparison CSV')}${current?.fileId?button('download-production','Download current source CSV',`data-id="${esc(current.id)}"`):''}${baseline?.fileId?button('download-production','Download baseline source CSV',`data-id="${esc(baseline.id)}"`):''}</div><p class="muted">${baseline?'Baseline: '+esc(baseline.sourceName)+' · '+esc(baseline.periodStart)+' to '+esc(baseline.periodEnd)+' · as of '+esc(baseline.asOf):'Choose a baseline for a sourced comparison.'}</p><div class="sc-table-wrap"><table><thead><tr><th>Account</th><th>Current RNs / revenue</th><th>Baseline RNs / revenue</th><th>Change</th><th>Status / explanation</th><th>Next action</th></tr></thead><tbody>${result.rows.map(r=>`<tr><td>${esc(r.account)}</td><td>${r.rn===null?'Missing':num(r.rn)}<br><small>${r.rev===null||r.rev===undefined?'Revenue not supplied':'$'+num(r.rev)}</small></td><td>${r.baseline===null?'Missing':num(r.baseline)}<br><small>${baselineRevenue(baseline,r)}</small></td><td>${r.delta===null?'Not comparable':num(r.delta)+(r.change===null?'':` (${(r.change*100).toFixed(1)}%)`)}</td><td><b>${esc(r.status)}</b><br><small>${esc(r.why)}</small></td><td>${button('plan-followup','Plan follow-up',`data-key="${esc(r.key||accountKey(r.account))}" data-current="${esc(current.id)}" data-baseline="${esc(baseline?.id||'')}"`)}</td></tr>`).join('')}</tbody></table></div></div>${plannedFollowups()}<div class="sc-card"><h3>Import history</h3>${production.map(p=>`<article class="sc-card"><b>${esc(p.name)}</b> · ${esc(p.periodStart)} to ${esc(p.periodEnd)} · ${p.rows.length} account rows · ${esc(p.basis)}<p class="muted">${esc(p.sourceName)} · as of ${esc(p.asOf)} · imported ${esc(p.importedAt)} · ${p.complete?'complete':'partial'} coverage</p>${button('delete-production','Remove import',`data-id="${esc(p.id)}"`)}</article>`).join('')||'<p class="muted">No production imported.</p>'}</div>`);
  }
  function plannedTasks() {const state=typeof SC.state==='function'?SC.state():SC.state;return (state?.plannedTasks||[]).filter(t=>t.source?.kind==='account-radar'&&!t.done);}
  function plannedFollowups() {
    const tasks=plannedTasks();
    return `<div class="sc-card"><h3>Planned follow-ups</h3><p class="muted">These plans do not count as completed sales activity. Copy a draft when ready, then log what actually happened.</p>${tasks.map(t=>`<article class="sc-card"><h4>${esc(t.account)}</h4><p>Due ${esc(t.due||t.followUp)}${t.contact?' · '+esc(t.contact):''}</p><details><summary>Outreach draft & evidence</summary><pre style="white-space:pre-wrap">${esc(t.outreach||'')}\n\n${esc(t.notes||'')}</pre></details><div class="sc-actions">${button('copy-planned-followup','Copy outreach draft',`data-id="${esc(t.id)}"`)}${button('complete-planned-followup','Log completed follow-up',`data-id="${esc(t.id)}"`)}</div></article>`).join('')||'<p class="muted">No outstanding Account Radar plans.</p>'}</div>`;
  }
  function baselineRevenue(baseline,row) {
    const b=baseline?.rows.find(x=>(x.key||accountKey(x.account))===(row.key||accountKey(row.account)));
    return b?.rev===null||b?.rev===undefined?'Revenue not supplied':'$'+num(b.rev);
  }
  function openFollowup(trigger) {
    const p=property(),current=production.find(x=>x.id===trigger.dataset.current),baseline=production.find(x=>x.id===trigger.dataset.baseline);
    if(!current)throw Error('This import is no longer available. Refresh Account Radar.');
    const row=analyzeRadar(current,baseline,production,comparable).rows.find(x=>(x.key||accountKey(x.account))===trigger.dataset.key);
    if(!row)throw Error('This account row is no longer available.');
    const actual=row.rn===null?'missing':num(row.rn)+' RNs'+(row.rev==null?'':', $'+num(row.rev));
    const previous=row.baseline===null?'missing':num(row.baseline)+' RNs'+(baseline?' ('+baselineRevenue(baseline,row)+')':'');
    const context=`${row.account}\nCurrent: ${current.periodStart} to ${current.periodEnd}: ${actual}. Source: ${current.sourceName}, as of ${current.asOf}.\n${baseline?`Baseline: ${baseline.periodStart} to ${baseline.periodEnd}: ${previous}. Source: ${baseline.sourceName}, as of ${baseline.asOf}.`:'No baseline selected.'}\n${row.status}: ${row.why}\nVerify project/seasonal changes directly. This is not evidence of the cause of any change.`;
    const outreach=row.status==='Declining'?`Hi,\n\nI wanted to check in about ${row.account}'s upcoming travel. Our hotel records show fewer room nights in the periods I reviewed. Are your team's travel needs changing, or is there anything we can help with for upcoming dates?\n\nI'd appreciate a quick update when convenient.`:`Hi,\n\nI wanted to check in about ${row.account}'s upcoming travel. Do you have any projects, group stays or recurring room needs we should plan for? I'm happy to review dates and options with you.\n\nPlease let me know a convenient time to connect.`;
    followupDraft={id:uid(),propertyId:p,account:row.account,currentId:current.id,baselineId:baseline?.id||null,context,source:{kind:'account-radar',basis:current.basis,currentAsOf:current.asOf,baselineAsOf:baseline?.asOf||null,currentSourceName:current.sourceName,baselineSourceName:baseline?.sourceName||null,accountKey:row.key||accountKey(row.account),currentProductionId:current.id,baselineProductionId:baseline?.id||null,currentFileId:current.fileId||null,baselineFileId:baseline?.fileId||null,status:row.status,currentPeriod:{start:current.periodStart,end:current.periodEnd,rn:row.rn,revenue:row.rev??null},baselinePeriod:baseline?{start:baseline.periodStart,end:baseline.periodEnd,rn:row.baseline}:null,reviewed:false}};
    SC.modal(`<div class="sc-card"><h3>Plan an account follow-up</h3><p class="muted">Review the source context and edit the draft. Nothing is sent. Saving creates a follow-up plan. Only a later explicit completion logs an activity.</p><details><summary>Production evidence</summary><pre style="white-space:pre-wrap">${esc(context)}</pre></details><form id="ws-followup-form">${field('Account',input('account',row.account,'readonly'))}${field('Contact name (optional)',input('contact','','maxlength="160" placeholder="Enter a contact you have verified"'))}${field('Follow-up due',input('due',date(),'type="date" required'))}${field('Outreach draft',area('outreach',outreach,'rows="9" required'))}<label class="sc-field"><span><input name="reviewed" type="checkbox" required> I reviewed the source context, timing and outreach wording.</span></label><div class="sc-actions">${button('copy-followup','Copy outreach draft')}<button class="btn pri" type="submit">Save follow-up plan</button>${button('close-modal','Cancel')}</div></form></div>`);
  }
  function csvForm() {
    if(!csvDraft)return '';
    const {headers,rows}=csvDraft;
    const col = (name,guess) => `<select name="${name}">${headers.map((h,i)=>`<option value="${i}" ${new RegExp(guess,'i').test(h)?'selected':''}>${esc(h)}</option>`).join('')}</select>`;
    return `<div class="sc-card"><h3>Map ${esc(csvDraft.name)}</h3><p>${rows.length} rows read. Each row must describe account production for the entire selected period. Rows for the same exact normalized account are summed. Do not import reservation detail without preparing account totals.</p><form id="ws-production-form"><div class="sc-grid">${field('Account column',col('accountCol','account|company'))}${field('Room nights column',col('rnCol','room.?night|^rn$'))}${field('Revenue column (optional)',`<select name="revCol"><option value="">Not supplied</option>${headers.map((h,i)=>`<option value="${i}">${esc(h)}</option>`).join('')}</select>`)}${field('Import label',input('name',csvDraft.name,'required maxlength="200"'))}${field('Period start',input('periodStart','','type="date" required'))}${field('Period end',input('periodEnd','','type="date" required'))}${field('Report as of',input('asOf',date(),'type="date" required'))}${field('Basis',`<select name="basis"><option value="stayed">Actual stayed production</option><option value="otb">On the books</option></select>`)}</div><label class="sc-field"><span><input type="checkbox" name="complete"> I checked this report covers the full period and account population. Explicit zero rows are retained; absent rows stay missing.</span></label><div class="sc-table-wrap"><table><thead><tr>${headers.map(h=>`<th>${esc(h)}</th>`).join('')}</tr></thead><tbody>${rows.slice(0,5).map(r=>`<tr>${r.map(c=>`<td>${esc(c)}</td>`).join('')}</tr>`).join('')}</tbody></table></div><button class="btn pri" type="submit">Save reviewed production</button>${button('cancel-csv','Cancel')}</form></div>`;
  }

  function signatureView() {
    if(!ensure())return pending();
    setTimeout(setupPad,0);
    return frame(`<div class="sc-card"><h3>Signature Studio</h3><p class="muted">Create your own signature appearance and place it on a locally composed contract. This is a printable mark, without recipient authentication or cryptographic signing. Uploaded PDF signing is not supported here.</p></div><div class="sc-grid"><div class="sc-card"><form id="ws-signature-form">${field('Document title',input('title',studio.title,'required maxlength="200"'))}${field('Approved contract text',area('text',studio.text,'rows="12" required'))}${field('Your name',input('name',studio.name,'required maxlength="160"'))}${field('Cursive style',`<select name="font">${options(['Allura','Great Vibes','Caveat'],studio.font)}</select>`)}<div class="sc-actions"><button class="btn" type="submit">Update document & name</button>${button('add-typed-signature','Add my typed signature')}</div></form><h4>Draw your own mark</h4><canvas id="ws-signature-canvas" width="520" height="150" style="display:block;width:100%;height:150px;background:#fff;border:1px solid #aaa;touch-action:none" aria-label="Draw your signature"></canvas><div class="sc-actions">${button('clear-pad','Clear drawing')}${button('add-drawn-signature','Add my drawing')}</div>${field('Or upload your own PNG/JPEG signature',input('ws-mark-file','','type="file" accept="image/png,image/jpeg" id="ws-mark-file"'))}<p class="muted">Your mark is never automatically applied to a template. Drag a mark to position it; use its corner handle to resize. Placement uses this one-page preview. Split longer contracts before placing a mark.</p></div><div class="sc-stack" style="overflow:auto"><div class="sc-card"><div class="sc-actions">${button('print-studio','Print / save PDF')}${button('docx-studio','Export DOCX')}${button('save-studio','Save draft locally')}${button('clear-marks','Remove marks')}</div><p class="muted">Printable pages keep your placed marks. DOCX preserves typed signature text at the document end; drawn/uploaded marks are not included in DOCX.</p>${get('signatureDraft').map(r=>button('load-studio',esc(r.data.title),`data-id="${esc(r.id)}"`)).join('')}</div><div class="ws-paper" id="ws-paper" style="position:relative;background:white;color:#172033;width:816px;min-height:1056px;padding:48px;box-sizing:border-box;overflow:hidden;font:14px/1.5 Georgia,serif;"><h2 style="color:#172033;font:24px/1.5 Georgia,serif;margin:0 0 20px">${esc(studio.title)}</h2><div style="white-space:pre-wrap;overflow-wrap:anywhere" id="ws-contract-text">${esc(studio.text)}</div>${studio.marks.map(markHTML).join('')}</div></div></div>`);
  }
  function cleanMark(raw) {
    const number=(value,min,max,fallback)=>Math.max(min,Math.min(max,Number.isFinite(Number(value))?Number(value):fallback));
    const image=typeof raw.image==='string'&&/^data:image\/(png|jpeg);base64,[A-Za-z0-9+/=]+$/.test(raw.image)?raw.image:null;
    return {id:typeof raw.id==='string'&&/^[a-zA-Z0-9-]+$/.test(raw.id)?raw.id:uid(),x:number(raw.x,0,90,10),y:number(raw.y,0,980,180),width:number(raw.width,80,600,220),height:number(raw.height,35,200,70),font:['Allura','Great Vibes','Caveat'].includes(raw.font)?raw.font:'Allura',text:String(raw.text||'').slice(0,160),image};
  }
  function markHTML(raw) {
    const m=cleanMark(raw);
    return `<div class="ws-mark" data-mark-id="${m.id}" style="position:absolute;left:${m.x}%;top:${m.y}px;width:${m.width}px;height:${m.height}px;border:1px dashed #8296b1;touch-action:none;cursor:move;box-sizing:border-box;display:flex;align-items:center;justify-content:center;">${m.image?`<img src="${m.image}" alt="Your signature" draggable="false" style="width:100%;height:100%;object-fit:contain;pointer-events:none">`:`<span style="font-family:'${m.font}',cursive;font-size:${Math.min(72,m.height*.75)}px;white-space:nowrap;pointer-events:none">${esc(m.text)}</span>`}<button type="button" data-ws-act="remove-mark" data-id="${m.id}" aria-label="Remove this signature" style="position:absolute;right:-9px;top:-12px;border-radius:50%;background:white;color:#273c53;border:1px solid #8296b1;cursor:pointer;">×</button><span class="ws-resize" role="slider" tabindex="0" aria-label="Resize signature" style="position:absolute;right:-5px;bottom:-5px;width:15px;height:15px;background:#2456a6;cursor:nwse-resize;"></span></div>`;
  }
  function setupPad() {
    const canvas=document.querySelector('#ws-signature-canvas');if(!canvas||signaturePad?.canvas===canvas)return;
    const ratio=Math.max(window.devicePixelRatio||1,1);canvas.width=canvas.clientWidth*ratio;canvas.height=150*ratio;canvas.getContext('2d').scale(ratio,ratio);
    signaturePad=new SignaturePad(canvas,{backgroundColor:'rgb(255,255,255)',penColor:'#172033'});
  }
  async function digest(buffer) {const h=await crypto.subtle.digest('SHA-256',buffer);return [...new Uint8Array(h)].map(b=>b.toString(16).padStart(2,'0')).join('');}
  function data(form) { return Object.fromEntries([...new FormData(form)].filter(([,v])=>typeof v==='string')); }
  function templateFields(d) {return [...new Set([...(d.mergeFields||[]),...[...String(d.body||'').matchAll(/\{\{\s*([\w.-]+)\s*\}\}/g)].map(m=>m[1])])].filter(k=>!['__proto__','constructor','prototype'].includes(k));}
  function getMergeFields(form) {
    if(!form)throw Error('Open a template preview first.');
    const out=Object.create(null);for(const [name,value]of new FormData(form))if(name.startsWith('merge:'))out[name.slice(6)]=String(value);
    for(const el of form.querySelectorAll('[name^="merge:"]'))if(!el.value.trim())throw Error('Fill the merge field: '+el.name.slice(6));
    return out;
  }
  async function openDocx(buffer) {
    inspectZip(buffer); await validateZipPayload(buffer);
    const zip=new PizZip(buffer),entries=Object.values(zip.files);
    if(entries.reduce((sum,x)=>sum+(x._data?.uncompressedSize||0),0)>50*1024*1024)throw Error('Expanded DOCX is too large to read safely.');
    if(entries.some(x=>/vbaProject/i.test(x.name)))throw Error('Macro-enabled templates are not supported.');
    return zip;
  }
  function inspectDocx(zip) {
    let text='';const fields=[];
    for(const entry of Object.values(zip.files).filter(x=>/^word\/(document|header\d*|footer\d*)\.xml$/.test(x.name))){
      const xml=new DOMParser().parseFromString(entry.asText(),'application/xml');
      for(const p of xml.getElementsByTagName('w:p'))text += [...p.getElementsByTagName('w:t')].map(t=>t.textContent).join('')+'\n';
    }
    for(const match of text.matchAll(/\{\{\s*([\w.-]+)\s*\}\}/g))fields.push(match[1]);
    return {body:text.trim(),mergeFields:[...new Set(fields)]};
  }
  async function makeDocx(title,text,marks=[]) {
    const children=[new Paragraph({text:title,heading:HeadingLevel.TITLE}),...String(text).split('\n').map(line=>new Paragraph({children:[new TextRun(line)]}))];
    for(const m of marks.filter(m=>!m.image))children.push(new Paragraph({children:[new TextRun({text:m.text,font:m.font,size:64})]}));
    return Packer.toBlob(new Document({sections:[{children}]}));
  }
  function fontRules() {let rules='';for(const sheet of document.styleSheets){try{for(const rule of sheet.cssRules)if(rule.type===CSSRule.FONT_FACE_RULE)rules+=rule.cssText;}catch{}}return rules;}
  function printDocument(title,body,marks=[]) {
    const markup=marks.map(cleanMark).map(m=>`<div style="position:absolute;left:${m.x}%;top:${m.y}px;width:${m.width}px;height:${m.height}px;display:flex;align-items:center;justify-content:center">${m.image?`<img src="${m.image}" alt="Signature" style="width:100%;height:100%;object-fit:contain">`:`<span style="font-family:'${m.font}',cursive;font-size:${Math.min(72,m.height*.75)}px;white-space:nowrap">${esc(m.text)}</span>`}</div>`).join('');
    const iframe=document.createElement('iframe');iframe.title='Print document';iframe.style.cssText='position:fixed;right:0;bottom:0;width:1px;height:1px;border:0;';
    iframe.srcdoc=`<!doctype html><html><head><meta charset="utf-8"><title>${esc(title)}</title><style>${fontRules()}@page{size:letter;margin:0}body{margin:0;font:14px/1.5 Georgia,serif;color:#172033}.paper{position:relative;min-height:1056px;width:816px;box-sizing:border-box;padding:48px}h2{font:24px/1.5 Georgia,serif;margin:0 0 20px}p{margin:0;white-space:pre-wrap;overflow-wrap:anywhere}</style></head><body><div class="paper"><h2>${esc(title)}</h2><p>${esc(body)}</p>${markup}</div></body></html>`;
    iframe.onload=async()=>{await iframe.contentDocument.fonts.ready;iframe.contentWindow.addEventListener('afterprint',()=>iframe.remove(),{once:true});iframe.contentWindow.focus();iframe.contentWindow.print();};
    document.body.append(iframe);
  }
  function syncStudioForm() {const f=document.querySelector('#ws-signature-form');if(!f)return;if(!f.reportValidity())throw Error('Enter your name and contract text first.');Object.assign(studio,data(f));}
  function addMark(mark) {
    syncStudioForm();studio.marks.push({id:uid(),x:10,y:Math.min(700,180+studio.marks.length*80),width:220,height:70,...mark});SC.render();
  }
  const actions = {
    'plan-followup':b=>openFollowup(b),
    'copy-planned-followup':async b=>{const task=plannedTasks().find(t=>t.id===b.dataset.id);if(!task)throw Error('This follow-up plan is no longer available.');await copy(task.outreach||'');},
    'complete-planned-followup':b=>{const task=plannedTasks().find(t=>t.id===b.dataset.id);if(!task)throw Error('This plan is already completed or no longer available.');SC.modal(`<div class="sc-card"><h3>Log completed follow-up</h3><p>${esc(task.account)}${task.contact?' · '+esc(task.contact):''}</p><p class="muted">Record what actually happened. This creates one completed sales activity; it does not send the outreach draft.</p><form id="ws-complete-followup-form" data-id="${esc(task.id)}" data-property="${esc(property())}">${field('Completed on',input('date',date(),'type="date" required'))}${field('Actual result',input('outcome','','required maxlength="300" placeholder="For example: spoke with contact; awaiting project dates"'))}${field('Notes',area('notes','','rows="4" placeholder="Actual conversation or outreach details"'))}<button type="submit" class="btn pri">Save completed activity</button>${button('close-modal','Cancel')}</form></div>`);},
    'copy-followup':async()=>{const f=document.querySelector('#ws-followup-form');if(!f||followupDraft?.propertyId!==property())throw Error('Reopen this follow-up in the correct hotel.');try{await navigator.clipboard.writeText(f.elements.outreach.value);SC.toast('Outreach draft copied. Nothing was sent.');}catch{f.elements.outreach.focus();f.elements.outreach.select();SC.toast('Press Ctrl+C or Command+C to copy the selected outreach draft.');}},
    'download-production':async b=>{const p=property(),period=production.find(x=>x.id===b.dataset.id);if(!period?.fileId)throw Error('Original CSV is not available for this older import.');const file=await fileFor(period.fileId,p);if(p===property())download(file.blob,file.name);},
    'new-srp':()=>{editSRP=null;SC.render();},
    'edit-srp':b=>{editSRP=b.dataset.id;SC.render();},
    'copy-srp':async b=>{const r=find(b.dataset.id,'srp');if(!r)return;await copy(r.data.code);},
    'copy-instructions':async b=>{const r=find(b.dataset.id,'srp');if(!r)return;const d=r.data;await copy(`${d.account}\n${d.codeType}: ${d.code}\n${d.notes||''}${d.url?'\n'+d.url:''}\nValid: ${d.validFrom||'not entered'} to ${d.validTo||'not entered'}\n${d.status||'Needs verification'}`);},
    'verify-srp':async b=>{const r=find(b.dataset.id,'srp');if(r){if(!r.data.source?.trim())throw Error('Add a source reference before marking this code verified.');await saveRecord('srp',{...r.data,status:'Verified',verifiedAt:date()},r.id);SC.toast('Verification date saved. Live PEP status was not checked.');}},
    'delete-record':b=>{const r=find(b.dataset.id);if(!r)return;confirmDelete(`Delete ${r.data.name||r.data.account||'this record'}?`,async()=>{await db.records.delete(r.id);if(editSRP===r.id)editSRP=null;if(editTemplate===r.id)editTemplate=null;await refresh();});},
    'new-template':()=>{editTemplate=null;SC.render();},
    'edit-template':b=>{editTemplate=b.dataset.id;SC.render();},
    'preview-template':b=>{preview=b.dataset.id;SC.render();},
    'history-template':b=>{const r=find(b.dataset.id,'template');if(r)SC.modal(`<div class="sc-card"><h3>${esc(r.data.name)} version history</h3>${(r.data.history||[]).map(v=>`<details><summary>Version ${v.version} · ${esc(v.savedAt)}</summary><pre style="white-space:pre-wrap">${esc(v.body)}</pre></details>`).join('')||'<p>No earlier versions yet.</p>'}${button('close-modal','Close')}</div>`);},
    'open-template':async b=>{const r=find(b.dataset.id,'template'),p=property();if(!r)return;const f=await fileFor(r.data.fileId,p);if(p!==property())return;for(const oldUrl of cleanupUrls)URL.revokeObjectURL(oldUrl);cleanupUrls.clear();const url=URL.createObjectURL(f.blob);cleanupUrls.add(url);if(f.mime==='application/pdf'||/\.pdf$/i.test(f.name))SC.modal(`<div class="sc-card"><h3>${esc(f.name)}</h3><iframe src="${url}" title="PDF original" style="width:100%;height:65vh;border:0"></iframe>${button('close-modal','Close')}</div>`);else if(/^text\//.test(f.mime)||/\.(txt|csv|md)$/i.test(f.name)){const text=await f.blob.text();if(p===property())SC.modal(`<div class="sc-card"><h3>${esc(f.name)}</h3><pre style="white-space:pre-wrap">${esc(text.slice(0,100000))}</pre>${button('close-modal','Close')}</div>`);}else{download(f.blob,f.name);SC.toast('Original downloaded. This format has no browser preview.');}},
    'download-template':async b=>{const r=find(b.dataset.id,'template'),p=property();if(r){const f=await fileFor(r.data.fileId,p);if(p===property())download(f.blob,f.name);}},
    'print-template':b=>{const r=find(b.dataset.id,'template');if(!r)return;const form=document.querySelector('#ws-merge-form'),fields=getMergeFields(form);printDocument(r.data.name,mergeText(r.data.body||'',fields));},
    'studio-template':b=>{const r=find(b.dataset.id,'template');if(!r)return;const fields=getMergeFields(document.querySelector('#ws-merge-form'));studio={...studio,title:r.data.name,text:mergeText(r.data.body||'',fields),marks:[]};SC.navigate('signatureStudio');},
    'cancel-csv':()=>{csvDraft=null;SC.render();},
    'delete-production':b=>{const p=production.find(p=>p.id===b.dataset.id);if(p)confirmDelete('Remove this production import? Trend history will change.',async()=>{await db.production.delete(p.id);comparable=false;await refresh();});},
    'export-radar':()=>{const c=production.find(x=>x.id===currentId)||production[0],base=production.find(x=>x.id===baselineId),r=analyzeRadar(c,base,production,comparable);if(!c)throw Error('Import a production CSV first.');const rows=[['Account','Current RNs','Baseline RNs','Delta RNs','Status','Explanation','Current source','Current period','Baseline period'],...r.rows.map(a=>[a.account,a.rn??'Missing',a.baseline??'Missing',a.delta??'Not comparable',a.status,a.why,c.sourceName,`${c.periodStart} to ${c.periodEnd}`,base?`${base.periodStart} to ${base.periodEnd}`:'Not selected'])];download(new Blob(['\uFEFF'+rows.map(row=>row.map(safeCSV).join(',')).join('\r\n')],{type:'text/csv;charset=utf-8'}),'account-radar.csv');},
    'add-typed-signature':()=>{syncStudioForm();addMark({text:studio.name,font:studio.font});},
    'clear-pad':()=>signaturePad?.clear(),
    'add-drawn-signature':()=>{if(!signaturePad||signaturePad.isEmpty())throw Error('Draw your own signature first.');addMark({image:signaturePad.toDataURL('image/png')});},
    'remove-mark':b=>{studio.marks=studio.marks.filter(m=>m.id!==b.dataset.id);SC.render();},
    'clear-marks':()=>{studio.marks=[];SC.render();},
    'print-studio':()=>{syncStudioForm();const paper=document.querySelector('#ws-paper');if(paper?.scrollHeight>1056)throw Error('This preview is longer than one printed page. Shorten or split the document before placing signatures.');printDocument(studio.title,studio.text,studio.marks);},
    'docx-studio':async()=>{syncStudioForm();download(await makeDocx(studio.title,studio.text,studio.marks),filename(studio.title)+'.docx');SC.toast('DOCX exported. Drawn/uploaded marks are omitted; typed marks appear at the end.');},
    'save-studio':async()=>{syncStudioForm();const p=property();await saveRecord('signatureDraft',{title:studio.title,text:studio.text,name:studio.name,font:studio.font,marks:studio.marks},null,p);SC.toast('Draft saved locally. This does not certify a signed contract.');},
    'load-studio':b=>{const r=find(b.dataset.id,'signatureDraft');if(r){studio={...blankStudio(),...structuredClone(r.data),marks:(r.data.marks||[]).map(cleanMark)};SC.render();}},
    'close-modal':()=>{SC.closeModal();for(const url of cleanupUrls)URL.revokeObjectURL(url);cleanupUrls.clear();},
    'confirm-delete':async b=>{const fn=deleteCallbacks.get(b.dataset.id);deleteCallbacks.delete(b.dataset.id);SC.closeModal();if(fn)await fn();}
  };
  const deleteCallbacks=new Map();
  function confirmDelete(title,fn) {const id=uid();deleteCallbacks.set(id,fn);SC.modal(`<div class="sc-card"><h3>${esc(title)}</h3><p>This removes the local record. Original attachments remain in local storage until backup/storage management removes them.</p><div class="sc-actions">${button('confirm-delete','Delete',`data-id="${id}"`)}${button('close-modal','Cancel')}</div></div>`);}
  const filename = name => String(name).replace(/[^a-zA-Z0-9._ -]/g,'').slice(0,100)||'document';
  async function copy(text) {try{await navigator.clipboard.writeText(text);SC.toast('Copied.');}catch{SC.modal(`<div class="sc-card"><h3>Copy this text</h3>${area('copy',text,'id="ws-copy" readonly rows="7"')}${button('close-modal','Close')}</div>`);setTimeout(()=>document.querySelector('#ws-copy')?.select(),0);}}
  document.addEventListener('click',e=>{const b=e.target.closest('[data-ws-act]');if(!b)return;const fn=actions[b.dataset.wsAct];if(!fn)return;if(SC.storage?.isRestoring?.()){e.preventDefault();showError(Error('Wait for backup restore to finish before using this workspace.'));return;}e.preventDefault();e.stopPropagation();if(b.disabled)return;b.disabled=true;activeJobs++;Promise.resolve().then(()=>fn(b)).catch(showError).finally(()=>{b.disabled=false;activeJobs--;});},true);
  document.addEventListener('input',e=>{if(e.target.id==='ws-srp-search'){const list=document.querySelector('#ws-srp-list');if(list)list.innerHTML=srpRows(e.target.value);}});
  document.addEventListener('change',async e=>{
    const t=e.target;
    if(t.id==='ws-current'){currentId=t.value;comparable=false;SC.render();}
    if(t.id==='ws-baseline'){baselineId=t.value;comparable=false;SC.render();}
    if(t.id==='ws-comparable'){comparable=t.checked;SC.render();}
    if(t.id==='ws-mark-file'&&t.files?.[0]){
      if(SC.storage?.isRestoring?.()){showError(Error('Wait for backup restore to finish.'));return;}
      const file=t.files[0],p=property();activeJobs++;try{if(!['image/png','image/jpeg'].includes(file.type))throw Error('Use a PNG or JPEG image of your own signature.');if(file.size>2*1024*1024)throw Error('Use a signature image smaller than 2 MB.');const image=await imageData(file);if(p!==property())return;addMark({image});}catch(err){showError(err);}finally{activeJobs--;}
    }
  });
  document.addEventListener('submit',e=>{
    const f=e.target;if(!['ws-srp-form','ws-template-form','ws-merge-form','ws-production-file-form','ws-production-form','ws-signature-form','ws-followup-form','ws-complete-followup-form'].includes(f.id))return;e.preventDefault();e.stopPropagation();if(SC.storage?.isRestoring?.()){showError(Error('Wait for backup restore to finish before saving.'));return;}if(f.dataset.saving)return;f.dataset.saving='true';activeJobs++;for(const b of f.querySelectorAll('[type=submit]'))b.disabled=true;void submit(f).catch(showError).finally(()=>{activeJobs--;delete f.dataset.saving;for(const b of f.querySelectorAll('[type=submit]'))b.disabled=false;});
  },true);
  async function submit(f) {
    if(!f.reportValidity())return;const p=property(),values=data(f);
    if(f.id==='ws-followup-form') {
      const draft=followupDraft;if(!draft||draft.propertyId!==p)throw Error('Hotel changed. Reopen this account follow-up in its hotel.');
      if(!f.elements.reviewed.checked)throw Error('Review and confirm the draft before saving.');
      if(!values.outreach.trim())throw Error('Write or edit the outreach draft before saving.');
      if(!production.some(x=>x.id===draft.currentId))throw Error('The source production import is no longer available. Reopen the account.');
      SC.commitPlannedTask({type:'followup',account:draft.account,contact:values.contact.trim(),segment:'Business Transient',due:values.due,followUp:values.due,outreach:values.outreach.trim(),notes:draft.context,sourceId:draft.currentId,localDraftId:draft.id,source:{...draft.source,reviewed:true,reviewedAt:stamp()}});
      followupDraft=null;SC.closeModal();SC.render();SC.toast('Follow-up plan saved. Nothing was sent or counted as completed activity.');return;
    }
    if(f.id==='ws-complete-followup-form') {
      if(f.dataset.property!==p)throw Error('Hotel changed. Reopen the plan in its hotel.');
      if(!plannedTasks().some(t=>t.id===f.dataset.id))throw Error('This follow-up is already completed or no longer available.');
      if(!values.outcome.trim())throw Error('Enter the actual result before logging a completed activity.');
      if(values.date>date())throw Error('Completed activity cannot be dated in the future.');
      SC.completePlannedTask(f.dataset.id,{date:values.date,outcome:values.outcome.trim(),notes:values.notes.trim()});SC.closeModal();SC.render();SC.toast('Completed follow-up logged once in Activity Log.');return;
    }
    if(f.id==='ws-srp-form'){
      if(values.validFrom&&values.validTo&&values.validFrom>values.validTo)throw Error('Valid through must be on or after valid from.');
      if(values.status==='Verified'&&(!values.verifiedAt||!values.source?.trim()))throw Error('A verified code needs a verification date and source reference.');
      if(values.url&&!/^https?:\/\//i.test(values.url))throw Error('Booking URLs must use http or https.');
      if(get('srp').some(r=>r.id!==editSRP&&r.data.code===values.code&&r.data.codeType===values.codeType&&r.data.validFrom===values.validFrom&&r.data.validTo===values.validTo))throw Error('This code/type/validity period already exists. Edit that record instead.');
      const id=editSRP;await saveRecord('srp',values,id,p);editSRP=null;SC.render();SC.toast('Code saved for this hotel.');
    }
    if(f.id==='ws-template-form'){
      const old=find(editTemplate,'template'),file=f.elements.file.files?.[0];
      let fileId=old?.data.fileId,fileName=old?.data.fileName,mergeFields=old?.data.mergeFields||[];
      if(file){fileId=await saveFile(file,p);fileName=file.name;if(!values.body&&/\.(txt|md)$/i.test(file.name))values.body=await file.text();if(/\.docx$/i.test(file.name)){const doc=inspectDocx(await openDocx(await file.arrayBuffer()));mergeFields=doc.mergeFields;if(!values.body)values.body=doc.body;}}
      const history=old?.data.history||[];
      if(old)history.push({version:old.data.version||1,body:old.data.body,name:old.data.name,category:old.data.category,approvedBy:old.data.approvedBy,fileId:old.data.fileId,fileName:old.data.fileName,savedAt:old.updatedAt});
      await saveRecord('template',{...values,fileId,fileName,mergeFields,version:(old?.data.version||0)+1,history},old?.id,p);if(p===property())editTemplate=null;SC.render();SC.toast('Template saved with version history.');
    }
    if(f.id==='ws-merge-form'){
      const r=find(f.dataset.id,'template');if(!r)throw Error('Template no longer available.');const fields=getMergeFields(f);let blob;
      if(r.data.fileId&&/\.docx$/i.test(r.data.fileName)){
        const file=await fileFor(r.data.fileId,p),zip=await openDocx(await file.blob.arrayBuffer());
        const doc=new Docxtemplater(zip,{paragraphLoop:true,linebreaks:true,delimiters:{start:'{{',end:'}}'},nullGetter:part=>{throw Error('Missing merge field: '+part.value);}});doc.render(fields);blob=doc.getZip().generate({type:'blob',mimeType:'application/vnd.openxmlformats-officedocument.wordprocessingml.document'});
      }else blob=await makeDocx(r.data.name,mergeText(r.data.body||'',fields));
      if(p===property()){download(blob,filename(r.data.name)+'-merged.docx');SC.toast('Merged DOCX exported. Review before use.');}
    }
    if(f.id==='ws-production-file-form'){
      const file=f.elements.csv.files?.[0];if(!file)throw Error('Choose a CSV file.');if(file.size>5*1024*1024)throw Error('Use a CSV under 5 MB.');
      const text=await file.text(),parsed=parseCSV(text),hash=await digest(await file.arrayBuffer());if(p!==property())return;csvDraft={...parsed,name:file.name,hash,propertyId:p,file};SC.render();
    }
    if(f.id==='ws-production-form'){
      const draft=csvDraft;if(!draft||draft.propertyId!==p)throw Error('Read the CSV again in this hotel.');
      if(!periodDays(values))throw Error('Choose a valid start/end period.');if(values.basis==='stayed'&&values.periodEnd>values.asOf)throw Error('Stayed production cannot end after the report as-of date.');
      if(values.accountCol===values.rnCol||values.revCol!==''&&[values.accountCol,values.rnCol].includes(values.revCol))throw Error('Account, room nights and revenue must use different columns.');
      if(production.some(x=>x.hash===draft.hash&&x.periodStart===values.periodStart&&x.periodEnd===values.periodEnd&&x.basis===values.basis))throw Error('This exact file and period are already imported.');
      const totals=new Map();
      for(const [i,row]of draft.rows.entries()){
        const account=row[Number(values.accountCol)].trim(),key=accountKey(account);if(!key)throw Error('Account name is missing on row '+(i+2));
        const rn=csvNumber(row[Number(values.rnCol)],'Room nights',i+2);if(rn<0||!Number.isInteger(rn))throw Error('Room nights must be nonnegative whole numbers on row '+(i+2));
        const rev=values.revCol===''?null:csvNumber(row[Number(values.revCol)],'Revenue',i+2);if(rev!==null&&rev<0)throw Error('Use nonnegative account revenue; handle corrections in the source report.');
        const old=totals.get(key)||{key,account,rn:0,rev:rev===null?null:0};old.rn+=rn;if(rev!==null)old.rev+=rev;totals.set(key,old);
      }
      const fileId=await saveFile(draft.file,p);
      const row={id:uid(),propertyId:p,fileId,periodStart:values.periodStart,periodEnd:values.periodEnd,asOf:values.asOf,basis:values.basis,complete:f.elements.complete.checked,sourceName:draft.name,name:values.name,hash:draft.hash,rows:[...totals.values()],mapping:{account:draft.headers[values.accountCol],rn:draft.headers[values.rnCol],revenue:values.revCol===''?null:draft.headers[values.revCol]},importedAt:stamp()};
      await db.transaction('rw',db.production,async()=>{const existing=await db.production.where('propertyId').equals(p).filter(x=>x.hash===draft.hash&&x.periodStart===values.periodStart&&x.periodEnd===values.periodEnd&&x.basis===values.basis).first();if(existing)throw Error('This exact file and period are already imported.');await db.production.add(row);});if(p===property()){csvDraft=null;currentId=row.id;comparable=false;}await refresh();SC.toast('Production saved. Select a comparable baseline to evaluate trends.');
    }
    if(f.id==='ws-signature-form'){Object.assign(studio,values);SC.render();SC.toast('Contract preview updated. No mark was applied automatically.');}
  }
  function csvNumber(value,label,row){const s=String(value).trim().replace(/[$,\s]/g,'');if(!s||!/^\d+(?:\.\d+)?$/.test(s))throw Error(`${label} must be numeric on row ${row}. Blank is not zero.`);const n=Number(s);if(!Number.isFinite(n)||n>1e12)throw Error(`${label} is out of range on row ${row}.`);return n;}
  async function imageData(file){const bitmap=await createImageBitmap(file);if(bitmap.width*bitmap.height>10000000){bitmap.close();throw Error('Use a signature image under 10 megapixels.');}const canvas=document.createElement('canvas');const scale=Math.min(1,1200/bitmap.width);canvas.width=Math.round(bitmap.width*scale);canvas.height=Math.round(bitmap.height*scale);canvas.getContext('2d').drawImage(bitmap,0,0,canvas.width,canvas.height);bitmap.close();return canvas.toDataURL('image/png');}
  let drag=null;
  document.addEventListener('pointerdown',e=>{
    const el=e.target.closest('.ws-mark');if(!el||e.target.closest('button'))return;const paper=el.closest('#ws-paper'),m=studio.marks.find(m=>m.id===el.dataset.markId);if(!paper||!m)return;e.preventDefault();el.setPointerCapture(e.pointerId);drag={el,m,paper,startX:e.clientX,startY:e.clientY,x:m.x,y:m.y,width:m.width,height:m.height,resize:!!e.target.closest('.ws-resize')};
  });
  document.addEventListener('pointermove',e=>{
    if(!drag)return;const {el,m,paper}=drag,dx=e.clientX-drag.startX,dy=e.clientY-drag.startY;
    if(drag.resize){m.width=Math.max(80,Math.min(paper.clientWidth*(1-m.x/100),drag.width+dx));m.height=Math.max(35,Math.min(200,drag.height+dy));el.style.width=m.width+'px';el.style.height=m.height+'px';const text=el.querySelector('span:not(.ws-resize)');if(text)text.style.fontSize=Math.min(72,m.height*.75)+'px';}
    else {m.x=Math.max(0,Math.min(100-m.width/paper.clientWidth*100,drag.x+dx/paper.clientWidth*100));m.y=Math.max(0,Math.min(paper.clientHeight-m.height,drag.y+dy));el.style.left=m.x+'%';el.style.top=m.y+'px';}
  });
  document.addEventListener('pointerup',()=>{drag=null;});document.addEventListener('pointercancel',()=>{drag=null;});
  document.addEventListener('keydown',e=>{if(!e.target.matches('.ws-resize')||!['ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(e.key))return;e.preventDefault();const m=studio.marks.find(m=>m.id===e.target.closest('.ws-mark').dataset.markId);if(!m)return;m.width=Math.max(80,Math.min(500,m.width+(e.key==='ArrowRight'?10:e.key==='ArrowLeft'?-10:0)));m.height=Math.max(35,Math.min(200,m.height+(e.key==='ArrowDown'?5:e.key==='ArrowUp'?-5:0)));SC.render();});
  window.addEventListener('pagehide',()=>{for(const u of cleanupUrls)URL.revokeObjectURL(u);});
  SC.registerView('srpVault','SRP & Group Code Vault','Your verified booking codes, without the search',srpView,'tag');
  SC.registerView('templateLibrary','Templates & RFP Library','Approved documents and reusable bid answers',templateView,'contract');
  SC.registerView('accountRadar','Account Radar','Account production changes with evidence',radarView,'bt');
  SC.registerView('signatureStudio','Signature Studio','Your own signature marks on reviewed documents',signatureView,'contract');
  SC.on?.('propertychange',()=>{void refresh();});
  SC.on?.('restore',()=>{studio=blankStudio();followupDraft=null;editSRP=null;editTemplate=null;csvDraft=null;preview=null;comparable=false;void refresh();});
  await refresh();
  return {refresh};
}
