#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if [ ! -f dist/index.html ]; then
  echo "Build the application first: npm ci && npm run build"
  exit 1
fi
echo "Sales Command: open http://127.0.0.1:4173 in your browser. Keep this terminal open."
python3 -m http.server 4173 --bind 127.0.0.1 --directory dist
