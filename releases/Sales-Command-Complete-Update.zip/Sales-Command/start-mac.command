#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if [ ! -f dist/index.html ] || [ ! -x tools/.venv/bin/python ]; then
  echo "Run setup-mac.command first and keep the dist folder with this app."
  exit 1
fi
mkdir -p .local
# No network-interface binding: both services stay on this Mac.
tools/.venv/bin/python tools/speech_server.py > .local/speech.log 2>&1 &
speech_pid=$!
python3 -m http.server 4173 --bind 127.0.0.1 --directory dist > .local/app.log 2>&1 &
app_pid=$!
cleanup() { kill "$speech_pid" "$app_pid" 2>/dev/null || true; }
trap cleanup EXIT INT TERM
for ((attempt=0;attempt<30;attempt++)); do
  if ! kill -0 "$speech_pid" 2>/dev/null || ! kill -0 "$app_pid" 2>/dev/null; then
    echo "A service could not start. Close any earlier Sales Command launchers and check .local logs."
    exit 1
  fi
  if [ -f tools/.speech-token ]; then break; fi
  sleep 1
done
open http://127.0.0.1:4173
if [ -f tools/.speech-token ]; then open -a TextEdit tools/.speech-token; fi
echo "Paste the private token from TextEdit into Call Desk. Keep this terminal open; press Control-C to stop."
wait "$app_pid"
