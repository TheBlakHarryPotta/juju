@echo off
cd /d "%~dp0"
if not exist dist\index.html (
  echo Build the application first: npm ci and npm run build
  pause
  exit /b 1
)
echo Sales Command will run locally. Keep this window open.
start "" http://127.0.0.1:4173
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 -m http.server 4173 --bind 127.0.0.1 --directory dist
) else (
  python -m http.server 4173 --bind 127.0.0.1 --directory dist
)
pause
