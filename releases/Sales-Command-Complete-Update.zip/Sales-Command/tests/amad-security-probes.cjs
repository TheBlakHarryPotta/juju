const fs=require('node:fs');
const vm=require('node:vm');
const assert=require('node:assert/strict');
const path=require('node:path');
const src=fs.readFileSync(path.resolve(__dirname,'../index.html'),'utf8');
function extract(start,end) { return src.slice(src.indexOf(start),src.indexOf(end,src.indexOf(start))); }
(async()=>{
const writes=[];
const sandbox={X:{col:{doc:key=>({get:async()=>{sandbox.HR.active='hotelB';sandbox.state={settings:{hotel:'HOTEL B'},bookings:[{name:'B-private-account'}],_at:200};return {exists:false};},set:async d=>writes.push([key,d]),delete:async()=>{}})},pulled:true,last:{},base:{},tab:'tab'},HR:{active:'hotelA'},state:{settings:{hotel:'HOTEL A'},bookings:[{name:'A-account'}],_at:100},CHUNK:90000,paintCloud(){},cloudQueue(){},uid:()=> 'abc123456',num:x=>Number(x)||0,console,Date,JSON,Object};
vm.createContext(sandbox);
vm.runInContext(extract('function cloudPush()','async function cloudPushReg()'),sandbox);
await sandbox.cloudPush();
assert.equal(JSON.parse(writes.find(([key])=>key.startsWith('h_hotelA_settings'))[1].s).hotel,'HOTEL A');
assert.equal(writes.find(([key])=>key==='m_hotelA')[1].name,'HOTEL A');
console.log('PASS immutable cloud property snapshot');
const q = vm.runInNewContext(src.slice(src.indexOf('const q = v =>'),src.indexOf('    const csv =',src.indexOf('const q = v =>'))).replace('const q =', '(').trim().replace(/;$/, ')'));
assert.equal(q('=1+1'),"'=1+1"); assert.equal(q(-2),'-2'); assert.equal(q('  @SUM(A1)'),"'  @SUM(A1)"); console.log('PASS spreadsheet formula text protection and numeric preservation');
const local={document:{getElementById:()=>local.el},el:{},localStorage:{setItem(){throw new Error('quota exceeded');}},X:{col:{}},HR:{active:'a'},hKey:()=> 'key',state:{},JSON};vm.createContext(local);vm.runInContext(extract('function xWriteLocal()','save = function'),local);local.xWriteLocal();assert.equal(local.el.textContent,'Local save failed: export a backup'); console.log('PASS truthful failed local save');
const ed={h:s=>String(s).replaceAll('&','&amp;').replaceAll('"','&quot;').replaceAll('<','&lt;').replaceAll('>','&gt;'),Object,Array,Set};vm.createContext(ed);vm.runInContext(extract('const XSAFE_FIELDS =','document.addEventListener(\'input\''),ed);
assert.ok(!ed.xEd({'x" onpointerover="alert(1)" z="':'value'},'fields').includes('onpointerover'));
assert.ok(ed.xEd({name:'Normal account'},'fields').includes('Normal account'));
vm.runInContext("xSet({}, 'fields.__proto__.polluted', 'bad'); xSet({}, 'fields.constructor.prototype.polluted', 'bad')",ed);
assert.equal(vm.runInContext('({}).polluted',ed),undefined); console.log('PASS schema field allowlist and prototype path rejection');
})();

// New properties must remain blank when lazy legacy sections are opened.
{
  const app = fs.readFileSync(path.resolve(__dirname,'../index.html'),'utf8');
  const extractRange=(a,b)=>app.slice(app.indexOf(a),app.indexOf(b,app.indexOf(a)));
  const fixture={window:{SEED:{},AP_SEED:{hotel:'OLD HOTEL',actions:[{text:'OLD ACCOUNT'}]}},
    state:{settings:{preparedBy:'Current manager',theme:'dark'}}, uid:()=> 'qa',RFP_TYPES:['Other'],
    MONTHS:['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'],
    num:value=>Number(value)||0,todayISO:()=> '2026-10-30',nextReportDate:()=> '2026-10-30',Date,JSON,Object};
  vm.createContext(fixture);
  vm.runInContext(extractRange('function emptyGroupYear()', 'let state;'),fixture);
  vm.runInContext(extractRange('function blankHotel(meta)', 'function xMigrate()'),fixture);
  vm.runInContext(extractRange('function apState()', 'const friday ='),fixture);
  vm.runInContext(extractRange('function kSettings()', 'function kList()'),fixture);
  fixture.state=fixture.blankHotel({name:'QA NEW HOTEL',rooms:99});
  assert.equal(fixture.apState().actions.length,0);
  assert.equal(fixture.apState().hotel,'QA NEW HOTEL');
  assert.equal(fixture.kSettings().hotel,'QA NEW HOTEL');
  assert.equal(fixture.kSettings().salesEmail,'');
  assert.equal(fixture.kSettings().cell,'');
  assert.equal(fixture.state.bookings.length,0);
  assert.equal(fixture.state.bonus.targetBonus,0);
  assert.equal(fixture.state.settings.goals.prospecting,0);
  console.log('PASS blank-property lazy action-plan and contract settings isolation');
}
