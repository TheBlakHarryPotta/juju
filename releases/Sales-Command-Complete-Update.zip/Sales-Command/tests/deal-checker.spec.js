import { test, expect } from '@playwright/test';
import { calculateDeal, checkDealInputs, dealDates, dateNumber, dealCSV } from '../src/deal-checker.js';

function fixture(overrides={}) {
  return {groupName:'QA Corporate Group',currency:'USD',arrival:'2030-06-01',departure:'2030-06-02',forecastAsOf:'2030-05-30',cutoff:'2030-05-25',rate:150,variableCost:30,commissionPct:5,paymentFeePct:0,rebatePerPaidRN:0,concessionPerOccupiedRN:0,fixedConcessions:0,incrementalFixedCost:0,ancillaryRevenue:0,ancillaryCost:0,alternativeVariableCost:40,alternativeCommissionPct:0,targetContribution:0,approvedMinRate:'',stressPickupPct:80,forecastStressPct:10,alternativeRateStressPct:10,nights:[{date:'2030-06-01',rooms:20,compRooms:2,capacity:100,forecastRooms:90,alternativeADR:200,rate:''}],...overrides};
}
const calculate=input=>calculateDeal(input,{today:'2030-05-30'});
function assertFiniteTree(value){if(typeof value==='number')expect(Number.isFinite(value)).toBe(true);else if(Array.isArray(value))value.forEach(assertFiniteTree);else if(value&&typeof value==='object')Object.values(value).forEach(assertFiniteTree);}

test('known-answer group math charges comps, subtracts commission and true displaced margin',()=>{
  const result=calculate(fixture());expect(result.ready).toBe(true);
  expect(result.base).toMatchObject({paidRN:18,occupiedRN:20,compRN:2,roomRevenue:2700,commissions:135,variableCosts:600,groupContribution:1965,displacedRN:10,displacedContribution:1600,incrementalContribution:365,breakEvenRate:128.66});
  expect(result.scenarios[2].displacedRN).toBe(20);expect(result.scenarios[2].incrementalContribution).toBeCloseTo(-1635,8);
  expect(result.assessment).toBe('sensitive');assertFiniteTree(result);
});

test('multi-night commissions, fees, rebates, variable concessions, fixed costs and ancillary contribution reconcile',()=>{
  const row={rooms:10,compRooms:1,capacity:100,forecastRooms:95,alternativeADR:200,rate:''};
  const result=calculate(fixture({departure:'2030-06-03',commissionPct:10,paymentFeePct:2,rebatePerPaidRN:2,concessionPerOccupiedRN:5,fixedConcessions:50,incrementalFixedCost:100,ancillaryRevenue:500,ancillaryCost:200,alternativeVariableCost:20,alternativeCommissionPct:5,targetContribution:100,nights:[{...row,date:'2030-06-01'},{...row,date:'2030-06-02'}]}));
  expect(result.ready).toBe(true);expect(result.base).toMatchObject({paidRN:18,occupiedRN:20,roomRevenue:2700,commissions:270,sellingFees:54,rebates:36,variableCosts:600,variableConcessions:100,fixedCosts:150,ancillaryContribution:300,groupContribution:1790,displacedContribution:1700,incrementalContribution:90,breakEvenRate:144.32,targetRate:150.64});
  expect(result.base.groupContribution-result.base.displacedContribution).toBeCloseTo(result.base.incrementalContribution,8);
});

test('lower paid pickup keeps promised comps and committed costs; ancillary revenue scales, costs do not',()=>{
  const result=calculate(fixture({forecastStressPct:0,ancillaryRevenue:1000,ancillaryCost:200,fixedConcessions:100,incrementalFixedCost:50}));
  const low=result.scenarios[1];expect(low.paidRN).toBeCloseTo(14.4);expect(low.compRN).toBe(2);expect(low.occupiedRN).toBeCloseTo(16.4);expect(low.ancillaryRevenue).toBe(800);expect(low.ancillaryCost).toBe(200);expect(low.fixedCosts).toBe(150);
  assertFiniteTree(result);
});

test('break-even and target rates rounded upward cover the entered target across varied costs and comps',()=>{
  for(const compRooms of [0,1,6])for(const commissionPct of [0,7,15]) {
    const input=fixture({commissionPct,paymentFeePct:2.5,rebatePerPaidRN:3,concessionPerOccupiedRN:4,fixedConcessions:85,incrementalFixedCost:40,ancillaryRevenue:180,ancillaryCost:90,targetContribution:250,nights:[{...fixture().nights[0],compRooms}]});
    const first=calculate(input);expect(first.ready).toBe(true);
    const atFloor=calculate({...input,rate:first.base.targetRate});expect(atFloor.base.incrementalContribution).toBeGreaterThanOrEqual(250-1e-7);
    const oneCentLower=calculate({...input,rate:first.base.targetRate-.01});expect(oneCentLower.base.incrementalContribution).toBeLessThan(250+1e-7);
  }
});

test('nightly rate overrides affect paid-room revenue and a flat floor still solves the whole stay',()=>{
  const input=fixture({departure:'2030-06-03',nights:[{...fixture().nights[0],rate:130},{...fixture().nights[0],date:'2030-06-02',rate:190,compRooms:0}]});
  const r=calculate(input);expect(r.ready).toBe(true);expect(r.base.roomRevenue).toBe(18*130+20*190);expect(r.base.averageRate).toBeCloseTo((18*130+20*190)/38);
  const flat=calculate({...input,rate:r.base.targetRate,nights:input.nights.map(n=>({...n,rate:''}))});expect(flat.base.incrementalContribution).toBeGreaterThanOrEqual(-1e-7);
});

test('no displacement does not demand invented alternative ADR or costs, including unused nights',()=>{
  const rows=[{...fixture().nights[0],forecastRooms:30,alternativeADR:''},{...fixture().nights[0],date:'2030-06-02',rooms:0,compRooms:0,forecastRooms:100,alternativeADR:''}];
  const r=calculate(fixture({departure:'2030-06-03',alternativeVariableCost:'',alternativeCommissionPct:'',nights:rows}));expect(r.ready).toBe(true);expect(r.base.displacedRN).toBe(0);expect(r.base.displacedContribution).toBe(0);assertFiniteTree(r);
});

test('busy-demand sensitivity requests alternative data even when the quoted block does not displace',()=>{
  const r=calculate(fixture({alternativeVariableCost:'',alternativeCommissionPct:'',nights:[{...fixture().nights[0],forecastRooms:75,alternativeADR:''}]}));expect(r.ready).toBe(false);expect(r.errors.join(' ')).toMatch(/alternative/i);
});

test('all complimentary rooms produce real costs and no fake finite room-rate floor',()=>{
  const r=calculate(fixture({rate:'',stressPickupPct:0,nights:[{...fixture().nights[0],compRooms:20}]}));expect(r.ready).toBe(true);expect(r.base).toMatchObject({paidRN:0,roomRevenue:0,variableCosts:600,groupContribution:-600,displacedRN:10,incrementalContribution:-2200,breakEvenRate:null,minimumRate:null});expect(r.warnings.join(' ')).toMatch(/all occupied rooms are complimentary/i);assertFiniteTree(r);
});

test('negative alternative margins are never credited as a benefit to the group',()=>{
  const r=calculate(fixture({alternativeVariableCost:250}));expect(r.ready).toBe(true);expect(r.base.displacedContribution).toBe(0);expect(r.base.incrementalContribution).toBe(1965);expect(r.warnings.join(' ')).toMatch(/floored at zero/i);
});

test('explicitly missing costs, impossible counts and commission100 are rejected instead of showing a verdict',()=>{
  const cases=[{variableCost:''},{commissionPct:' '},{paymentFeePct:95},{ancillaryCost:undefined},{stressPickupPct:0.0000001},{nights:[{...fixture().nights[0],rooms:101}]},{nights:[{...fixture().nights[0],compRooms:21}]},{nights:[{...fixture().nights[0],forecastRooms:101}]},{nights:[{...fixture().nights[0],rooms:0,compRooms:0}]}];
  for(const value of cases){const r=calculate(fixture(value));expect(r.ready,JSON.stringify(value)).toBe(false);expect(r.errors.length).toBeGreaterThan(0);assertFiniteTree(r);}
});

test('booleans, lists, objects, infinities and malformed dates cannot masquerade as numeric inputs',()=>{
  for(const variableCost of [false,true,[],[30],{},Infinity,NaN,'0x10','thirty','1e9999'])expect(calculate(fixture({variableCost})).ready).toBe(false);
  for(const input of [null,[],42,'group'])expect(calculate(input).ready).toBe(false);
  for(const nights of [[null],[[]],{},'night'])expect(calculate(fixture({nights})).ready).toBe(false);
  expect(calculate(fixture({arrival:'2030-02-30'})).ready).toBe(false);
  expect(dateNumber('1970-01-01')).toBe(0);expect(dateNumber('2030-02-30')).toBe(null);
});

test('dates are complete and bounded, duplicate/gap/night-outside-stay is rejected',()=>{
  expect(dealDates('2030-06-01','2030-06-03')).toEqual(['2030-06-01','2030-06-02']);expect(dealDates('2030-06-01','2030-06-01')).toEqual([]);expect(dealDates('2030-01-01','2030-06-01')).toEqual([]);
  for(const nights of [[...fixture().nights,fixture().nights[0]],[{...fixture().nights[0],date:'2030-06-02'}],[]])expect(checkDealInputs(fixture({nights})).errors.length).toBeGreaterThan(0);
});

test('date and user-entered minimum risks are shown without inventing a hotel policy',()=>{
  const r=calculateDeal(fixture({arrival:'2020-06-01',departure:'2020-06-02',forecastAsOf:'2020-05-01',cutoff:'2020-06-03',approvedMinRate:175,nights:[{...fixture().nights[0],date:'2020-06-01'}]}),{today:'2030-05-30'});
  expect(r.ready).toBe(true);expect(r.assessment).toBe('minimum-review');expect(r.base.minimumRate).toBe(175);expect(r.warnings.join(' ')).toMatch(/in the past/);expect(r.warnings.join(' ')).toMatch(/cutoff is after arrival/i);expect(r.assumptions.join(' ')).toMatch(/not net profit/i);
});

test('CSV export includes every night of each scenario and finite raw numbers',()=>{
  const r=calculate(fixture());const csv=dealCSV(r);expect(csv.split('\r\n')).toHaveLength(4);expect(csv).toContain('"2700"');expect(csv).toContain('"365"');expect(csv).not.toMatch(/NaN|Infinity/);expect(()=>dealCSV({ready:false})).toThrow(/Calculate/);
});
