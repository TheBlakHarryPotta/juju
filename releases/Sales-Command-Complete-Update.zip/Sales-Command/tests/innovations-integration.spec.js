import { test, expect } from '@playwright/test';

const PACKAGE_TEXT = [
 'Company: Synthetic Bridge Training LLC',
 'Group: Synthetic Summer Training',
 'Contact: Sam Example',
 'Email: sam@example.test',
 'Phone: 202-555-0101',
 'Arrival: 2027-06-04',
 'Departure: 2027-06-06',
 '10 King rooms at $149 per night',
 'Group code: 00123',
 'Next step: Send the training proposal',
].join('\n');

async function openBlank(page, route='home') {
 await page.goto('/'); await page.waitForFunction(()=>window.SC?.ready);
 await page.evaluate(async route=>{
  await SC.ready; await SC.createProperty({name:'Synthetic Innovations QA Hotel',rooms:100});
  clearTimeout(xSaveT);await SC.storage.flush();SC.navigate(route);
 },route);
}
async function snapshot(page) {
 return page.evaluate(async()=>({
  propertyId:SC.propertyId,
  state:structuredClone(SC.state),
  durable:structuredClone((await SC.storage.db.snapshots.get(SC.propertyId))?.state),
  revision:(await SC.storage.db.snapshots.get(SC.propertyId))?.revision,
 }));
}
async function capture(page,name){
 await page.mouse.move(0,0);await page.evaluate(()=>document.activeElement?.blur());
 await expect(page.locator('#toast')).not.toHaveClass(/show/);
 await page.screenshot({path:`docs/screenshots/innovations-${name}.png`,fullPage:false});
}

async function reviewPackage(page,{text=PACKAGE_TEXT,actual=false}={}){
 await page.locator('#deal-package-text').fill(text);await page.locator('[data-package-action="review"]').click();await expect(page.locator('#deal-package-review-form')).toBeVisible();
 await finishPackageForm(page,{actual});
}
async function finishPackageForm(page,{actual=false}={}){
 const form=page.locator('#deal-package-review-form');
 await form.locator('[name="nextStep"]').fill('Send the reviewed training proposal');
 const dates=await page.evaluate(()=>{const d=new Date();d.setDate(d.getDate()+3);return {today:todayISO(),due:d.toISOString().slice(0,10)}});
 await form.locator('[name="due"]').fill(dates.due);await form.locator('[name="sourceDate"]').fill(dates.today);
 await form.locator('[name="groupCode"]').fill('00123');
 const room=form.locator('[name="roomUse:0"]');if(await room.count()){
  await room.check();await form.locator('[name="roomCount:0"]').fill('10');await form.locator('[name="roomRate:0"]').fill('149');await form.locator('[name="roomOcc:0"]').selectOption('Double');await form.locator('[name="roomRepeat:0"]').check();
 }
 if(actual){await form.locator('[name="actualCall"]').check();await form.locator('[name="activityDate"]').fill(dates.today);await form.locator('[name="category"]').selectOption('prospecting');await form.locator('[name="outcome"]').fill('Actually discussed training dates and requested a proposal.');}
 await form.locator('[name="reviewed"]').check();
}
async function submitPackage(page){await page.getByRole('button',{name:'Create reviewed deal package',exact:true}).click();await expect(page.locator('#deal-package-review-form')).toHaveCount(0);await expect(page.locator('.deal-package-receipt')).toHaveCount(1);}

test('whole Call Desk transcript creates one reviewed connected package with no invented completed call',async({page})=>{
 await openBlank(page,'calls');await page.locator('[data-local-action="manual"]').click();await page.locator('#local-review-text').fill(PACKAGE_TEXT);
 await page.locator('[data-local-action="deal-package"]').click();await expect(page.locator('#local-review-dialog')).toHaveCount(0);await expect(page.locator('#deal-package-review-form')).toBeVisible();
 await expect(page.locator('#deal-package-review-form [name="account"]')).toHaveValue('Synthetic Bridge Training LLC');await expect(page.locator('#deal-package-review-form')).toContainText('10 King rooms at $149 per night');
 let state=await page.evaluate(()=>SC.state);expect(state.contracts).toHaveLength(0);expect(state.bookings).toHaveLength(0);expect(state.activities).toHaveLength(0);
 await page.locator('[data-package-action="cancel"]').click();state=await page.evaluate(()=>SC.state);expect(state.contracts).toHaveLength(0);expect(state.salesWorkflows?.prospects||[]).toHaveLength(0);
 await reviewPackage(page);const before=await snapshot(page);await submitPackage(page);
 const result=await page.evaluate(async()=>({state:SC.state,row:await SC.storage.db.snapshots.get(SC.propertyId),counts:activityCounts(),items:SC.salesWorkflows.reportItems(SC.reportRange()),text:weeklyEmailText(),files:await SC.storage.db.files.toArray()}));
 const s=result.state,p=s.salesWorkflows.prospects[0],b=s.bookings[0],c=s.contracts[0],task=s.plannedTasks[0];
 expect(s.salesWorkflows.prospects).toHaveLength(1);expect(s.bookings).toHaveLength(1);expect(s.contracts).toHaveLength(1);expect(s.plannedTasks).toHaveLength(1);expect(s.activities).toHaveLength(0);expect(result.counts.total).toBe(0);
 expect(b).toMatchObject({status:'Prospect',rn:20,rev:2980,adr:149,prospectId:p.id,contractId:c.id});expect(c).toMatchObject({status:'Draft',prospectId:p.id,bookingId:b.id});expect(c.data.signed).toBe(false);expect(c.data.groupCode).toBe('00123');expect(c.data.rooms[0]).toMatchObject({rate:149,nights:{'2027-06-04':10,'2027-06-05':10}});expect(task).toMatchObject({done:false,prospectId:p.id,bookingId:b.id,contractId:c.id});expect(p.contacted).toBe(false);
 expect(result.row.revision).toBe(before.revision+1);expect(result.row.state.innovationReceipts).toHaveLength(1);expect(result.row.state.bookings[0].id).toBe(b.id);expect(result.items).toHaveLength(1);expect(result.text.match(/Deal package prepared for Synthetic Bridge Training LLC/g)).toHaveLength(1);
 const source=result.files.find(f=>f.id===c.source.fileId);expect(source).toBeTruthy();expect(await page.evaluate(async id=>(await SC.storage.db.files.get(id)).blob.text(),source.id)).toBe(PACKAGE_TEXT);
 await page.reload();await page.waitForFunction(()=>window.SC?.ready);await page.evaluate(async()=>{await SC.ready;SC.navigate('dealPackage')});await expect(page.locator('.deal-package-receipt')).toHaveCount(1);
});

test('an explicitly completed package call reports once and package undo survives encrypted restore without deleting unrelated work',async({page})=>{
 await openBlank(page,'dealPackage');await reviewPackage(page,{actual:true});await submitPackage(page);
 const result=await page.evaluate(async()=>{SC.render();SC.render();const receipt=SC.transactions.list()[0];return{receipt,counts:activityCounts(),items:SC.salesWorkflows.reportItems(SC.reportRange()),prospects:SC.state.salesWorkflows.prospects,activities:SC.state.activities,backup:await(await SC.storage.backup('synthetic-package-backup')).text()}});
 expect(result.activities).toHaveLength(1);expect(result.prospects).toHaveLength(1);expect(result.prospects[0]).toMatchObject({contacted:true,contactActivityId:result.activities[0].id});expect(result.counts.prospecting).toBe(1);expect(result.counts.total).toBe(1);expect(result.items).toHaveLength(1);
 await page.evaluate(async backup=>{SC.state.bookings[0].notes='Temporary post-backup edit';SC.save();await SC.storage.flush();await SC.storage.restore(backup,'synthetic-package-backup');SC.commitPlannedTask({account:'Synthetic Unrelated Work',due:'2027-07-01',notes:'A later independent plan'});await SC.storage.flush()},result.backup);
 await page.reload();await page.waitForFunction(()=>window.SC?.ready);await page.evaluate(async()=>{await SC.ready;SC.navigate('dealPackage')});await page.locator(`[data-package-action="undo"][data-id="${result.receipt.id}"]`).click();
 await expect.poll(()=>page.evaluate(id=>SC.transactions.list().find(r=>r.id===id)?.status,result.receipt.id)).toBe('undone');
 const after=await page.evaluate(async()=>({state:SC.state,files:await SC.storage.db.files.count(),durable:(await SC.storage.db.snapshots.get(SC.propertyId)).state}));
 for(const s of[after.state,after.durable]){expect(s.contracts).toHaveLength(0);expect(s.bookings).toHaveLength(0);expect(s.activities).toHaveLength(0);expect(s.salesWorkflows.prospects).toHaveLength(0);expect(s.plannedTasks).toHaveLength(1);expect(s.plannedTasks[0].account).toBe('Synthetic Unrelated Work');}
 expect(after.files).toBeGreaterThan(0);
});

test('a package supplies explicit nightly needs to a reviewed forecast and only a plan emerges from the match',async({page})=>{
 await openBlank(page,'dealPackage');await reviewPackage(page);await submitPackage(page);const prospect=await page.evaluate(()=>SC.state.salesWorkflows.prospects[0]);await page.evaluate(()=>SC.navigate('needDates'));
 await page.locator('#nd-file-input').setInputFiles({name:'synthetic-GRO-reviewed.csv',mimeType:'text/csv',buffer:Buffer.from('Date,Capacity,ForecastRooms,RoomType\n2027-06-04,40,20,King\n2027-06-05,40,25,King')});await expect(page.locator('#nd-mapping-form')).toBeVisible();expect(await page.evaluate(()=>SC.state.needDateMatcher?.forecast||null)).toBeNull();
 await page.locator('#nd-mapping-form [name="asOf"]').fill(await page.evaluate(()=>todayISO()));await page.locator('#nd-mapping-form [name="reviewed"]').check();await page.getByRole('button',{name:'Commit reviewed forecast rows',exact:true}).click();
 const card=page.locator(`.nd-fit-card[data-prospect-id="${prospect.id}"]`);await expect(card).toContainText('20 of 20');await expect(card).toContainText('100%');await expect(card).toContainText('synthetic-GRO-reviewed.csv');
 await card.locator('[data-nd-action="draft"]').click();const follow=page.locator('#nd-followup-form');await expect(follow.locator('[name="outreach"]')).toContainText('2027-06-04');expect(await follow.locator('[name="outreach"]').inputValue()).not.toContain('$149');await follow.locator('[name="reviewed"]').check();await page.getByRole('button',{name:'Save planned follow-up',exact:true}).click();await expect(follow).toHaveCount(0);
 let data=await page.evaluate(()=>({tasks:SC.state.plannedTasks,activities:SC.state.activities,prospect:SC.state.salesWorkflows.prospects[0],counts:activityCounts()}));expect(data.tasks).toHaveLength(2);expect(data.activities).toHaveLength(0);expect(data.counts.total).toBe(0);expect(data.prospect.contacted).toBe(false);
 await card.locator('[data-nd-action="draft"]').click();await page.locator('#nd-followup-form [name="reviewed"]').check();await page.getByRole('button',{name:'Save planned follow-up',exact:true}).click();await expect(page.locator('#nd-modal-error')).toContainText('already exists');expect(await page.evaluate(()=>SC.state.plannedTasks.length)).toBe(2);await page.locator('#nd-followup-form [data-nd-action="close"]').click();
 await page.evaluate(()=>{const d=new Date();d.setDate(d.getDate()-30);SC.needDates.importForecast({asOf:d.toISOString().slice(0,10),sourceName:'Synthetic stale report',reviewed:true,rows:[{date:'2027-06-04',capacity:40,forecastRooms:20,roomType:'King'},{date:'2027-06-05',capacity:40,forecastRooms:25,roomType:'King'}]})});await expect(page.locator('.nd-fit-card')).toHaveCount(0);await expect(page.locator('.nd-unscored')).toContainText('days old');
 await page.evaluate(()=>SC.needDates.importForecast({asOf:todayISO(),sourceName:'Synthetic missing-night report',reviewed:true,rows:[{date:'2027-06-04',capacity:40,forecastRooms:20,roomType:'King'}]}));await expect(page.locator('.nd-fit-card')).toHaveCount(0);await expect(page.locator('.nd-unscored')).toContainText('2027-06-05');
 await page.evaluate(async()=>{await SC.createProperty({name:'Synthetic Other Innovations Hotel',rooms:80});SC.navigate('needDates')});await expect(page.locator('.nd-fit-card')).toHaveCount(0);expect(await page.evaluate(()=>SC.state.needDateMatcher?.forecast||null)).toBeNull();await expect(page.locator('#view')).not.toContainText('Synthetic Bridge Training LLC');
});

test('past package closeout records actuals separately, protects history from undo, and creates one fresh dated repeat opportunity',async({page})=>{
 await openBlank(page,'dealPackage');
 const dates=await page.evaluate(()=>{const day=n=>{const d=new Date();d.setDate(d.getDate()+n);return d.toISOString().slice(0,10)};return{arrive:day(-5),depart:day(-3),today:day(0),windowStart:day(30),windowEnd:day(45)}});
 await reviewPackage(page,{text:PACKAGE_TEXT.replaceAll('2027-06-04',dates.arrive).replaceAll('2027-06-06',dates.depart)});await submitPackage(page);
 const original=await page.evaluate(()=>({booking:SC.state.bookings[0],receipt:SC.transactions.list()[0]}));await page.evaluate(()=>SC.navigate('repeatBusiness'));await page.locator('[data-rb-action="new"]').click();
 const closeout=page.locator('#rb-closeout-form');await closeout.locator('[name="linkedSource"]').selectOption('booking:'+original.booking.id);await expect(closeout.locator('[name="contractedRn"]')).toHaveValue('20');await expect(closeout.locator('[name="actualRn"]')).toHaveValue('');await expect(closeout.locator('[name="actualRevenue"]')).toHaveValue('');
 await closeout.locator('[name="actualRn"]').fill('18');await closeout.locator('[name="actualRevenue"]').fill('2682');await closeout.locator('[name="sourceName"]').fill('Synthetic stayed-production summary');await closeout.locator('[name="asOf"]').fill(dates.today);await closeout.locator('[name="outcome"]').fill('18 of the contracted 20 room nights stayed. Discuss next training cycle.');await closeout.locator('[name="preferences"]').fill('Business preference: early training-room access.');await closeout.locator('[name="reviewed"]').check();await page.getByRole('button',{name:'Save reviewed closeout',exact:true}).click();await expect(closeout).toHaveCount(0);
 const memory=await page.evaluate(()=>SC.repeatBusiness.memories()[0]);expect(memory.actuals).toMatchObject({rn:18,revenue:2682,adr:149});expect(memory.contracted).toMatchObject({rn:20,revenue:2980,adr:149});expect(await page.evaluate(id=>SC.state.bookings.find(b=>b.id===id).rev,original.booking.id)).toBe(2980);expect(await page.evaluate(()=>SC.state.activities.length)).toBe(0);
 await page.evaluate(()=>SC.navigate('dealPackage'));await page.locator(`[data-package-action="undo"][data-id="${original.receipt.id}"]`).click();await expect(page.locator('#toast')).toContainText(/refers|history/i);expect(await page.evaluate(()=>SC.state.contracts.length)).toBe(1);expect(await page.evaluate(()=>SC.repeatBusiness.memories().length)).toBe(1);
 await page.evaluate(()=>SC.navigate('repeatBusiness'));await page.locator(`[data-rb-action="reminder"][data-id="${memory.id}"]`).click();const reminder=page.locator('#rb-reminder-form');await reminder.locator('[name="windowStart"]').fill(dates.windowStart);await reminder.locator('[name="windowEnd"]').fill(dates.windowEnd);await reminder.locator('[name="leadDays"]').fill('30');await reminder.locator('[data-rb-action="suggest-date"]').click();await expect(reminder.locator('[name="date"]')).toHaveValue(dates.today);await page.getByRole('button',{name:'Save reminder',exact:true}).click();await expect(reminder).toHaveCount(0);await expect(page.locator('#rb-reminder-queue')).toContainText('Synthetic Bridge Training LLC');
 async function cycle(){await page.locator(`[data-rb-action="cycle"][data-id="${memory.id}"]`).first().click();const form=page.locator('#rb-cycle-form');await expect(form.locator('[name="arrive"]')).toHaveValue('');await expect(form.locator('[name="depart"]')).toHaveValue('');await form.locator('[name="label"]').fill('Synthetic 2027 Training');await form.locator('[name="arrive"]').fill('2027-08-10');await form.locator('[name="depart"]').fill('2027-08-12');await form.locator('[name="confirmedNewDates"]').check();await page.getByRole('button',{name:'Create fresh opportunity & prospect',exact:true}).click();await expect(form).toHaveCount(0);}
 await cycle();await cycle();
 const result=await page.evaluate(()=>({bookings:SC.state.bookings,prospects:SC.state.salesWorkflows.prospects,cycles:SC.state.repeatBusiness.cycles,activities:SC.state.activities,queue:SC.repeatBusiness.queue()}));expect(result.bookings).toHaveLength(2);expect(result.prospects).toHaveLength(2);expect(result.cycles).toHaveLength(1);expect(result.activities).toHaveLength(0);expect(result.queue).toHaveLength(0);
 const fresh=result.bookings.find(b=>b.id!==original.booking.id);expect(fresh).toMatchObject({status:'Prospect',arrive:'2027-08-10',depart:'2027-08-12',rn:0,adr:0,rev:0});expect(result.prospects.find(p=>p.id===result.cycles[0].prospectId)).toMatchObject({status:'New',contacted:false});
 const backup=await page.evaluate(async()=>await(await SC.storage.backup('synthetic-repeat-backup')).text());await page.evaluate(async b=>{SC.state.repeatBusiness.memories=[];SC.save();await SC.storage.flush();await SC.storage.restore(b,'synthetic-repeat-backup')},backup);await page.reload();await page.waitForFunction(()=>window.SC?.ready);await page.evaluate(async()=>{await SC.ready;SC.navigate('repeatBusiness')});expect(await page.evaluate(()=>SC.repeatBusiness.memories()[0].actuals.rn)).toBe(18);expect(await page.evaluate(()=>SC.state.repeatBusiness.cycles.length)).toBe(1);
});

test('Import Station sends a whole conversation to package review and shared follow-ups log actual results before blocking prior undo',async({page})=>{
 await openBlank(page,'captureStation');await page.locator('#si-destination').selectOption('dealPackage');await page.locator('.si-paste summary').click();await page.locator('#si-paste').fill(PACKAGE_TEXT);await page.locator('[data-si="paste"]').click();await expect(page.locator('#deal-package-review-form')).toBeVisible();expect(await page.evaluate(()=>SC.state.bookings.length)).toBe(0);await finishPackageForm(page);await submitPackage(page);
 const ids=await page.evaluate(()=>({task:SC.state.plannedTasks[0].id,receipt:SC.transactions.list()[0].id,today:todayISO(),due:SC.state.plannedTasks[0].due}));await page.evaluate(()=>SC.navigate('followUps'));await page.locator(`[data-fu="complete"][data-id="${ids.task}"]`).click();const form=page.locator('#fu-complete-form');await form.locator('[name="date"]').fill(ids.due);await form.locator('[name="outcome"]').fill('Actually discussed the next training proposal.');await page.getByRole('button',{name:'Save completed follow-up',exact:true}).click();await expect(page.locator('#fu-error')).toContainText('not a future plan');expect(await page.evaluate(()=>SC.state.activities.length)).toBe(0);
 await form.locator('[name="date"]').fill(ids.today);await page.getByRole('button',{name:'Save completed follow-up',exact:true}).click();await expect(form).toHaveCount(0);const result=await page.evaluate(()=>({activities:SC.state.activities,tasks:SC.state.plannedTasks,counts:activityCounts(),items:SC.salesWorkflows.reportItems(SC.reportRange())}));expect(result.activities).toHaveLength(1);expect(result.activities[0]).toMatchObject({date:ids.today,type:'followup',outcome:'Actually discussed the next training proposal.'});expect(result.tasks[0].done).toBe(true);expect(result.counts.total).toBe(1);expect(result.counts.prospecting).toBe(0);expect(result.items).toHaveLength(2);
 await page.locator(`[data-fu="undo"][data-id="${ids.receipt}"]`).click();await expect(page.locator('#fu-status')).toContainText(/changed|later work/i);expect(await page.evaluate(()=>SC.state.bookings.length)).toBe(1);expect(await page.evaluate(()=>SC.state.activities.length)).toBe(1);
});

test('a complete phone package review and populated innovation views fit desktop and phone screens',async({page})=>{
 await page.setViewportSize({width:390,height:844});await openBlank(page,'dealPackage');await reviewPackage(page);expect(await page.evaluate(()=>document.documentElement.scrollWidth)).toBe(390);await submitPackage(page);
 await page.evaluate(async()=>{
  SC.needDates.importForecast({asOf:todayISO(),sourceName:'Synthetic reviewed King forecast',reviewed:true,rows:[{date:'2027-06-04',capacity:40,forecastRooms:20,roomType:'King'},{date:'2027-06-05',capacity:40,forecastRooms:25,roomType:'King'}]});
  const date=n=>{const d=new Date();d.setDate(d.getDate()+n);return d.toISOString().slice(0,10)};
  const m=await SC.repeatBusiness.closeout({account:'Synthetic Bridge Training LLC',event:'Synthetic Completed Training',arrive:date(-5),depart:date(-3),actualRn:18,actualRevenue:2682,contractedRn:20,contractedRevenue:2980,sourceName:'Synthetic stayed-production summary',asOf:todayISO(),reviewed:true,sourceKind:'manual',organizer:'Sam Example',preferences:'Coordinate training-room access.',outcome:'18 room nights stayed; discuss a future planning window.'});
  await SC.repeatBusiness.planReminder(m.id,{date:todayISO(),windowStart:date(30),windowEnd:date(45),leadDays:30});await SC.storage.flush();
 });
 const errors=[];page.on('pageerror',e=>errors.push(e.message));
 for(const[device,width,height]of[['desktop',1440,1000],['phone',390,844]]){
  await page.setViewportSize({width,height});for(const[route,name]of[['dealPackage','deal-package'],['needDates','need-dates'],['repeatBusiness','repeat-business']]){
   await page.evaluate(route=>SC.navigate(route),route);await expect(page.locator('#view')).not.toBeEmpty();expect(await page.evaluate(()=>document.documentElement.scrollWidth)).toBe(width);await capture(page,`${name}-${device}`);
  }
 }
 expect(errors).toEqual([]);
});

test('a previously logged Call Desk source cannot count again when it becomes a deal package',async({page})=>{
 await openBlank(page,'calls');await page.locator('[data-local-action="manual"]').click();await page.locator('#local-review-text').fill(PACKAGE_TEXT);await page.locator('[data-local-action="suggest"]').click();await page.locator('#local-review-form [name="activityType"]').selectOption('prospecting');await page.locator('#local-review-form [name="confirmed"]').check();await page.getByRole('button',{name:'Confirm & add reviewed draft',exact:true}).click();await expect(page.locator('#local-review-dialog')).toHaveCount(0);
 const before=await page.evaluate(()=>({activity:SC.state.activities[0],prospect:SC.state.salesWorkflows.prospects[0]}));expect(await page.evaluate(()=>activityCounts().prospecting)).toBe(1);
 await page.evaluate(()=>SC.navigate('intake'));await page.locator('[data-local-action="review"]').first().click();await page.locator('[data-local-action="deal-package"]').click();await finishPackageForm(page,{actual:true});await page.getByRole('button',{name:'Create reviewed deal package',exact:true}).click();await expect(page.locator('#deal-package-error')).toContainText(/already|source.*call|call.*source/i);expect(await page.evaluate(()=>SC.state.activities.length)).toBe(1);expect(await page.evaluate(()=>SC.state.bookings.length)).toBe(0);expect(await page.evaluate(()=>SC.state.contracts.length)).toBe(0);
 await page.locator('#deal-package-review-form [name="actualCall"]').uncheck();await page.locator('#deal-package-review-form [name="existingProspect"]').selectOption(before.prospect.id);await page.locator('#deal-package-review-form [name="overwriteExisting"]').check();await submitPackage(page);
 const result=await page.evaluate(()=>({activities:SC.state.activities,prospects:SC.state.salesWorkflows.prospects,bookings:SC.state.bookings,counts:activityCounts()}));expect(result.activities).toHaveLength(1);expect(result.activities[0].id).toBe(before.activity.id);expect(result.prospects).toHaveLength(1);expect(result.prospects[0].id).toBe(before.prospect.id);expect(result.bookings).toHaveLength(1);expect(result.counts.prospecting).toBe(1);
});

test('package preparation follows its actual date when an old report week was selected',async({page})=>{
 await openBlank(page,'dealPackage');const dates=await page.evaluate(async()=>{const current=SC.state.reportDate,d=new Date(current+'T00:00:00Z');d.setUTCDate(d.getUTCDate()-28);const old=d.toISOString().slice(0,10);SC.state.reportDate=old;SC.save();await SC.storage.flush();return{current,old}});
 await reviewPackage(page);await submitPackage(page);
 expect(await page.evaluate(()=>SC.state.reportDate)).toBe(dates.old);expect(await page.evaluate(old=>weeklyEmailText(old),dates.old)).not.toContain('Deal package prepared for Synthetic Bridge Training LLC');
 const result=await page.evaluate(async current=>{SC.state.reportDate=current;SC.save();await SC.storage.flush();SC.navigate('weekly');return{text:weeklyEmailText(),items:SC.salesWorkflows.reportItems(SC.reportRange()),counts:activityCounts(),activities:SC.state.activities}},dates.current);
 expect(result.text.match(/Deal package prepared for Synthetic Bridge Training LLC/g)).toHaveLength(1);expect(result.items).toHaveLength(1);expect(result.items[0].kind).toBe('highlight');expect(result.activities).toHaveLength(0);expect(result.counts.total).toBe(0);
});
