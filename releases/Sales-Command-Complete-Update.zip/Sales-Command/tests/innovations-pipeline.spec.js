import {test,expect} from '@playwright/test';
async function open(page){await page.goto('/');await page.waitForFunction(()=>window.SC?.ready);await page.evaluate(async()=>{await SC.ready;await SC.createProperty({name:'Synthetic Pipeline Compatibility Hotel',rooms:100});SC.navigate('dealPackage')});}
async function packageBooking(page,{mixed=false}={}){
 await open(page);const text='Company: Synthetic Pipeline Company\nEvent: Synthetic Training\nContact: Sam Example\nArrival: 2027-06-04\nDeparture: 2027-06-06\n10 King rooms at $149 per night'+(mixed?' and 5 Double/Double rooms at $149 per night':'');await page.locator('#deal-package-text').fill(text);await page.locator('[data-package-action="review"]').click();
 const f=page.locator('#deal-package-review-form');await f.locator('[name="nextStep"]').fill('Confirm the reviewed training proposal');await f.locator('[name="due"]').fill('2027-05-01');
 for(let i=0;i<(mixed?2:1);i++){await f.locator(`[name="roomUse:${i}"]`).check();await f.locator(`[name="roomOcc:${i}"]`).selectOption('Double');await f.locator(`[name="roomRepeat:${i}"]`).check();}
 await f.locator('[name="reviewed"]').check();await page.getByRole('button',{name:'Create reviewed deal package',exact:true}).click();await expect(f).toHaveCount(0);return page.evaluate(()=>structuredClone(SC.state.bookings[0]));
}
async function editor(page,id){await page.evaluate(()=>SC.navigate('pipeline'));if(!await page.locator('.pp-ed').isVisible())await page.locator(`.deal[data-act="ppOpen"][data-v="${id}"]`).click();await expect(page.locator('.pp-ed')).toBeVisible();}
function field(page,id,name){return page.locator(`.pp-ed [data-p="bookings.#${id}.${name}"]`);}
async function edit(page,id,name,value){await field(page,id,name).fill(String(value));await field(page,id,name).press('Tab');}
async function expectTransfer(page,rooms,rate,dates=['2027-06-04','2027-06-05']){
 await page.locator('.pp-ed [data-act="ppDeal"]').click();await expect(page.locator('#dc-form')).toBeVisible();const quote=Number(await page.locator('[data-dc-field="rate"]').inputValue());expect(quote).toBe(rate);
 for(const date of dates){await expect(page.locator(`[data-dc-night="${date}"][data-dc-column="rooms"]`)).toHaveValue(String(rooms));const override=await page.locator(`[data-dc-night="${date}"][data-dc-column="rate"]`).inputValue();expect(override===''?quote:Number(override)).toBe(rate);await expect(page.locator(`[data-dc-night="${date}"][data-dc-column="forecastRooms"]`)).toHaveValue('');await expect(page.locator(`[data-dc-night="${date}"][data-dc-column="compRooms"]`)).toHaveValue('');}
 await expect(page.locator('[data-dc-field="variableCost"]')).toHaveValue('');
}

test('a reviewed King package remains editable in Pipeline and transfers its current UUID counts and price',async({page})=>{
 const b=await packageBooking(page);expect(b.id).toContain('-');await editor(page,b.id);await expect(field(page,b.id,'wantK')).toHaveValue('10');await expect(field(page,b.id,'rate')).toHaveValue('149');await expect(page.locator('.pp-ed [data-k="source"][data-v="Other"]')).toHaveClass(/on/);
 await edit(page,b.id,'rate',159);await expect.poll(()=>page.evaluate(id=>{const b=SC.state.bookings.find(b=>b.id===id);return{rn:b.rn,adr:b.adr,rev:b.rev}},b.id)).toEqual({rn:20,adr:159,rev:3180});
 await page.locator('.pp-ed [data-act="ppStatus"][data-v="Definite"]').click();const result=await page.evaluate(id=>({booking:SC.state.bookings.find(b=>b.id===id),contract:SC.state.contracts[0],total:pipelineTotals().Definite}),b.id);expect(result.contract.status).toBe('Draft');expect(result.contract.data.signed).toBe(false);expect(result.contract.data.rooms[0].rate).toBe(149);expect(result.booking.rev).toBe(3180);expect(result.total).toBe(3180);
 await expectTransfer(page,10,159);
});

test('unsupported Double Double stays intact instead of becoming Queen or a partial legacy block',async({page})=>{
 const b=await packageBooking(page,{mixed:true});expect(b).toMatchObject({rn:30,adr:149,rev:4470,wantK:0,wantQQ:0,wantROH:0});await editor(page,b.id);const custom=page.locator('.sc-package-allocation-review');await expect(custom).toBeVisible();await expect(custom).toContainText('King');await expect(custom).toContainText('Two Double Beds');await expect(custom).toContainText('30 reviewed room nights');expect(await field(page,b.id,'wantQQ').count()).toBe(0);
 await edit(page,b.id,'rate',159);const result=await page.evaluate(id=>({booking:SC.state.bookings.find(b=>b.id===id),rooms:SC.state.contracts[0].data.rooms}),b.id);expect(result.booking).toMatchObject({rn:30,adr:159,rev:4770,wantK:0,wantQQ:0,wantROH:0});expect(result.rooms.map(r=>r.type)).toEqual(['King','Two Double Beds']);expect(result.rooms.every(r=>r.rate===149)).toBe(true);
 await expectTransfer(page,15,159);
});

test('fresh repeat UUID opportunities recalculate native room edits and Definite does not sign their new contract',async({page})=>{
 await open(page);const b=await page.evaluate(async()=>{const date=n=>{const d=new Date();d.setDate(d.getDate()+n);return d.toISOString().slice(0,10)};const m=await SC.repeatBusiness.closeout({account:'Synthetic Returning Company',event:'Synthetic Past Meeting',organizer:'Sam Example',email:'sam@example.test',phone:'202-555-0101',arrive:date(-5),depart:date(-3),actualRn:18,actualRevenue:2682,sourceKind:'manual',sourceName:'Synthetic stayed-production report',asOf:todayISO(),reviewed:true});const cycle=await SC.repeatBusiness.createCycle(m.id,{label:'Synthetic New Season',arrive:'2027-08-10',depart:'2027-08-12',confirmedNewDates:true});return structuredClone(SC.state.bookings.find(b=>b.id===cycle.bookingId))});
 expect(b.id).toContain('-');expect(b).toMatchObject({rn:0,adr:0,rev:0,email:'sam@example.test',phone:'202-555-0101',source:'Other'});await editor(page,b.id);await edit(page,b.id,'wantK',5);await edit(page,b.id,'rate',149);await expect.poll(()=>page.evaluate(id=>{const b=SC.state.bookings.find(b=>b.id===id);return{rn:b.rn,adr:b.adr,rev:b.rev}},b.id)).toEqual({rn:10,adr:149,rev:1490});
 const manual=await page.evaluate(id=>{const b=SC.state.bookings.find(b=>b.id===id);b.revManual=true;b.rev=1234;ppSync(b);const out={manual:b.revManual,rev:b.rev};b.revManual=false;ppSync(b);SC.save();return out},b.id);expect(manual).toEqual({manual:true,rev:1234});
 await expectTransfer(page,5,149,['2027-08-10','2027-08-11']);await editor(page,b.id);await page.locator('.pp-ed [data-act="ppContract"]').click();await expect.poll(()=>page.evaluate(()=>SC.state.contracts.length)).toBe(1);await editor(page,b.id);await page.locator('.pp-ed [data-act="ppStatus"][data-v="Definite"]').click();expect(await page.evaluate(()=>SC.state.contracts[0].status)).toBe('Draft');expect(await page.evaluate(()=>SC.state.contracts[0].data.signed)).toBe(false);expect(await page.evaluate(()=>SC.state.activities.length)).toBe(0);expect(await page.evaluate(()=>activityCounts().rfps)).toBe(0);
 await page.locator('[data-act="ppNew"]').click();const ordinary=await page.evaluate(()=>SC.state.bookings.at(-1).id);await edit(page,ordinary,'name','Synthetic actual legacy inquiry');await page.locator('.pp-ed [data-act="ppSet"][data-k="source"][data-v="Other"]').click();const tally=await page.evaluate(()=>activityCounts());expect(tally.rfps).toBe(1);expect(tally.total).toBe(1);expect(tally.prospecting).toBe(0);
});
