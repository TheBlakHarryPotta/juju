import { test, expect } from '@playwright/test';

import { Document, Packer, Paragraph } from 'docx';
import PizZip from 'pizzip';
async function open(page, view = 'intake') {
  await page.goto('/'); await page.waitForFunction(() => window.SC?.ready);
  await page.evaluate(async view => { await SC.ready; SC.navigate(view); }, view);
}
function pdf(text) {
  const content = `BT /F1 20 Tf 50 730 Td (${text}) Tj ET`;
  const objects = ['<< /Type /Catalog /Pages 2 0 R >>', '<< /Type /Pages /Kids [3 0 R] /Count 1 >>', '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>', '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>', `<< /Length ${Buffer.byteLength(content)} >>\nstream\n${content}\nendstream`];
  let output = '%PDF-1.4\n'; const offsets = [0];
  objects.forEach((object, index) => { offsets.push(Buffer.byteLength(output)); output += `${index + 1} 0 obj\n${object}\nendobj\n`; });
  const start = Buffer.byteLength(output); output += `xref\n0 6\n0000000000 65535 f \n${offsets.slice(1).map(offset => String(offset).padStart(10, '0') + ' 00000 n \n').join('')}trailer\n<< /Size 6 /Root 1 0 R >>\nstartxref\n${start}\n%%EOF`;
  return Buffer.from(output);
}
function workbook() {
  const zip = new PizZip();
  zip.file('[Content_Types].xml', '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>');
  zip.file('xl/workbook.xml', '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Production" sheetId="1" r:id="rId1"/></sheets></workbook>');
  zip.file('xl/_rels/workbook.xml.rels', '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>');
  zip.file('xl/worksheets/sheet1.xml', '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData><row r="1"><c r="A1" t="inlineStr"><is><t>QA HOTEL</t></is></c><c r="B1" t="inlineStr"><is><t>00123</t></is></c><c r="C1"><v>15</v></c></row></sheetData></worksheet>');
  return zip.generate({ type: 'nodebuffer' });
}
async function intake(page, items) {
  return page.evaluate(async items => {
    const files = items.map(item => new File([Uint8Array.from(atob(item.base64), c => c.charCodeAt(0))], item.name, { type: item.type }));
    return (await SC.intakeFiles(files)).map(({ id, name, status, text, kind, coverage, details, error }) => ({ id, name, status, text, kind, coverage, details, error }));
  }, items.map(item => ({ ...item, base64: item.buffer.toString('base64'), buffer: undefined })));
}

test('text, CSV, DOCX and PDF extract locally while originals remain downloadable', async ({ page }) => {
  await open(page);
  const docx = await Packer.toBuffer(new Document({ sections: [{ children: [new Paragraph('QA HOTEL contract for ACME 00123')] }] }));
  const results = await intake(page, [
    { name: 'notes.txt', type: 'text/plain', buffer: Buffer.from('Company: QA ACME\nContact: Jo Smith\nGroup: Hockey 30 rooms $149 per night') },
    { name: 'production.csv', type: 'text/csv', buffer: Buffer.from('Company,RN,Code\nQA ACME,10,00123') },
    { name: 'contract.docx', type: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', buffer: docx },
    { name: 'proposal.pdf', type: 'application/pdf', buffer: pdf('QA HOTEL proposal for ACME 00123') },
    { name: 'production.xlsx', type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', buffer: workbook() },
  ]);
  expect(results).toHaveLength(5);
  for (const row of results) { expect(row.status, `${row.name}: ${row.error}`).toBe('review'); expect(row.text).toMatch(/QA (?:ACME|HOTEL)/); }
  expect(results.find(r => r.kind === 'pdf').details).toMatchObject({ pagesInspected: 1, totalPages: 1, ocrPages: 0 });
  expect(results.find(r => r.kind === 'csv').text).toContain('00123');
  expect(results.find(r => r.kind === 'xlsx').text).toContain('00123');
  const saved = await page.evaluate(async () => (await SC.storage.db.files.toArray()).map(f => ({ size: f.blob.size, originalSize: f.size })));
  expect(saved.every(f => f.size === f.originalSize && f.size > 0)).toBe(true);
  const download = page.waitForEvent('download');
  await page.locator(`[data-local-action="download"][data-file-id="${results[0].id}"]`).click();
  expect((await download).suggestedFilename()).toBe('notes.txt');
});

test('screenshot OCR uses local assets and extracts readable sales text', async ({ page }) => {
  test.setTimeout(120_000);
  const remote = []; page.on('request', request => { const u = new URL(request.url()); if (['http:', 'https:'].includes(u.protocol) && !['127.0.0.1', 'localhost'].includes(u.hostname)) remote.push(u.origin); });
  await open(page);
  const result = await page.evaluate(async () => {
    const canvas = document.createElement('canvas'); canvas.width = 1200; canvas.height = 240;
    const ctx = canvas.getContext('2d'); ctx.fillStyle = 'white'; ctx.fillRect(0, 0, 1200, 240); ctx.fillStyle = 'black'; ctx.font = 'bold 56px Arial'; ctx.fillText('QA HOTEL CORPORATE SALES', 30, 90); ctx.font = '44px Arial'; ctx.fillText('Company: ACME   Code: 00123', 30, 175);
    const blob = await new Promise(resolve => canvas.toBlob(resolve, 'image/png'));
    const [row] = await SC.intakeFiles([new File([blob], 'screenshot.png', { type: 'image/png' })]);
    return { status: row.status, text: row.text, coverage: row.coverage, details: row.details, error: row.error };
  });
  expect(result.status, result.error).toBe('review');
  expect(result.text).toMatch(/HOTEL/); expect(result.text).toMatch(/CORPORATE/);
  expect(result.details.confidence).toBeGreaterThan(50);
  expect(remote).toEqual([]);
});

test('upload extraction never commits sales fields before explicit review confirmation', async ({ page }) => {
  await open(page);
  const before = await page.evaluate(() => state.accounts.length);
  const [file] = await intake(page, [{ name: 'account.txt', type: 'text/plain', buffer: Buffer.from('Company: QA Reviewed Company\nContact: Jo Smith\nEmail: jo@example.test') }]);
  expect(await page.evaluate(() => state.accounts.length)).toBe(before);
  await page.locator(`[data-local-action="review"][data-file-id="${file.id}"]`).click();
  await page.locator('#local-review-form [name="destination"]').selectOption('account');
  await expect(page.locator('#local-review-form [name="account"]')).toHaveValue('QA Reviewed Company');
  await page.locator('#local-review-form [name="confirmed"]').check();
  await page.getByRole('button', { name: 'Confirm & add reviewed draft', exact: true }).click();
  await expect(page.locator('#local-review-dialog')).toHaveCount(0);
  expect(await page.evaluate(() => state.accounts.find(a => a.name === 'QA Reviewed Company')?.contacts[0]?.name)).toBe('Jo Smith');
  const draft = await page.evaluate(async () => (await SC.storage.db.records.toArray()).find(r => r.type === 'reviewed-account'));
  expect(draft.status).toBe('committed'); expect(draft.source.fileId).toBe(file.id);
});

test('drag and drop captures section context and hostile HTML stays an inert original', async ({ page }) => {
  await open(page, 'pipeline');
  await page.evaluate(() => {
    const transfer = new DataTransfer(); transfer.items.add(new File(['<script>window.__qaUploadExecuted=1</script>'], 'unsafe.html', { type: 'text/html' }));
    document.getElementById('view').dispatchEvent(new DragEvent('drop', { bubbles: true, cancelable: true, dataTransfer: transfer }));
  });
  await expect.poll(() => page.evaluate(async () => SC.storage.db.files.count())).toBe(1);
  await expect.poll(() => page.evaluate(async () => (await SC.storage.db.files.toArray())[0]?.status)).toBe('attachment');
  const result = await page.evaluate(async () => { const f = (await SC.storage.db.files.toArray())[0]; return { context: f.contextView, contents: await f.blob.text(), ran: window.__qaUploadExecuted || false }; });
  expect(result.context).toBe('pipeline'); expect(result.contents).toContain('<script>'); expect(result.ran).toBe(false);
});

test('repeated uploads deduplicate within a hotel and reject over-limit files', async ({ page }) => {
  await open(page);
  const input = [{ name: 'duplicate.txt', type: 'text/plain', buffer: Buffer.from('QA duplicate source') }];
  const first = await intake(page, input), second = await intake(page, input);
  expect(second[0].id).toBe(first[0].id);
  expect(await page.evaluate(async () => SC.storage.db.files.count())).toBe(1);
  const result = await page.evaluate(async () => SC.intakeFiles([new File([new Uint8Array(SC.intakeLimits.fileBytes + 1)], 'too-large.bin')]));
  expect(result).toEqual([]); expect(await page.evaluate(async () => SC.storage.db.files.count())).toBe(1);
});

test('manual call transcript stays editable and can be reviewed into an activity', async ({ page }) => {
  await open(page, 'calls');
  await page.locator('[data-local-action="manual"]').click();
  await page.locator('#local-review-text').fill('Company: QA Call Company\nContact: Alex\nDiscussed 30 rooms at $149 per night.');
  await page.locator('[data-local-action="suggest"]').click();
  await expect(page.locator('#local-review-form [name="account"]')).toHaveValue('QA Call Company');
  await page.locator('#local-review-form [name="notes"]').fill('Follow up on 30-room proposal.');
  await page.locator('#local-review-form [name="confirmed"]').check();
  await page.getByRole('button', { name: 'Confirm & add reviewed draft', exact: true }).click();
  await expect(page.locator('#local-review-dialog')).toHaveCount(0);
  expect(await page.evaluate(() => state.activities.some(a => a.account === 'QA Call Company' && /30-room/.test(a.notes)))).toBe(true);
});
