import { test, expect } from '@playwright/test';
import { spawn } from 'node:child_process';
import fs from 'node:fs/promises';
import path from 'node:path';
const suites = ['unit', 'inv', 'drilltest', 'enttest', 'smoke', 'v3', 'v4', 'fuzz', 'cherry'];
for (const name of suites) {
  test(`handoff baseline: ${name}`, async ({}, testInfo) => {
    test.setTimeout(120_000);
    test.skip(name === 'v3', 'The host AI screenshot tray was replaced by local intake; actual screenshot OCR and local format tests cover the replacement.');
    const output = testInfo.outputPath('legacy-output'); await fs.mkdir(output, { recursive: true });
    const result = await new Promise((resolve, reject) => {
      const child = spawn(process.execPath, [path.resolve('tests/legacy', `${name}.cjs`)], { cwd: output, env: { ...process.env, FORCE_COLOR: '0' } });
      let stdout = '', stderr = '';
      child.stdout.on('data', chunk => { stdout += chunk; }); child.stderr.on('data', chunk => { stderr += chunk; });
      child.on('error', reject); child.on('close', code => resolve({ code, stdout, stderr }));
    });
    await testInfo.attach('baseline-output', { body: result.stdout + result.stderr, contentType: 'text/plain' });
    expect(result.code, result.stderr).toBe(0);
    if (name === 'fuzz') { expect(result.stdout).toMatch(/clicks \d+/); expect(result.stdout).toContain('NO ERRORS'); }
    else expect(result.stdout).toMatch(/ERRS none/);
    if (name === 'inv') { const metrics = JSON.parse(result.stdout.split('\n')[0]); expect(metrics.checks).toBe(720); expect(metrics.fail).toEqual([]); }
    if (name === 'smoke') {
      expect(result.stdout).toContain('XSS pwned = 0');
      expect(result.stdout).toMatch(/FO_CASES .*"A":\[2200,0,2200\].*"B":\[-1400,25,-1400\].*"C":\[140,7,-100\].*"over":\[-1600,20,-1600\]/);
      expect(result.stdout).toContain('"kept":true');
    }
    if (name === 'drilltest') expect(result.stdout).toContain('"match": true');
    if (name === 'v4') {
      const data = JSON.parse(result.stdout.split('\n')[0]);
      expect(data.ring.count).toBe(4);
      expect(data.bt1.find(row => row[0] === 'Westinghouse').slice(1, 4)).toEqual([8, 107.25, 858]);
      expect(data.bt1.find(row => row[0] === 'Omnicell').slice(1, 4)).toEqual([12, 135, 1620]);
    }
  });
}
