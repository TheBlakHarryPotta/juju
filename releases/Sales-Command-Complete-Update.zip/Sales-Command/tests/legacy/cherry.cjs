const { chromium } = require('playwright'); const path = require('path');
(async () => { const b = await chromium.launch({executablePath:process.env.CHROMIUM_PATH || '/usr/bin/chromium',args:['--no-sandbox']}); const p = await (await b.newContext({ viewport: { width: 1280, height: 800 } })).newPage(); const errs = []; p.on('pageerror', e => errs.push(e.message));
 await p.goto(process.env.SC_TEST_URL || 'http://127.0.0.1:5173'); await p.waitForTimeout(1400);
 const r = await p.evaluate(async () => { const out = {}; const oh = Date.prototype.getHours;
  for (const [n, hr] of [['dawn', 6], ['day', 12], ['dusk', 19], ['night', 23]]) { Date.prototype.getHours = () => hr; view = 'home'; render(); await new Promise(r => setTimeout(r, 150)); out[n] = !!document.querySelector('canvas.x-sky'); }
  state.settings.goals.tours = 1; view = 'home'; render(); document.querySelector('.gring[data-v="tours"]').click(); await new Promise(r => setTimeout(r, 200));
  document.querySelector('#xGoalF [name=account]').value = 'Bayer'; document.querySelector('[data-act="xGoalLog"]').click(); await new Promise(r => setTimeout(r, 150));
  out.confetti = [...document.querySelectorAll("body > canvas")].length; await new Promise(r => setTimeout(r, 400)); out.toast = document.getElementById('toast').textContent; xModalClose(); return out; });
 await p.waitForTimeout(2600); await p.screenshot({ path: 'c-night.png', scale: 'css' }); console.log(JSON.stringify(r), 'ERRS', errs.length ? errs : 'none'); await b.close(); })();
