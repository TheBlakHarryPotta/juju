const { chromium } = require('playwright'); const path = require('path');
(async () => {
  const b = await chromium.launch({executablePath:process.env.CHROMIUM_PATH || '/usr/bin/chromium',args:['--no-sandbox']}); const ctx = await b.newContext({ viewport: { width: 1440, height: 900 } });
  await ctx.addInitScript(() => { window.SC_ALLOW_EXTERNAL_PROCESSING = true;
    const store = {}; const mk = p => ({ get: async () => ({ exists: p in store, data: () => store[p] }), set: async d => { store[p] = d; }, delete: async () => { delete store[p]; }, onSnapshot: () => () => { } });
    const sample = async (p, o) => { window.__prompt = p; const t = 'October group revenue is $13,625 on 101 room nights. Company meetings drove most of it.'; o && o.onText && o.onText({ text: t }); return { text: t }; };
    sample.json = async () => ({}); sample.limits = async () => ({ maxPromptBytes: 2e5, images: { maxCount: 4, maxInputBytes: 5e6 } });
    const caps = { sample, db: { collection: base => ({ doc: id => mk(base + '/' + id) }) }, user: { id: async () => 'u1' }, downloads: { save: async (x) => { window.__dl = x; return 'saved'; } } };
    window.claude = { use: async n => caps[n] || null };
  });
  const p = await ctx.newPage(); const errs = []; p.on('pageerror', e => errs.push(e.message)); p.on('console', m => { if (m.type() === 'error' && !/fonts|net::|ERR_/.test(m.text())) errs.push(m.text()); });
  await p.goto(process.env.SC_TEST_URL || 'http://127.0.0.1:5173'); await p.waitForTimeout(1600);
  // synthetic GRO + Pickup
  await p.evaluate(() => {
    let seed = 3; const rnd = () => (seed = seed * 16807 % 2147483647) / 2147483647; const days = [];
    for (let i = 0; i < 120; i++) { const d = addDays('2026-10-01', i), seg = {}, segS = {}; let s0 = 0, s1 = 0, t0 = 0, t1 = 0;
      for (const [k, , t] of GRO_SEGS) { const rn = Math.round(rnd() * (t === 'G' ? 12 : 9)), adr = 110 + rnd() * 60, srn = Math.round(rnd() * 9); seg[k] = [rn, Math.round(rn * adr)]; segS[k] = [srn, Math.round(srn * adr * .95)]; s0 += rn; s1 += seg[k][1]; t0 += srn; t1 += segS[k][1]; }
      seg.Trans = [0, 0]; seg.Grp = [0, 0]; segS.Trans = [0, 0]; segS.Grp = [0, 0];
      days.push({ d, dow: '', cap: 110, sld: s0 + 2, rev: s1 + 250, stly: [t0 + 1, t1 + 100], ly: [t0, t1], fc: [s0 + 5, s1 + 500], pu: [1, 120], pu7: [3, 400], lrv: 120, ev: '', arr: 10, dep: 10, seg, segS, losRate: 0, fms: null, comp: null }); }
    revState().gdd = { asOf: '2026-10-17', hotel: 'Test', needThr: 70, highThr: 96, days };
    const rows = [], cx = [];
    const srps = [['LNR1', 'Westinghouse LNR', 'LNR', 'WESTINGHOUSE ELECTRIC'], ['BAR', 'Best Available', 'BAR', ''], ['P8', 'Expedia Package', 'DISC', 'EXPEDIA'], ['GOV', 'Government', 'GOV', 'US ARMY CORPS'], ['CNR2', 'Siemens Corp', 'CNR', 'SIEMENS']];
    for (let i = 0; i < 60; i++) { const s = srps[i % srps.length]; rows.push({ stay: addDays('2026-10-20', i % 40), srp: s[0], srpName: s[1], mcat: s[2], corp: s[3], bkd: addDays('2026-10-10', i % 7), conf: String(80000 + i), day: 1, los: 1 + (i % 3), rms: 1, adr: 120 + (i % 5) * 10, rev: 120 + (i % 5) * 10 }); }
    for (let i = 0; i < 6; i++) { const s = srps[i % 3]; cx.push({ stay: addDays('2026-10-25', i), srp: s[0], srpName: s[1], mcat: s[2], corp: s[3], bkd: '2026-10-12', conf: String(90000 + i), day: 1, los: 1, rms: 1, adr: 130, rev: 130 }); }
    revState().pubd = { asOf: '2026-10-17', hotel: 'Test', bookings: { '7': { from: '2026-10-10', rows } }, cancels: { '7': { from: '2026-10-10', rows: cx } } };
    state.bookings.push({ id: 'pp1', name: 'Hockey Classic', account: 'PA Hockey', segment: 'Sports', status: 'Tentative', statusDate: todayISO(), arrive: '2027-01-15', arrival: '2027-01', rn: 55, adr: 129, rev: 0, revManual: false });
    save(); view = 'home'; render();
  });
  await p.waitForTimeout(1300);
  const out = {};
  const tile = async (re) => { const ok = await p.evaluate(re => { const c = [...document.querySelectorAll('.card.x-drillable')].find(c => new RegExp(re, 'i').test(c.querySelector('.kpi .lab').textContent)); if (!c) return false; c.click(); return true; }, re); if (!ok) return 'NO TILE'; await p.waitForTimeout(400); const r = await p.evaluate(() => ({ recon: (document.querySelector('#xDrill .x-recon') || {}).className, txt: (document.querySelector('#xDrill .x-recon') || {}).textContent, rows: document.querySelectorAll('#xDrill .x-row').length })); await p.evaluate(() => xdClose()); await p.waitForTimeout(300); return r; };
  out.groupOtb = await tile('^group \\d{4} otb$'); out.openPipe = await tile('^open pipeline$'); out.openRfps = await tile('^open rfps$'); out.followups = await tile('^follow-ups due$'); out.turned = await tile('^turned definite$');
  await p.evaluate(() => { view = 'bt'; render(); }); await p.waitForTimeout(1100); out.btRev = await tile('^bt revenue$'); out.btRn = await tile('^bt room nights$');
  // pace chart: click Oct bar -> jumps to GRO group segments for Oct
  await p.evaluate(() => { view = 'pace'; render(); }); await p.waitForTimeout(1100);
  out.paceBar = await p.evaluate(async () => { const r = [...document.querySelectorAll('rect.x-hit')][9]; if (!r) return 'no hits'; r.dispatchEvent(new MouseEvent('click', { bubbles: true })); await new Promise(r => setTimeout(r, 400)); return { src: ui.xd.src, filters: ui.xd.filters, opts: ui.xd.opts, rows: [...document.querySelectorAll('#xDrill .x-row b')].slice(0, 6).map(x => x.textContent) }; });
  await p.screenshot({ path: 'd-pace.png' }); await p.evaluate(() => xdClose());
  // explorer: GRO reconcile vs hotel totals, drill to records
  await p.evaluate(() => { ui.xd = null; view = 'explore'; render(); }); await p.waitForTimeout(1200);
  out.gro = await p.evaluate(() => { const D = ui.xd, m = D.opts.month, days = xGdd().days.filter(d => d.d.startsWith(m)); const hotel = days.reduce((s, d) => s + d.rev, 0), st = xdState(D); return { month: m, hotel, drill: st.tot.rev, match: Math.abs(hotel - st.tot.rev) < 0.01, by: st.by, rows: st.rows.map(r => r.k) }; });
  await p.screenshot({ path: 'd-explore.png' });
  const path2 = [];
  for (let i = 0; i < 4; i++) { const r = await p.evaluate(() => { const b = document.querySelector('.x-explore .x-row'); if (!b) return null; const t = b.querySelector('b').textContent; b.click(); return t; }); await p.waitForTimeout(250); path2.push(r + ' -> ' + await p.evaluate(() => xdState(ui.xd).by)); }
  out.groPath = path2; out.crumbs = await p.evaluate(() => [...document.querySelectorAll('.x-explore .x-crumb')].map(c => c.textContent));
  await p.evaluate(() => document.querySelector('.x-explore [data-act="xdCrumb"][data-v="-1"]').click()); out.backToAll = await p.evaluate(() => ui.xd.filters.length);
  // pickup tab: channel -> srp -> company -> record, with cancels netting
  await p.evaluate(() => document.querySelector('[data-act="xdSrc"][data-v="pickup"]').click()); await p.waitForTimeout(300);
  out.pickup = await p.evaluate(() => { const st = xdState(ui.xd); return { by: st.by, rows: st.rows.map(r => [r.k, r.rn, r.rev]), totRn: st.tot.rn }; });
  for (let i = 0; i < 4; i++) { await p.evaluate(() => { const b = document.querySelector('.x-explore .x-row'); b && b.click(); }); await p.waitForTimeout(200); }
  out.pickLeaf = await p.evaluate(() => ({ by: xdState(ui.xd).by, filters: ui.xd.filters, cols: [...document.querySelectorAll('.x-explore th')].map(t => t.textContent), n: document.querySelectorAll('.x-explore tbody tr').length }));
  await p.screenshot({ path: 'd-leaf.png' });
  // explain + csv
  await p.evaluate(() => document.querySelector('[data-act="xdSrc"][data-v="gro"]').click()); await p.waitForTimeout(300);
  await p.evaluate(() => document.querySelector('[data-act="xdExplain"]').click()); await p.waitForTimeout(500);
  out.explain = await p.evaluate(() => ({ box: !!document.getElementById('xdText'), prompt: (window.__prompt || '').slice(0, 260) }));
  await p.evaluate(() => document.querySelector('[data-act="xdCsv"]').click()); await p.waitForTimeout(300);
  out.csv = await p.evaluate(async () => window.__dl ? (await window.__dl.data.text()).split('\n').slice(0, 3) : null);
  // rev page segment rows + occupancy chart
  await p.evaluate(() => { view = 'rev'; render(); }); await p.waitForTimeout(1100);
  out.revWired = await p.evaluate(() => ({ segRows: document.querySelectorAll('tr.x-drillable').length, occHits: document.querySelectorAll('rect.x-hit').length }));
  await p.screenshot({ path: 'd-rev.png' });
  console.log(JSON.stringify(out, null, 1)); console.log('ERRS', errs.length ? errs : 'none'); await b.close();
})();
