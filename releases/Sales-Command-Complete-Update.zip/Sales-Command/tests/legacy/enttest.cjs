const { chromium } = require('playwright'); const path = require('path');
(async () => {
  const b = await chromium.launch({executablePath:process.env.CHROMIUM_PATH || '/usr/bin/chromium',args:['--no-sandbox']}); const ctx = await b.newContext({ viewport: { width: 1440, height: 900 } });
  await ctx.addInitScript(() => { window.SC_ALLOW_EXTERNAL_PROCESSING = true; const sample = async (p, o) => { window.__p = p; const t = 'Hockey Classic is at 72% pickup.'; o && o.onText && o.onText({ text: t }); return { text: t }; }; sample.json = async () => ({}); sample.limits = async () => ({ maxPromptBytes: 2e5 }); window.claude = { use: async n => ({ sample })[n] || null }; });
  const p = await ctx.newPage(); const errs = []; p.on('pageerror', e => errs.push(e.message)); p.on('console', m => { if (m.type() === 'error' && !/fonts|net::|ERR_/.test(m.text())) errs.push(m.text()); });
  await p.goto(process.env.SC_TEST_URL || 'http://127.0.0.1:5173'); await p.waitForTimeout(1500);
  await p.evaluate(() => {
    const nights = []; for (let i = 0; i < 3; i++) nights.push({ d: addDays('2026-11-13', i), block: [30, 40, 25][i], pu: [22, 31, 12][i], avail: [8, 9, 13][i], var7: [3, 4, 1][i], rate: 129, sysPct: 10, userPct: null });
    const wed = [{ d: '2026-12-05', block: 15, pu: 15, avail: 0, var7: 0, rate: 149, sysPct: 0, userPct: null }];
    revState().wash = { asOf: '2026-10-17', by: '', groups: [{ code: 'HOCKEY26', name: 'Pittsburgh Spring Hockey Classic', seg: 'SMRF', mgr: 'Grady Gill', status: 'Definite', cutoff: '2026-10-23', nights }, { code: 'SMTHWED', name: 'Smith Wedding', seg: 'SMRF', mgr: 'Grady Gill', status: 'Definite', cutoff: '2026-11-05', nights: wed }] };
    state.bookings.push({ id: 'hk', name: 'Pittsburgh Spring Hockey Classic', account: 'PA Youth Hockey League', contact: 'Jo Smith', email: 'jo@pahockey.org', phone: '412-555-0101', segment: 'Sports', status: 'Definite', statusDate: '2026-09-20', created: '2026-09-01', arrive: '2026-11-13', depart: '2026-11-16', arrival: '2026-11', rn: 95, adr: 129, rev: 0, revManual: false, notes: 'Wants breakfast at 6am Saturday' });
    const c = newGroupContract(); Object.assign(c.data, { event: 'Pittsburgh Spring Hockey Classic', org: 'PA Youth Hockey League', arrive: '2026-11-13', depart: '2026-11-16', attr: 'pct', attrPct: 80 }); c.status = 'Signed'; c.updated = '2026-09-22'; kList().push(c);
    xAcctUpsert({ name: 'PA Youth Hockey League', contacts: [{ name: 'Jo Smith', title: 'Tournament Director' }] }); save();
  });
  const out = {};
  for (const v of ['revmeet', 'pipeline', 'cal', 'accounts', 'home']) { await p.evaluate(v => { view = v; render(); }, v); await p.waitForTimeout(500); out[v] = await p.evaluate(() => ({ links: document.querySelectorAll('#view .x-ent').length, info: document.querySelectorAll('#view .x-info').length })); }
  await p.evaluate(() => { view = 'revmeet'; render(); }); await p.waitForTimeout(400);
  const opened = await p.evaluate(() => { const el = [...document.querySelectorAll('#view .x-ent, #view .x-info')].find(e => e.dataset.k === 'group' && /hockey/.test(e.dataset.v)); if (!el) return false; el.click(); return true; });
  await p.waitForTimeout(700);
  out.opened = opened;
  out.profile = await p.evaluate(() => Object.fromEntries([...document.querySelectorAll('#xDrill .x-fact')].map(f => [f.querySelector('span').textContent, f.querySelector('b').textContent])));
  out.tags = await p.evaluate(() => [...document.querySelectorAll('#xDrill .x-dhead .tag')].map(t => t.textContent));
  await p.screenshot({ path: 'e-profile.png' });
  await p.evaluate(() => document.querySelector('[data-act="xEntCopy"]').click()); await p.waitForTimeout(200);
  out.summary = await p.evaluate(() => xGroupSummary(xGroups().find(g => /hockey/.test(g.key))));
  await p.evaluate(() => document.querySelector('[data-act="xEntExplain"]').click()); await p.waitForTimeout(400); out.explainBox = await p.evaluate(() => !!document.getElementById('xdText'));
  await p.evaluate(() => document.querySelector('[data-act="xEntGo"][data-v="disp"]').click()); await p.waitForTimeout(500);
  out.disp = await p.evaluate(() => { const A = dpCur(); return { view, name: A.name, arrive: A.arrive, depart: A.depart, rate: A.rate, nights: A.nights, inFc: A.inFc }; });
  // explorer groups tab -> leaf -> profile
  await p.evaluate(() => { ui.xd = null; view = 'explore'; render(); document.querySelector('[data-act="xdSrc"][data-v="groups"]').click(); }); await p.waitForTimeout(400);
  out.groupsTab = await p.evaluate(() => { const st = xdState(ui.xd); return { by: st.by, rows: st.rows.map(r => [r.k, r.rn, r.crn]) }; });
  await p.evaluate(() => document.querySelector('.x-explore .x-row').click()); await p.waitForTimeout(300);
  out.leafClick = await p.evaluate(() => { const tr = document.querySelector('.x-explore tbody tr[data-act="xEnt"]'); if (!tr) return 'no leaf link'; tr.click(); return true; }); await p.waitForTimeout(400);
  out.leafOpened = await p.evaluate(() => (document.querySelector('#xDrill .x-ename') || {}).textContent);
  await p.screenshot({ path: 'e-groups.png' });
  console.log(JSON.stringify(out, null, 1)); console.log('ERRS', errs.length ? errs : 'none'); await b.close();
})();
