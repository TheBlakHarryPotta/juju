const { chromium } = require('playwright'); const path = require('path');
(async () => {
  const b = await chromium.launch({executablePath:process.env.CHROMIUM_PATH || '/usr/bin/chromium',args:['--no-sandbox']}); const ctx = await b.newContext({ viewport: { width: 1440, height: 900 } });
  await ctx.addInitScript(() => { window.SC_ALLOW_EXTERNAL_PROCESSING = true;
    const store = {}; const mk = p => ({ get: async () => ({ exists: p in store, data: () => store[p] && JSON.parse(JSON.stringify(store[p])) }), set: async d => { store[p] = JSON.parse(JSON.stringify(d)); }, delete: async () => { delete store[p]; }, onSnapshot: () => () => { } });
    const sample = async () => ({ text: 'ok' }); sample.json = async () => ({ type: 'other', confidence: .5, title: 't', summary: 's', fields: { notes: 'x' } }); sample.limits = async () => ({ maxPromptBytes: 2e5, images: { maxCount: 4, maxInputBytes: 5e6 } });
    const caps = { sample, db: { collection: base => ({ doc: id => mk(base + '/' + id) }) }, user: { id: async () => 'u1' }, downloads: { save: async () => 'saved' } };
    window.claude = { use: async n => caps[n] || null }; HTMLInputElement.prototype.showPicker = function () { }; const oc = HTMLInputElement.prototype.click; HTMLInputElement.prototype.click = function () { if (this.type === 'file') return; return oc.call(this); };
  });
  const p = await ctx.newPage(); let errs = [];
  p.on('pageerror', e => errs.push(e.message)); p.on('console', m => { if (m.type() === 'error' && !/fonts|net::|ERR_|favicon/.test(m.text())) errs.push('console: ' + m.text().slice(0, 200)); });
  p.on('dialog', d => d.dismiss());
  await p.goto(process.env.SC_TEST_URL || 'http://127.0.0.1:5173'); await p.waitForTimeout(1800);
  // give every module some data so their buttons render
  await p.evaluate(() => { dpNew({ name: 'G', arrive: '2026-12-01', depart: '2026-12-03', rooms: 20, rate: 120 }); xAcctUpsert({ name: 'Westinghouse', contacts: [{ name: 'Dana' }] }); state.rshop.comps.push({ id: 'c1', name: 'Courtyard' }); state.rshop.rows.push({ id: 'r1', stay: '2026-12-01', shop: '2026-10-17', r: { self: 149, c1: 159 } }); kList().push(newGroupContract()); gdNew && gdNew(); save(); });
  const snap = await p.evaluate(() => JSON.stringify(state));
  const views = await p.evaluate(() => NAV.flatMap(([, l]) => l.map(x => x[0])));
  const report = []; let clicks = 0;
  for (const v of views) {
    const n = await p.evaluate(([v, snap]) => { state = JSON.parse(snap); migrate(); xMigrate(); view = v; ui.ppOpen = null; render(); return document.querySelectorAll('#view [data-act]').length; }, [v, snap]);
    for (let i = 0; i < Math.min(n, 80); i++) {
      errs = [];
      const act = await p.evaluate(([v, snap, i]) => { document.querySelectorAll('.x-modal,.x-pop,.x-palette,.x-tray').forEach(e => e.remove()); state = JSON.parse(snap); migrate(); xMigrate(); view = v; ui.ppOpen = null; render(); const el = document.querySelectorAll('#view [data-act]')[i]; if (!el) return null; const a = el.dataset.act; if (/^(theme)$/.test(a)) return a; try { el.click(); } catch (e) { return a + ' THREW ' + e.message; } return a; }, [v, snap, i]);
      clicks++; await p.waitForTimeout(40);
      if (errs.length) report.push(`${v} :: ${act} :: ${errs[0]}`);
    }
  }
  console.log('clicks', clicks); console.log(report.length ? report.join('\n') : 'NO ERRORS'); await b.close();
})();
