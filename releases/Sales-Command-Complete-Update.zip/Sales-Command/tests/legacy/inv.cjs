const { chromium } = require('playwright'); const path = require('path');
(async () => { const b = await chromium.launch({executablePath:process.env.CHROMIUM_PATH || '/usr/bin/chromium',args:['--no-sandbox']}); const p = await (await b.newContext()).newPage(); const errs = []; p.on('pageerror', e => errs.push(e.message));
 await p.goto(process.env.SC_TEST_URL || 'http://127.0.0.1:5173'); await p.waitForTimeout(1200);
 const r = await p.evaluate(() => {
  let seed = 9; const rnd = () => (seed = seed * 16807 % 2147483647) / 2147483647; const fail = []; let checks = 0;
  for (let trial = 0; trial < 40; trial++) {
   const days = []; for (let i = 0; i < 45; i++) { const seg = {}, segS = {}; let a = [0, 0], c = [0, 0]; const missing = rnd() < .05;
     for (const [k] of GRO_SEGS) { const rn = missing ? 0 : Math.round(rnd() * 8), rv = Math.round(rn * (100 + rnd() * 90) * 100) / 100, s0 = missing ? 0 : Math.round(rnd() * 8), sv = Math.round(s0 * (95 + rnd() * 80) * 100) / 100; seg[k] = [rn, rv]; segS[k] = [s0, sv]; a[0] += rn; a[1] += rv; c[0] += s0; c[1] += sv; }
     const adj = rnd() < .5 ? 0 : Math.round(rnd() * 4000) / 100; days.push({ d: addDays('2026-11-01', i), seg, segS, sld: a[0] + (rnd() < .3 ? 1 : 0) + (missing ? 40 : 0), rev: Math.round((a[1] + adj + (missing ? 5000 : 0)) * 100) / 100, stly: [c[0] + 1, c[1] + 0.37], ly: [0, 0], fc: [0, 0] }); }
   revState().gdd = { asOf: '2026-10-17', days };
   const rows = [], cx = []; for (let i = 0; i < 30; i++) { rows.push({ stay: addDays('2026-11-01', i), srp: 'S' + (i % 4), srpName: 'Plan', mcat: ['BAR', 'LNR', 'GOV'][i % 3], corp: 'C' + (i % 5), bkd: '2026-10-15', conf: 'c' + i, los: 1, rms: 1 + (i % 2), adr: 120, rev: 120 * (1 + (i % 2)) }); }
   for (let i = 0; i < 8; i++) cx.push({ stay: addDays('2026-11-03', i), srp: 'S1', srpName: 'Plan', mcat: 'LNR', corp: 'C1', bkd: '2026-10-16', conf: 'x' + i, los: 1, rms: i % 2 ? -1 : 1, adr: 110, rev: i % 2 ? -110 : 110 });
   revState().pubd = { asOf: '2026-10-17', bookings: { '7': { rows } }, cancels: { '7': { rows: cx } } };
   for (const src of ['gro', 'pickup']) {
    const S = XD[src], dims = S.dims.map(d => d[0]); const all = xdState({ src, filters: [], opts: {} });
    // INV-01 conservation over every dim and a random filter
    for (const dim of dims) { checks++; const st = xdState({ src, filters: [], by: dim, opts: {} }); const sr = st.rows.reduce((s, x) => s + x.rev, 0), sn = st.rows.reduce((s, x) => s + x.rn, 0); if (Math.abs(sr - all.tot.rev) > 1e-6 || Math.abs(sn - all.tot.rn) > 1e-6) fail.push(`INV01 ${src} ${dim}`);
      const pick = st.rows[Math.floor(rnd() * st.rows.length)]; if (pick) { const sub = xdState({ src, filters: [[dim, pick.k]], opts: {} }); if (Math.abs(sub.tot.rev - pick.rev) > 1e-6) fail.push(`INV01f ${src} ${dim}`); } }
    if (src === 'gro') { checks++; const hotel = days.reduce((s, d) => s + d.rev, 0), hrn = days.reduce((s, d) => s + d.sld, 0), hst = days.reduce((s, d) => s + d.stly[1], 0); if (Math.abs(all.tot.rev - hotel) > 1e-6 || Math.abs(all.tot.rn - hrn) > 1e-6 || Math.abs(all.tot.crev - hst) > 1e-6) fail.push('INV01 hotel totals');
      // INV-03 row deltas sum to total delta
      checks++; const st = xdState({ src, filters: [], by: 'segment', opts: {} }); const dsum = st.rows.reduce((s, x) => s + (x.rev - x.crev), 0); if (Math.abs(dsum - (all.tot.rev - all.tot.crev)) > 1e-6) fail.push('INV03'); }
    if (src === 'pickup') { // INV-02 netting + order independence
      checks++; const net = rows.reduce((s, r) => s + r.rev, 0) - cx.reduce((s, r) => s + Math.abs(r.rev), 0); if (Math.abs(all.tot.rev - net) > 1e-6) fail.push('INV02 net ' + all.tot.rev + ' vs ' + net);
      rows.reverse(); cx.reverse(); checks++; const again = xdState({ src, filters: [], opts: {} }); if (Math.abs(again.tot.rev - all.tot.rev) > 1e-6) fail.push('INV02 order'); }
   }
  }
  // tile parsing + drilled-scope recon
  const t = [xdTileNum('-$1,200').v, xdTileNum('$188.3K').v, xdTileNum('($450)').v, xdTileNum('73.2%').v];
  return { checks, fail: fail.slice(0, 10), t };
 });
 console.log(JSON.stringify(r)); console.log('ERRS', errs.length ? errs : 'none'); await b.close(); })();
