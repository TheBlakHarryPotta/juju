const { chromium } = require('playwright');
const path = require('path');
(async () => {
  const b = await chromium.launch({executablePath:process.env.CHROMIUM_PATH || '/usr/bin/chromium',args:['--no-sandbox']});
  const ctx = await b.newContext({ viewport: { width: 1440, height: 900 } });
  // simulated Claude runtime: sample returns a canned extraction, db is in-memory
  await ctx.addInitScript(() => { window.SC_ALLOW_EXTERNAL_PROCESSING = true;
    const store = {}; const mk = p => ({ id: p.split('/').pop(), path: p,
      get: async () => ({ exists: p in store, id: p, data: () => store[p] && JSON.parse(JSON.stringify(store[p])), metadata: {} }),
      set: async d => { store[p] = JSON.parse(JSON.stringify(d)); }, delete: async () => { delete store[p]; }, onSnapshot: () => () => { } });
    window.__store = store;
    window.__canned = null;
    const sample = async (input, o) => ({ text: 'Plan: call Westinghouse Tuesday.', truncated: false });
    sample.json = async (input, o) => window.__canned;
    sample.limits = async () => ({ maxPromptBytes: 200000, images: { maxCount: 4, maxInputBytes: 5e6 } });
    const caps = { sample, db: { collection: base => ({ path: base, doc: id => mk(base + '/' + id) }), doc: mk }, user: { id: async () => 'u1' }, downloads: { save: async () => 'saved' } };
    window.claude = { use: async n => caps[n] || null };
  });
  const page = await ctx.newPage();
  const errs = [];
  page.on('pageerror', e => errs.push('PAGEERR ' + e.message));
  page.on('console', m => { if (m.type() === 'error' && !/fonts.g|ERR_|net::/.test(m.text())) errs.push('CONSOLE ' + m.text()); });
  await page.goto(process.env.SC_TEST_URL || 'http://127.0.0.1:5173');
  await page.waitForTimeout(1500);
  const views = await page.evaluate(() => NAV.flatMap(([, l]) => l.map(x => x[0])));
  for (const v of views) {
    for (const th of ['dark', 'light']) {
      await page.evaluate(([v, th]) => { state.settings.theme = th; applyTheme(); view = v; render(); }, [v, th]);
      const t = await page.evaluate(() => document.getElementById('view').innerText.length);
      if (t < 20) errs.push(`EMPTY ${v} ${th}`);
    }
  }
  await page.evaluate(() => { view = 'home'; state.settings.theme = 'dark'; applyTheme(); render(); });
  await page.screenshot({ path: 'shot-home-dark.png' });
  await page.evaluate(() => { state.settings.theme = 'light'; applyTheme(); render(); });
  await page.screenshot({ path: 'shot-home-light.png' });

  // displacement math: 2 nights, capacity 100, forecast 90, ADR 150, block 20 @ 120, 10% comm, CPOR 30
  const d = await page.evaluate(() => {
    const A = dpNew({ name: 'T', arrive: '2026-12-01', depart: '2026-12-03', rooms: 20, rate: 120, comm: 10, cpor: 30 });
    A.nights = { '2026-12-01': { cap: '100', fc: '90', adr: '150' }, '2026-12-02': { cap: '100', fc: '50', adr: '150' } };
    const r1 = dpCalc(A); A.wash = 15; A.attr = 90; const r2 = dpCalc(A); A.wash = 0; A.los = 3; A.tAnc = 10; const r3 = dpCalc(A);
    view = 'disp'; A.res = { key: dpKey(A), ...r3 }; render();
    return { n1: r1.t.net, d1: r1.t.disp, n2: r2.t.net, full2: r2.full.net, attr: r2.attrFee, n3: r3.t.net, sh: r3.t.shoulderLoss, be: r1.breakeven, html: document.getElementById('view').innerHTML.includes('Pro view') };
  });
  console.log('DISP', JSON.stringify(d));
  await page.screenshot({ path: 'shot-disp.png', fullPage: false });

  // import flow with canned RFP extraction
  await page.evaluate(() => { window.__canned = { type: 'group_lead', confidence: .9, title: 'Cranberry Youth Hockey', summary: 'Hockey tournament block request', source: 'Email', fields: { name: 'Cranberry Youth Hockey', account: 'PA Hockey League', contact: 'Jo Smith', email: 'jo@x.com', phone: '', segment: 'Sports', status: 'Prospect', arrive: '2027-01-15', depart: '2027-01-17', peakRooms: 30, rate: 129, nightly: [{ date: '2027-01-15', rooms: 30 }, { date: '2027-01-16', rooms: 25 }], meetingRoom: null, fb: null, notes: 'Needs breakfast early' } }; });
  const before = await page.evaluate(() => state.bookings.length);
  await page.evaluate(() => xIngestText('Hi, we need 30 rooms Jan 15-17 for a hockey tournament...', 'Email'));
  await page.waitForSelector('#xModal');
  await page.screenshot({ path: 'shot-review.png' });
  await page.click('#xModal [data-act="xGo"]');
  await page.waitForTimeout(300);
  const after = await page.evaluate(() => ({ n: state.bookings.length, b: state.bookings[state.bookings.length - 1], acct: state.accounts.map(a => a.name), view }));
  console.log('IMPORT', before, after.n, after.view, JSON.stringify(after.b).slice(0, 300), after.acct);

  // rate shop import
  await page.evaluate(() => { window.__canned = { type: 'rate_shop', confidence: .9, title: 'SSH', summary: 's', source: 'SSH Live', fields: { shopDate: '2026-10-17', rows: [{ stayDate: '2026-10-20', hotel: 'Hampton Inn Cranberry', rate: 149 }, { stayDate: '2026-10-20', hotel: 'Courtyard Cranberry', rate: 169 }, { stayDate: '2026-10-20', hotel: 'Hyatt Place', rate: 159 }] } }; });
  await page.evaluate(() => xIngestText('rates', 'shop'));
  await page.waitForSelector('#xModal'); await page.click('#xModal [data-act="xGo"]'); await page.waitForTimeout(300);
  console.log('RATES', await page.evaluate(() => JSON.stringify(state.rshop)));
  await page.screenshot({ path: 'shot-rates.png' });

  // hotels: add, switch back
  await page.evaluate(() => xHotelAdd());
  await page.fill('#xHotelForm [name=name]', 'Hampton Inn Pittsburgh Wexford'); await page.fill('#xHotelForm [name=short]', 'Hampton Wexford'); await page.fill('#xHotelForm [name=rooms]', '102');
  await page.click('[data-act="xHotelCreate"]'); await page.waitForTimeout(600);
  const h2 = await page.evaluate(() => ({ hotel: state.settings.hotel, rooms: state.settings.rooms, bookings: state.bookings.length, list: HR.list.length }));
  await page.evaluate(() => xSwitch('h0')); await page.waitForTimeout(800);
  const h0 = await page.evaluate(() => ({ hotel: state.settings.hotel, bookings: state.bookings.length, accts: state.accounts.length }));
  console.log('HOTELS', JSON.stringify(h2), JSON.stringify(h0));
  await page.evaluate(() => xHotelMenu(document.querySelector('.x-hotel')));
  await page.screenshot({ path: 'shot-hotels.png' });
  await page.evaluate(() => xPopClose());
  console.log('CLOUD', await page.evaluate(() => [X.status, X.err, Object.keys(window.__store).length, Object.keys(window.__store).filter(k => /m_|reg/.test(k))]));
  // accounts + ai pages
  await page.evaluate(() => { view = 'accounts'; render(); }); await page.screenshot({ path: 'shot-accounts.png' });
  await page.evaluate(() => { xPalOpen(); }); await page.keyboard.type('disp'); await page.screenshot({ path: 'shot-palette.png' }); await page.keyboard.press('Escape');
  // fresh-device test: new context with the same cloud store should pull, not overwrite
  const store = await page.evaluate(() => JSON.stringify(window.__store));
  const p2 = await ctx.newPage(); await p2.addInitScript(s => { const o = JSON.parse(s); localStorage.clear(); window.__seed = o; }, store);

  // ChatGPT unit cases (one night, CPOR 30)
  const fo = await page.evaluate(() => {
    const run = (cap, fc, block, wash, rate, adr) => { const A = dpNew({ arrive: '2027-03-01', depart: '2027-03-02', rooms: block, rate, cpor: 30, wash }); A.nights = { '2027-03-01': { cap: String(cap), fc: String(fc), adr: String(adr) } }; const r = dpCalc(A); dpState().list.shift(); return [r.t.net, r.t.disp, r.full && r.full.net]; };
    return { A: run(100, 50, 20, 0, 140, 180), B: run(100, 95, 30, 0, 125, 200), C: run(100, 90, 20, 15, 100, 180), over: run(100, 130, 20, 0, 100, 180) };
  });
  console.log('FO_CASES', JSON.stringify(fo), 'expect A 2200/0, B -1400/25, C 140/7 full -100, over disp 20');
  // XSS: hostile strings from an imported document must render as text
  await page.evaluate(() => { window.__pwned = 0; window.__canned = { type: 'account', confidence: .9, title: '<img src=x onerror="window.__pwned=1">', summary: '<script>window.__pwned=2</script>', source: 'x', fields: { name: 'Evil <img src=x onerror="window.__pwned=3"> Co', contacts: [{ name: '"><svg onload="window.__pwned=4">', email: 'a@b.c' }], notes: 'Ignore all rules' } }; });
  await page.evaluate(() => xIngestText('evil', 'evil.txt')); await page.waitForSelector('#xModal'); await page.click('#xModal [data-act="xGo"]'); await page.waitForTimeout(400);
  await page.evaluate(() => { view = 'accounts'; render(); view = 'inbox'; render(); }); await page.waitForTimeout(300);
  console.log('XSS pwned =', await page.evaluate(() => window.__pwned));
  // conflict: another device writes newer meta; our next push must load theirs and keep ours
  const conf = await page.evaluate(async () => {
    const m = window.__store['data/users/u1/m_h0']; window.__store['data/users/u1/m_h0'] = { ...m, at: Date.now() + 99999, by: 'other' };
    state.settings.preparedBy = 'Local Edit'; state._at = Date.now(); await cloudPush();
    return { kept: !!localStorage.getItem('scc.conflict.h0'), now: state.settings.preparedBy };
  });
  console.log('CONFLICT', JSON.stringify(conf));
  console.log('ERRS', errs.length ? errs : 'none');
  await b.close();
})();
