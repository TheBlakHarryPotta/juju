const { chromium } = require('playwright'); const path = require('path');
(async () => { const b = await chromium.launch({executablePath:process.env.CHROMIUM_PATH || '/usr/bin/chromium',args:['--no-sandbox']}); const p = await (await b.newContext()).newPage(); const errs = []; p.on('pageerror', e => errs.push(e.message));
 await p.goto(process.env.SC_TEST_URL || 'http://127.0.0.1:5173'); await p.waitForTimeout(1200);
 const r = await p.evaluate(() => {
  const L = t => JSON.stringify(xBtLines(t)[0] || null);
  const res = {
   fo1: L('Westinghouse has 8 RNs - Revenue $858 ADR $107.25 last year 12 RNs $1,440'),
   fo2: L('Omnicell has 4 RNs - Revenue $-250'),
   fo3: JSON.stringify(xBtTable([['Account', 'RNs', 'Revenue', 'ADR', 'LY RNs', 'LY Revenue'], ['Hitachi', 13, 2208, 169.85, 18, 2466], ['Grand Total', 13, 2208, 169.85, 18, 2466]])),
   fo4: JSON.stringify(xBtTable([['Company', 'RNs', 'Revenue', 'LY Rate'], ['Keter', 12, 1800, 145]])),
   lyNotCurrent: L('Westinghouse has 8 RNs, last year 12 RNs for $1500'),
   grady: L('Westinghouse has 8 RNs - Revenue $858'),
   gemini: JSON.stringify(xBtTable([['Report: Company Production'], ['Company Name', 'OTB Room Nights', 'Actual RN', 'Variance RN %', 'OTB Revenue', 'Actual Revenue', 'STLY Room Nights', 'STLY Revenue'], ['Bayer', 10, 9, '-10%', 1300, 1170, 7, 840], ['Report generated 10/17/2026', '', '', '', '', '', '', '']])),
   multi: (xBtTable([['Property', 'Company', 'Room Nights', 'Revenue'], ['PITCR', 'A Co', 1, 100], ['PITWX', 'B Co', 2, 200]]) || {}).multi };
  // partial row must not erase current production; zero revenue respected
  state.bt = [{ id: 'z', account: 'ABC', rn: 20, adr: 150, rev: 3000, lyRn: 0, lyRev: 0 }];
  xBtApply([{ account: 'ABC', lyRn: 15 }]); res.partial = JSON.stringify(state.bt[0]);
  xBtApply([{ account: 'ZeroCo', rn: 8, rev: 0, adr: 150 }]); res.zero = JSON.stringify(state.bt.find(b => b.account === 'ZeroCo'));
  xBtApply([{ account: 'Siemens', rn: 3, rev: 450 }, { account: 'Siemens', rn: 2, rev: 290 }]); res.sum = JSON.stringify(state.bt.find(b => b.account === 'Siemens'));
  state.bt.push({ id: 's2', account: 'Siemens Healthineers', rn: 1, rev: 1 }); res.fuzzy = JSON.stringify(xBtPlan([{ account: 'Siemens Healthineers Inc', rn: 4, rev: 500 }]));
  const a = { type: 'rate_shop', fields: { shopDate: '2026-10-17', rows: [{ stayDate: '2026-10-20', hotel: 'Courtyard', rate: 159 }] } };
  xMerge(a, { type: 'rate_shop', fields: { shopDate: '2026-10-18', rows: [{ stayDate: '2026-10-20', hotel: 'Courtyard', rate: null }, { stayDate: '2026-10-21', hotel: 'Courtyard', rate: 149 }] } }); res.merge = JSON.stringify(a);
  return res; });
 for (const [k, v] of Object.entries(r)) console.log(k.padEnd(14), v); console.log('ERRS', errs.length ? errs : 'none'); await b.close(); })();
