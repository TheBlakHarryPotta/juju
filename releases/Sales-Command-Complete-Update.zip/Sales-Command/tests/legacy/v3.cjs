const { chromium } = require('playwright'); const path = require('path');
(async () => {
  const b = await chromium.launch({executablePath:process.env.CHROMIUM_PATH || '/usr/bin/chromium',args:['--no-sandbox']}); const ctx = await b.newContext({ viewport: { width: 1440, height: 900 } });
  await ctx.addInitScript(() => { window.SC_ALLOW_EXTERNAL_PROCESSING = true;
    const store = {}; const mk = p => ({ get: async () => ({ exists: p in store, data: () => store[p] && JSON.parse(JSON.stringify(store[p])) }), set: async d => { store[p] = JSON.parse(JSON.stringify(d)); }, delete: async () => { delete store[p]; }, onSnapshot: () => () => { } });
    window.__calls = [];
    const sample = async () => ({ text: 'ok' });
    sample.json = async (p, o) => { window.__calls.push({ n: (o.images || []).length, part: (p.match(/covers images (\d+) to (\d+) of (\d+)/) || [])[0] || '' }); const i = window.__calls.length; return { type: 'activities', confidence: .9, title: 'Delphi activities', summary: 'Calls', source: 'Delphi', fields: { items: [{ date: '2026-10-1' + i, type: 'existing', account: 'Acct ' + i, contact: '', notes: 'n', followUp: null }, { date: '2026-10-10', type: 'existing', account: 'Shared row', contact: '', notes: 'dup', followUp: null }] } }; };
    sample.limits = async () => ({ maxPromptBytes: 2e5, images: { maxCount: 4, maxInputBytes: 5e6 } });
    const caps = { sample, db: { collection: base => ({ doc: id => mk(base + '/' + id) }) }, user: { id: async () => 'u1' }, downloads: { save: async () => 'saved' } };
    window.claude = { use: async n => caps[n] || null };
  });
  const p = await ctx.newPage(); const errs = [];
  p.on('pageerror', e => errs.push(e.message)); p.on('console', m => { if (m.type() === 'error' && !/fonts|net::|ERR_/.test(m.text())) errs.push(m.text()); });
  await p.goto(process.env.SC_TEST_URL || 'http://127.0.0.1:5173'); await p.waitForTimeout(1800);
  const views = await p.evaluate(() => NAV.flatMap(([, l]) => l.map(x => x[0])));
  for (const sk of ['aurora', 'sunset', 'midnight', 'champagne']) for (const th of ['dark', 'light']) for (const v of views) await p.evaluate(([v, th, sk]) => { state.settings.theme = th; state.settings.skin = sk; applyTheme(); view = v; render(); }, [v, th, sk]);
  const shot = async (sk, th, v, name, w = 1440) => { await p.setViewportSize({ width: w, height: 900 }); await p.evaluate(([v, th, sk]) => { state.settings.theme = th; state.settings.skin = sk; applyTheme(); view = '__'; render(); view = v; render(); }, [v, th, sk]); await p.waitForTimeout(1900); await p.screenshot({ path: name }); };
  await shot('aurora', 'dark', 'home', 'v3-home-aurora.png');
  await shot('sunset', 'dark', 'revmeet', 'v3-sunset.png');
  await shot('midnight', 'light', 'home', 'v3-midnight-light.png');
  await shot('aurora', 'dark', 'home', 'v3-mobile.png', 400);
  await p.setViewportSize({ width: 1440, height: 900 });
  // screenshot stack: 3 normal + 1 tall full page
  const r = await p.evaluate(async () => {
    const mkImg = (w, h, hue) => new Promise(res => { const c = document.createElement('canvas'); c.width = w; c.height = h; const g = c.getContext('2d'); g.fillStyle = `hsl(${hue},60%,50%)`; g.fillRect(0, 0, w, h); c.toBlob(bl => res(new File([bl], 'shot' + hue + '.png', { type: 'image/png' })), 'image/png'); });
    const fs = [await mkImg(1600, 900, 10), await mkImg(1600, 900, 120), await mkImg(1600, 900, 220), await mkImg(1400, 7000, 300)];
    view = 'inbox'; render(); xIngest(fs, 'drop'); await new Promise(r => setTimeout(r, 600));
    return { tray: ui.xTray.length, tall: ui.xTray.filter(t => t.tall).length, html: !!document.getElementById('xTray') };
  });
  await p.screenshot({ path: 'v3-tray.png' });
  await p.click('[data-act="xTrayGo"][data-v="all"]'); await p.waitForSelector('#xModal', { timeout: 15000 });
  const r2 = await p.evaluate(() => ({ calls: window.__calls, items: ((ui.xq.find(x => x.res) || {}).res || {}).fields.items.length, kind: ui.xq[0].kind }));
  await p.screenshot({ path: 'v3-review.png' });
  console.log('TRAY', JSON.stringify(r), 'CALLS', JSON.stringify(r2));
  console.log('ERRS', errs.length ? errs.slice(0, 8) : 'none'); await b.close();
})();
