const { chromium } = require('playwright'); const path = require('path');
(async () => {
  const b = await chromium.launch({executablePath:process.env.CHROMIUM_PATH || '/usr/bin/chromium',args:['--no-sandbox']}); const ctx = await b.newContext({ viewport: { width: 1440, height: 900 } });
  await ctx.addInitScript(() => { window.SC_ALLOW_EXTERNAL_PROCESSING = true;
    const store = {}; const mk = p => ({ get: async () => ({ exists: p in store, data: () => store[p] }), set: async d => { store[p] = d; }, delete: async () => { delete store[p]; }, onSnapshot: () => () => { } });
    const sample = async () => ({ text: 'ok' }); sample.json = async () => ({ type: 'bt_production', confidence: .92, title: 'Lighthouse company production', summary: 'Oct production by company', source: 'Lighthouse', fields: { period: 'Oct 2026', items: [{ account: 'Westinghouse Electric', rn: 8, rev: 858, adr: null, lyRn: 5, lyRev: 610 }, { account: 'Brand New Co', rn: 3, rev: 390 }, { account: 'Total', rn: 11, rev: 1248 }] } });
    sample.limits = async () => ({ maxPromptBytes: 2e5, images: { maxCount: 4, maxInputBytes: 5e6 } });
    const caps = { sample, db: { collection: base => ({ doc: id => mk(base + '/' + id) }) }, user: { id: async () => 'u1' }, downloads: { save: async () => 'saved' } };
    window.claude = { use: async n => caps[n] || null };
  });
  const p = await ctx.newPage(); const errs = []; p.on('pageerror', e => errs.push(e.message));
  await p.goto(process.env.SC_TEST_URL || 'http://127.0.0.1:5173'); await p.waitForTimeout(1600);
  // rings
  await p.evaluate(() => { view = 'home'; render(); });
  const wired = await p.evaluate(() => [...document.querySelectorAll('.gring')].map(g => g.dataset.v));
  await p.click('.gring[data-v="prospecting"]'); await p.waitForSelector('#xModal');
  await p.fill('#xGoalF [name=account]', 'Westinghouse'); await p.fill('#xGoalF [name=notes]', 'Left VM'); await p.click('[data-act="xGoalLog"]'); await p.waitForTimeout(200);
  await p.evaluate(() => document.querySelector('#xModal details').open = true);
  await p.fill('#xGoalBulk', 'Bayer - sent rates\nMSA Safety - tour booked\nEaton'); await p.click('[data-act="xGoalBulk"]'); await p.waitForTimeout(200);
  await p.screenshot({ path: 'v4-goal.png' });
  const ring = await p.evaluate(() => ({ count: activityCounts(weekRange()).prospecting, sub: [...document.querySelectorAll('#view .gring')].find(g => g.dataset.v === 'prospecting').innerText.replace(/\n/g, ' ') }));
  await p.evaluate(() => xModalClose());
  await p.click('.gring[data-v="all"]'); await p.waitForSelector('#xModal'); await p.screenshot({ path: 'v4-goals-all.png' }); await p.evaluate(() => xModalClose());
  // BT pasted lines
  await p.evaluate(() => { view = 'bt'; render(); });
  await p.fill('#xBtPaste', 'Westinghouse has 8 RNs - Revenue $858\nSiemens has 5 RNs - ADR $157 - Revenue $786\nOmnicell had 12 RNs for $1,620. Last year they had 9 RNs for $1,170');
  await p.click('[data-act="xBtPasteGo"]'); await p.waitForSelector('#xModal'); await p.screenshot({ path: 'v4-bt-review.png' });
  await p.click('#xModal [data-act="xGo"]'); await p.waitForTimeout(300);
  const bt1 = await p.evaluate(() => state.bt.filter(b => /westing|siemens|omnicell/i.test(b.account)).map(b => [b.account, b.rn, b.adr, b.rev, b.lyRn, b.lyRev]));
  // The old file-input/Claude review modal was replaced by local File Inbox.
  // Real CSV, XLSX, screenshot OCR and explicit reviewed commits are asserted in intake.spec.js.
  console.log(JSON.stringify({ wired, ring, bt1, replacedWorkflow: 'File uploads now use local File Inbox; verified by intake and radar integration suites.' }));
  console.log('ERRS', errs.length ? errs : 'none'); await b.close();
})();
