import {test,expect} from '@playwright/test';
import PizZip from 'pizzip';
import {evaluateNeedDates,validateForecast,validateRequest,mapForecastTable,guessForecastMapping,needDateOutreach} from '../src/need-date-matchmaker.js';
import {parseTable} from '../src/sales-import-parser.js';
const base={propertyId:'hotel-a',today:'2030-01-01',settings:{softOccupancyPct:75,staleDays:7}};
const prospect=(id='p1',extra={})=>({id,propertyId:'hotel-a',account:'QA '+id,contact:'Taylor',status:'Qualified',arrive:'2030-01-10',depart:'2030-01-12',...extra});
const request=(id='p1',rooms=[20,40],extra={})=>({prospectId:id,reviewed:true,arrive:'2030-01-10',depart:'2030-01-12',sourceNote:'Synthetic request fixture',nights:rooms.map((rooms,i)=>({date:'2030-01-'+(10+i),rooms})),...extra});
const forecast=(extra={})=>({id:'f1',propertyId:'hotel-a',reviewed:true,sourceName:'QA synthetic forecast',asOf:'2030-01-01',rows:[{date:'2030-01-10',capacity:100,forecastRooms:50},{date:'2030-01-11',capacity:100,forecastRooms:80}],...extra});
const evaluate=extra=>evaluateNeedDates({...base,prospects:[prospect()],forecast:forecast(),overrides:[request()],...extra});
function finiteTree(v){if(typeof v==='number')expect(Number.isFinite(v)).toBe(true);else if(Array.isArray(v))v.forEach(finiteTree);else if(v&&typeof v==='object')Object.values(v).forEach(finiteTree);}

test('Need Dates domain: exact overlap, headroom pressure and score have an independent known answer',()=>{
 const result=evaluate();expect(result.ready).toBe(true);expect(result.ranked).toHaveLength(1);expect(result.ranked[0]).toMatchObject({requestedRN:60,coveredRN:40,softCoveredRN:20,pressureRN:20,score:33.33});
 expect(result.ranked[0].evidence[0]).toMatchObject({headroom:50,coveredRN:20,isSoft:true,softCoveredRN:20});expect(result.ranked[0].evidence[1]).toMatchObject({headroom:20,coveredRN:20,isSoft:false,pressureRN:20});finiteTree(result);
});
test('Need Dates domain: no-pressure requests rank before pressure and ties use useful soft-night RN',()=>{
 const result=evaluate({prospects:[prospect('pressure'),prospect('small'),prospect('good')],overrides:[request('pressure',[20,40]),request('small',[5,5]),request('good',[10,10])]});
 expect(result.ranked.map(x=>x.prospectId)).toEqual(['good','small','pressure']);expect(result.ranked[0].score).toBe(50);
});
test('Need Dates domain: missing nightly counts and month-only dates are never inferred from total RN',()=>{
 const noCounts=evaluate({prospects:[prospect('p1',{rn:200})],overrides:[]});expect(noCounts.ranked).toEqual([]);expect(noCounts.unscored[0].score).toBe(null);expect(noCounts.unscored[0].reason).toMatch(/nightly room counts/i);
 const month=evaluate({prospects:[prospect('p1',{arrive:'2030-01'})],overrides:[request('p1',[20,40],{arrive:'2030-01'})]});expect(month.ranked).toEqual([]);expect(month.unscored[0].reason).toMatch(/full arrival/i);
 expect(()=>validateRequest(prospect(),{...request(),nights:[{date:'2030-01-10',rooms:60}]})).toThrow(/every occupied night/);
});
test('Need Dates domain: missing forecast dates stay unknown and are not assumed empty',()=>{
 const result=evaluate({forecast:forecast({rows:[forecast().rows[0]]})});expect(result.ranked).toHaveLength(0);expect(result.unscored[0]).toMatchObject({scored:false,score:null});expect(result.unscored[0].reason).toContain('2030-01-11');expect(result.unscored[0].evidence[1].unknown).toBe(true);
});
test('Need Dates domain: stale source blocks ranking until the owner explicitly changes the freshness rule',()=>{
 const stale=evaluate({today:'2030-01-09'});expect(stale.ready).toBe(false);expect(stale.ranked).toEqual([]);expect(stale.reason).toMatch(/8 days old/);
 const changed=evaluate({today:'2030-01-09',settings:{softOccupancyPct:75,staleDays:10}});expect(changed.ready).toBe(true);expect(changed.ranked).toHaveLength(1);
 const future=evaluate({forecast:forecast({asOf:'2030-01-02'})});expect(future.ready).toBe(false);expect(future.reason).toMatch(/future/);
});
test('Need Dates domain: room-type rows cannot be substituted for totals or double-counted',()=>{
 const typed=forecast({rows:forecast().rows.map(n=>({...n,roomType:'King'}))});expect(evaluate({forecast:typed}).ranked).toEqual([]);
 const exact=evaluate({forecast:typed,overrides:[request('p1',[20,20],{roomType:'KING'})]});expect(exact.ranked).toHaveLength(1);
 const totalWithTyped=forecast({rows:[...forecast().rows,...forecast().rows.map(n=>({...n,capacity:50,forecastRooms:10,roomType:'King'}))]});expect(evaluate({forecast:totalWithTyped}).ranked[0].coveredRN).toBe(40);
});
test('Need Dates domain: impossible capacity, zero sellable inventory and terminal statuses never imply a fit',()=>{
 const closed=forecast({rows:forecast().rows.map(n=>({...n,capacity:0,forecastRooms:0}))});const result=evaluate({forecast:closed});expect(result.ranked).toEqual([]);expect(result.unscored[0].reason).toMatch(/exceed/);finiteTree(result);
 for(const status of ['Won','Lost','Do not contact'])expect(evaluate({prospects:[prospect('p1',{status})]}).ranked).toEqual([]);
});
test('Need Dates domain: malformed forecasts and request numbers are rejected before analysis',()=>{
 expect(()=>validateForecast(forecast({rows:[forecast().rows[0],forecast().rows[0]]}),base)).toThrow(/Duplicate/);
 for(const capacity of ['',false,[],{},Infinity,-1,1.5])expect(()=>validateForecast(forecast({rows:[{...forecast().rows[0],capacity}]}),base)).toThrow();
 expect(()=>validateForecast(forecast({reviewed:false}),base)).toThrow(/review/);expect(()=>validateForecast(forecast({rows:[{...forecast().rows[0],forecastRooms:101}]}),base)).toThrow(/exceed/);
 expect(()=>validateRequest(prospect(),request('p1',[false,20]))).toThrow(/explicit/);
 expect(()=>validateRequest(prospect(),request('p1',[20,40],{arrive:'2030-01-10extra'}))).toThrow(/Full arrival/);
 expect(()=>validateRequest(prospect(),request('p1',[20,40],{depart:'2030-01-12extra'}))).toThrow(/Full arrival/);
});
test('Need Dates domain: source property isolation and changed manual-review dates block stale matching',()=>{
 expect(evaluate({forecast:forecast({propertyId:'hotel-b'})}).ranked).toEqual([]);
 const scoped=evaluate({prospects:[prospect(),prospect('foreign',{propertyId:'hotel-b'})]});expect(scoped.candidates).toHaveLength(1);
 const changed=evaluate({overrides:[request('p1',[20,40],{prospectStayAtReview:{arrive:'2030-01-09',depart:'2030-01-12'}})]});expect(changed.ranked).toEqual([]);expect(changed.unscored[0].reason).toMatch(/dates changed/);
});
test('Need Dates domain: approved package counts are used only after explicit source review',()=>{
 const p=prospect('p1',{requestedNights:request().nights,requestedNightsReviewed:true,requestedNightsReviewedAt:'2030-01-01',requestedNightsSource:{name:'Approved call package'}});
 expect(evaluate({prospects:[p],overrides:[]}).ranked).toHaveLength(1);
 expect(evaluate({prospects:[{...p,requestedNightsReviewed:false}],overrides:[]}).ranked).toEqual([]);
 const mixed=evaluate({prospects:[{...p,requestedRoomTypes:['King','Double Queen']}],overrides:[]});expect(mixed.ranked[0].warnings.join(' ')).toMatch(/mixed room-type/);
});
test('Need Dates domain: fixed table mapper preserves explicit zero and ignores executable-looking headers',()=>{
 const table=parseTable('Stay Date,Capacity,ForecastRooms,RoomType,ApprovedMinRate,__proto__\n2030-01-10,100,0,,129,ignored\n2030-01-11,100,50,,129,ignored');const rows=mapForecastTable(table,guessForecastMapping(table.headers));
 const f=validateForecast(forecast({rows}),base);expect(f.rows[0].forecastRooms).toBe(0);expect(Object.hasOwn(rows[0],'__proto__')).toBe(false);expect(f.periodStart).toBe('2030-01-10');
 expect(()=>mapForecastTable(table,{date:0,capacity:1,forecastRooms:1})).toThrow(/only once/);
});
test('Need Dates domain: outreach uses stated needs and asks to confirm rather than quoting inventory or a rate',()=>{
 const result=evaluate();const draft=needDateOutreach(result.ranked[0],'QA Hotel','QA Sales');expect(draft).toContain('2030-01-10: 20 rooms');expect(draft).toContain('confirm');expect(draft).not.toMatch(/\$|available for you|rooms are held|guaranteed/i);expect(()=>needDateOutreach(result.unscored[0])).toThrow();
});

async function open(page){await page.goto('/');await page.waitForFunction(()=>window.SC?.needDates&&window.SC?.salesWorkflows);await page.evaluate(async()=>{await SC.ready;SC.navigate('needDates');});}
async function seedProspect(page){return page.evaluate(()=>{const d=new Date();d.setDate(d.getDate()+14);const arrive=d.toISOString().slice(0,10);d.setDate(d.getDate()+1);const depart=d.toISOString().slice(0,10);const imported=SC.salesWorkflows.importProspects([{account:'QA Need Date Company',contact:'Jo',arrive,depart}],{source:{id:'qa-need-date-source',kind:'QA'}});const p=imported.prospects[0];return {id:p.id,arrive,depart,asOf:new Date().toISOString().slice(0,10),propertyId:String(SC.propertyId)};});}

test('Need Dates UI: actual CSV mapping and reviewed request create a plan without completed activity',async({page})=>{
 await open(page);const p=await seedProspect(page);
 await page.locator('#nd-file-input').setInputFiles({name:'qa-need-forecast.csv',mimeType:'text/csv',buffer:Buffer.from(`Date,Capacity,ForecastRooms\n${p.arrive},100,30`)});
 await expect(page.locator('#nd-mapping-form')).toBeVisible();await page.locator('#nd-mapping-form [name="asOf"]').fill(p.asOf);await page.locator('#nd-mapping-form [name="reviewed"]').check();await page.locator('#nd-mapping-form [type="submit"]').click();
 await page.locator(`[data-nd-action="review-request"][data-id="${p.id}"]`).click();await page.locator('#nd-request-form [data-nd-request-date]').fill('12');await page.locator('#nd-request-form [name="reviewed"]').check();await page.locator('#nd-request-form [type="submit"]').click();
 await expect(page.locator(`.nd-fit-card[data-prospect-id="${p.id}"]`)).toBeVisible();await expect(page.locator(`.nd-fit-card[data-prospect-id="${p.id}"]`)).toContainText('12 of 12');
 const before=await page.evaluate(()=>({activities:SC.state.activities.length,contacted:SC.state.salesWorkflows.prospects[0].contacted}));
 await page.locator(`[data-nd-action="draft"][data-id="${p.id}"]`).click();await page.locator('#nd-followup-form [name="reviewed"]').check();await page.locator('#nd-followup-form [type="submit"]').click();
 const after=await page.evaluate(()=>({activities:SC.state.activities.length,contacted:SC.state.salesWorkflows.prospects[0].contacted,task:SC.state.plannedTasks.at(-1)}));expect(after.activities).toBe(before.activities);expect(after.contacted).toBe(before.contacted);expect(after.task.source.kind).toBe('need-date-matchmaker');expect(after.task.done).toBe(false);expect(after.task.source.requestedNights[0].rooms).toBe(12);expect(after.task.source.forecastSourceName).toBe('qa-need-forecast.csv');
});
test('Need Dates UI: a stale source produces no fit cards and hotel switching isolates sources and requests',async({page})=>{
 await open(page);const p=await seedProspect(page);
 const result=await page.evaluate(p=>{const old=new Date();old.setDate(old.getDate()-20);SC.needDates.importForecast({sourceName:'QA old source',asOf:old.toISOString().slice(0,10),reviewed:true,rows:[{date:p.arrive,capacity:100,forecastRooms:30}]});SC.needDates.reviewRequest(p.id,{reviewed:true,arrive:p.arrive,depart:p.depart,nights:[{date:p.arrive,rooms:10}]});return SC.needDates.evaluate();},p);expect(result.ready).toBe(false);await expect(page.locator('.nd-fit-card')).toHaveCount(0);
 await page.evaluate(async()=>{await SC.createProperty({name:'QA Second Need Date Hotel',rooms:60});SC.navigate('needDates');});await expect(page.locator('.nd-page')).toContainText('No forecast saved for this hotel.');const isolated=await page.evaluate(()=>SC.needDates.evaluate());expect(isolated.ranked).toEqual([]);expect(isolated.candidates).toEqual([]);
 await page.evaluate(async id=>{await SC.switchProperty(id);SC.navigate('needDates');},p.propertyId);await expect(page.locator('.nd-page')).toContainText('QA old source');expect(await page.evaluate(()=>SC.needDates.evaluate().candidates.length)).toBe(result.candidates.length);expect(await page.evaluate(id=>SC.needDates.evaluate().candidates.some(c=>c.prospectId===id),p.id)).toBe(true);
});


test('Need Dates UI: actual XLSX report-title rows retain sheet, source-row and file-hash evidence',async({page})=>{
 await open(page);const p=await seedProspect(page);const zip=new PizZip();
 zip.file('[Content_Types].xml','<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>');
 zip.file('xl/workbook.xml','<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Need Date Forecast" sheetId="1" r:id="rId1"/></sheets></workbook>');
 zip.file('xl/_rels/workbook.xml.rels','<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>');
 const cell=(address,text)=>`<c r="${address}" t="inlineStr"><is><t>${text}</t></is></c>`;
 zip.file('xl/worksheets/sheet1.xml','<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData><row r="1">'+cell('A1','QA Report Title')+'</row><row r="3">'+cell('A3','Date')+cell('B3','Capacity')+cell('C3','ForecastRooms')+cell('D3','RoomType')+'</row><row r="4">'+cell('A4',p.arrive)+'<c r="B4"><v>100</v></c><c r="C4"><v>40</v></c>'+cell('D4','King')+'</row></sheetData></worksheet>');
 await page.locator('#nd-file-input').setInputFiles({name:'qa-need-dates.xlsx',mimeType:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',buffer:zip.generate({type:'nodebuffer'})});
 await expect(page.locator('#nd-mapping-form')).toBeVisible();await page.locator('#nd-mapping-form [name="asOf"]').fill(p.asOf);await page.locator('#nd-mapping-form [name="reviewed"]').check();await page.locator('#nd-mapping-form [type="submit"]').click();
 const source=await page.evaluate(()=>SC.state.needDateMatcher.forecast);expect(source.sourceSheet).toBe('Need Date Forecast');expect(source.sourceHash).toMatch(/^[a-f0-9]{64}$/);expect(source.rows[0]).toMatchObject({date:p.arrive,capacity:100,forecastRooms:40,roomType:'King',sourceRow:4});
 const result=await page.evaluate(p=>{SC.needDates.reviewRequest(p.id,{reviewed:true,arrive:p.arrive,depart:p.depart,roomType:'King',nights:[{date:p.arrive,rooms:10}]});return SC.needDates.evaluate().ranked.find(r=>r.prospectId===p.id);},p);expect(result.score).toBe(100);expect(result.softCoveredRN).toBe(10);
});
