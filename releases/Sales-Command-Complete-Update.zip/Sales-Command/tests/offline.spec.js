import { test, expect } from '@playwright/test';

test('production PWA reloads and performs OCR offline with no external requests', async ({ page, context }) => {
  test.setTimeout(120_000);
  const external = [];
  page.on('request', request => {
    const u = new URL(request.url());
    if (['http:', 'https:'].includes(u.protocol) && !['127.0.0.1', 'localhost'].includes(u.hostname)) external.push(u.origin);
  });
  await page.goto(process.env.SC_TEST_PRODUCTION_URL || 'http://127.0.0.1:4173');
  await page.waitForFunction(() => window.SC?.ready);
  await page.evaluate(async () => { await SC.ready; await navigator.serviceWorker.ready; });
  await page.waitForFunction(() => !!navigator.serviceWorker.controller, { timeout: 60_000 });
  await page.evaluate(async () => { state.settings.preparedBy = 'QA offline manager'; save(); await SC.storage.flush(); });
  await context.setOffline(true);
  await page.reload();
  await page.waitForFunction(() => window.SC?.ready);
  expect(await page.evaluate(async () => { await SC.ready; return state.settings.preparedBy; })).toBe('QA offline manager');
  const result = await page.evaluate(async () => {
    SC.navigate('intake');
    const canvas = document.createElement('canvas'); canvas.width = 1000; canvas.height = 160;
    const ctx = canvas.getContext('2d'); ctx.fillStyle = 'white'; ctx.fillRect(0, 0, 1000, 160); ctx.fillStyle = 'black'; ctx.font = 'bold 56px Arial'; ctx.fillText('HOTEL SALES OFFLINE', 25, 95);
    const blob = await new Promise(resolve => canvas.toBlob(resolve, 'image/png'));
    const [f] = await SC.intakeFiles([new File([blob], 'offline-screenshot.png', { type: 'image/png' })]);
    return { status: f.status, text: f.text, error: f.error };
  });
  expect(result.status, result.error).toBe('review'); expect(result.text).toMatch(/HOTEL SALES/);
  expect(external).toEqual([]);
});
