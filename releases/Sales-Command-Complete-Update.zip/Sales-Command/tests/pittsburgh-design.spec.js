import { test, expect } from '@playwright/test';

async function open(page, view = 'home') {
  await page.goto('/');
  await page.waitForFunction(() => window.SC?.ready);
  await page.evaluate(async view => { await SC.ready; SC.navigate(view); }, view);
}
async function appearance(page) {
  await page.locator('#top [data-act="theme"]').click();
  await expect(page.locator('[data-pg-palette="steel"]')).toBeVisible();
}
async function noPageOverflow(page) {
  expect(await page.evaluate(() => ({ width: innerWidth, scroll: document.documentElement.scrollWidth }))).toEqual({ width: 390, scroll: 390 });
}

test('Pittsburgh appearance palettes persist across reload and preserve sales data', async ({ page }) => {
  await open(page);
  const before = await page.evaluate(() => JSON.stringify({ property: SC.propertyId, accounts: SC.state.accounts, activities: SC.state.activities }));
  const colors = [];
  for (const palette of ['steel', 'river', 'copper', 'daylight']) {
    await appearance(page);
    await page.locator(`[data-pg-palette="${palette}"]`).click();
    await expect(page.locator('html')).toHaveAttribute('data-pittsburgh-palette', palette);
    await page.keyboard.press('Escape');
    colors.push(await page.evaluate(() => getComputedStyle(document.body).backgroundColor));
    await page.reload();
    await page.evaluate(async () => { await SC.ready; });
    await expect(page.locator('html')).toHaveAttribute('data-pittsburgh-palette', palette);
    expect(await page.evaluate(() => JSON.stringify({ property: SC.propertyId, accounts: SC.state.accounts, activities: SC.state.activities }))).toBe(before);
  }
  expect(new Set(colors).size).toBeGreaterThanOrEqual(3);
});

test('motion preference persists while system reduced-motion suppresses animated skyline', async ({ page }) => {
  await page.emulateMedia({ reducedMotion: 'reduce' });
  await open(page);
  await appearance(page);
  await page.locator('#pgMotionEnabled').uncheck();
  await page.keyboard.press('Escape');
  await page.reload(); await page.evaluate(async () => { await SC.ready; });
  await appearance(page); await expect(page.locator('#pgMotionEnabled')).not.toBeChecked();
  await page.locator('#pgMotionEnabled').check(); await page.keyboard.press('Escape');
  const animated = await page.evaluate(() => [...document.getAnimations()].filter(a => a.playState === 'running' && a.effect?.getTiming().duration > 20).length);
  expect(animated).toBe(0);
});

test('phone navigation exposes new sales workspaces without page clipping or runtime errors', async ({ page }) => {
  await page.setViewportSize({ width: 390, height: 844 });
  const errors=[]; page.on('pageerror', error => errors.push(error.message));
  await open(page);
  for (const route of ['home', 'prospects', 'tours', 'networking', 'salesWeek', 'dealCheck', 'captureStation', 'calls', 'intake', 'contracts']) {
    await page.locator('.menu-btn').click();
    const link=page.locator(`#side .nav[data-go="${route}"]`);
    const group=link.locator('xpath=ancestor::details');
    if(await group.count() && await group.getAttribute('open')===null) await group.locator('summary').click();
    await link.click();
    await expect(page.locator('#view')).not.toBeEmpty();
    await noPageOverflow(page);
    expect(await page.evaluate(() => SC.view)).toBe(route);
  }
  expect(errors).toEqual([]);
});

test('each Pittsburgh palette renders a readable desktop and phone command center', async ({ page }) => {
  await open(page);
  for (const palette of ['steel', 'river', 'copper', 'daylight']) {
    await page.setViewportSize({ width: 1440, height: 1000 });
    await appearance(page); await page.locator(`[data-pg-palette="${palette}"]`).click(); await page.keyboard.press('Escape');
    await page.mouse.move(0,0);await page.evaluate(()=>document.activeElement?.blur());
    await expect(page.locator('#toast')).not.toHaveClass(/show/);
    await expect(page.locator('#view')).toBeVisible();
    await expect(page.locator('.pg-city')).toBeVisible();
    const city=await page.locator('.pg-city').boundingBox();expect(city.width).toBeGreaterThan(250);expect(city.height).toBeGreaterThan(100);
    await page.screenshot({path:`docs/screenshots/pittsburgh-${palette}-desktop.png`,fullPage:false});
    await page.setViewportSize({ width: 390, height: 844 });
    await noPageOverflow(page);await page.mouse.move(0,0);
    await page.screenshot({path:`docs/screenshots/pittsburgh-${palette}-phone.png`,fullPage:false});
    await expect(page.locator('#view h1, #view h2').first()).toBeVisible();
  }
});

test('Import Station maps an actual prospect CSV only after review and keeps missing data blank', async ({ page }) => {
  await open(page,'captureStation');
  const baseline=await page.evaluate(()=>({activities:SC.state.activities.length,prospects:SC.state.salesWorkflows?.prospects?.length||0}));
  const csv='Company,Contact,Email,Phone,Arrival,Departure,Next step\nSynthetic Bridge Labs,Sam Example,sam@example.test,0012345,2027-02-01,2027-02-03,Call about training\nSynthetic River Works,Alex Example,,,,,Verify travel need';
  async function upload(){
    await page.locator('#si-file').setInputFiles({name:'synthetic-prospect-list.csv',mimeType:'text/csv',buffer:Buffer.from(csv)});
    await expect(page.locator('#si-import-form')).toBeVisible();
  }
  await upload();
  await expect(page.locator('[name="map-account"]')).toHaveValue('0');
  await expect(page.locator('[name="map-contact"]')).toHaveValue('1');
  expect(await page.evaluate(()=>SC.state.salesWorkflows?.prospects?.length||0)).toBe(baseline.prospects);
  await page.locator('#si-import-form [name="confirmed"]').check();
  await page.getByRole('button',{name:'Import reviewed prospects',exact:true}).click();
  await expect(page.locator('#si-status')).toContainText('2 reviewed rows');
  const result=await page.evaluate(()=>({activities:SC.state.activities.length,prospects:SC.state.salesWorkflows.prospects.filter(p=>p.account.startsWith('Synthetic '))}));
  expect(result.activities).toBe(baseline.activities);
  expect(result.prospects).toHaveLength(2);
  expect(result.prospects[0]).toMatchObject({account:'Synthetic Bridge Labs',contact:'Sam Example',phone:'0012345',status:'New',contacted:false,arrive:'2027-02-01',depart:'2027-02-03'});
  expect(result.prospects[1]).toMatchObject({account:'Synthetic River Works',email:'',phone:'',arrive:'',depart:'',status:'New'});
  expect(result.prospects.every(p=>p.source.fileId)).toBe(true);
  await upload(); await page.locator('#si-import-form [name="confirmed"]').check(); await page.getByRole('button',{name:'Import reviewed prospects',exact:true}).click();
  await expect(page.locator('#si-status')).toContainText('repeated source rows are skipped');
  expect(await page.evaluate(()=>SC.state.salesWorkflows.prospects.length)).toBe(baseline.prospects+2);
});

test('Lighthouse CSV supplies dated BT Update figures to the actual weekly report', async ({ page }) => {
  await open(page,'captureStation');
  await page.locator('#si-destination').selectOption('lighthouse');
  await page.locator('#si-file').setInputFiles({name:'synthetic-bt-drilldown.csv',mimeType:'text/csv',buffer:Buffer.from('Account,RN,Revenue,ADR,LY RN,LY Revenue\nSynthetic Corporate Segment,20,2980,149,25,3500\nTotal,20,2980,149,25,3500')});
  await expect(page.locator('#si-import-form')).toBeVisible();
  const reportDate=await page.evaluate(()=>SC.state.reportDate);
  const start=await page.evaluate(()=>{const d=new Date(SC.state.reportDate+'T00:00:00Z');d.setUTCDate(d.getUTCDate()-6);return d.toISOString().slice(0,10)});
  await page.locator('[name="start"]').fill(start); await page.locator('[name="end"]').fill(reportDate); await page.locator('[name="reportEnd"]').fill(reportDate);
  await page.locator('#si-import-form [name="confirmed"]').check();
  await page.getByRole('button',{name:'Import reviewed BT Update',exact:true}).click();
  await expect(page.locator('#si-status')).toContainText('1 BT accounts / segments');
  const source=await page.evaluate(()=>SC.state.btImports[0]);
  expect(source.rows).toHaveLength(1); expect(source.rows[0]).toMatchObject({rn:20,revenue:2980,adr:149,lyRn:25,lyRevenue:3500});
  await page.evaluate(()=>SC.navigate('weekly'));
  await expect(page.locator('#view')).toContainText('Synthetic Corporate Segment');
  await expect(page.locator('#view')).toContainText('20 room nights');
  const text=await page.evaluate(()=>weeklyEmailText());
  expect(text).toContain('Synthetic Corporate Segment'); expect(text).toContain('$2,980'); expect(text).toContain('-20.0%');
});

test('a reviewed Call Desk RFP creates a new prospect without inventing a contacted call', async ({ page }) => {
  await open(page,'calls');
  const before=await page.evaluate(()=>({activities:SC.state.activities.length,rfps:SC.state.rfps.length}));
  await page.locator('[data-local-action="manual"]').click();
  await page.locator('#local-review-text').fill('Company: Synthetic Tunnel Engineering\nContact: Taylor Example\nEmail: taylor@example.test\nGroup: Synthetic Training Visit\nRequest a training group proposal.');
  await page.locator('[data-local-action="suggest"]').click();
  await page.locator('#local-review-form [name="destination"]').selectOption('rfp');
  await page.locator('#local-review-form [name="confirmed"]').check();
  await page.getByRole('button',{name:'Confirm & add reviewed draft',exact:true}).click();
  await expect(page.locator('#local-review-dialog')).toHaveCount(0);
  const result=await page.evaluate(()=>({activities:SC.state.activities.length,rfps:SC.state.rfps,prospects:SC.state.salesWorkflows.prospects}));
  expect(result.activities).toBe(before.activities); expect(result.rfps).toHaveLength(before.rfps+1);
  expect(result.prospects.find(p=>p.account==='Synthetic Tunnel Engineering')).toMatchObject({status:'New',contacted:false,contact:'Taylor Example'});
});

test('Deal Review reconciles occupied costs, paid revenue and displacement, and rejects stale exports', async ({ page }) => {
  await open(page,'dealCheck');
  async function field(name,value){await page.locator(`[data-dc-field="${name}"]`).fill(String(value));await page.locator(`[data-dc-field="${name}"]`).press('Tab');}
  await field('groupName','Synthetic Bridge Training'); await field('arrival','2026-12-01');await field('departure','2026-12-02');
  await page.locator('[data-dc-action="apply-dates"]').click();
  for(const [name,value]of Object.entries({rate:150,variableCost:30,commissionPct:5,paymentFeePct:0,rebatePerPaidRN:0,concessionPerOccupiedRN:0,fixedConcessions:0,incrementalFixedCost:0,ancillaryRevenue:0,ancillaryCost:0,alternativeVariableCost:40,alternativeCommissionPct:0,targetContribution:0,stressPickupPct:80,forecastStressPct:10,alternativeRateStressPct:10}))await field(name,value);
  for(const [name,value]of Object.entries({rooms:20,compRooms:2,capacity:100,forecastRooms:90,alternativeADR:200})){
    const input=page.locator(`[data-dc-night="2026-12-01"][data-dc-column="${name}"]`);await input.fill(String(value));await input.press('Tab');
  }
  await page.locator('[data-dc-action="analyze"]').click();
  await expect(page.locator('[data-dc-result="incremental"]')).toHaveText('$365.00');
  await expect(page.locator('[data-dc-result="breakEven"]')).toHaveText('$128.66');
  const downloadEvent=page.waitForEvent('download'); await page.locator('[data-dc-action="export"][data-format="json"]').click();
  const download=await downloadEvent;const fs=await import('node:fs/promises');const exported=JSON.parse(await fs.readFile(await download.path(),'utf8'));
  expect(exported.analysis.base).toMatchObject({paidRN:18,occupiedRN:20,roomRevenue:2700,commissions:135,variableCosts:600,displacedRN:10,displacedContribution:1600,incrementalContribution:365,breakEvenRate:128.66});
  expect(exported.analysis.scenarios.find(s=>s.key==='demand')?.incrementalContribution).toBeCloseTo(-1635,8);
  await field('variableCost',35);
  await expect(page.locator('.dc-stale')).toContainText('Recalculate');
  const exports=page.locator('[data-dc-action="export"]'); for(let i=0;i<await exports.count();i++)await expect(exports.nth(i)).toBeDisabled();
});

test('section-to-report review adds one dated highlight and duplicate checking preserves source records', async ({ page }) => {
  await open(page,'home');
  const before=await page.evaluate(()=>SC.state.activities.length);
  async function submitHighlight(){
    await page.getByRole('button',{name:'Send this section to weekly report',exact:true}).click();
    await page.locator('#sc-section-report-form [name="summary"]').fill('Synthetic reviewed sales highlight: training opportunity needs a site visit.');
    const date=await page.evaluate(()=>SC.state.reportDate);
    await page.locator('#sc-section-report-form [name="date"]').fill(date);
    await page.locator('#sc-section-report-form [name="confirmed"]').check();
    await page.getByRole('button',{name:'Send reviewed highlight',exact:true}).click();
    await expect(page.locator('#sc-section-report-form')).toHaveCount(0);
  }
  await page.getByRole('button',{name:'Send this section to weekly report',exact:true}).click();
  expect(await page.evaluate(()=>SC.state.salesWorkflows?.reportPins?.filter(p=>p.item.kind==='highlight').length||0)).toBe(0);
  await page.locator('#sc-section-report-form [data-act="xClose"]').click();
  await submitHighlight(); await submitHighlight();
  const result=await page.evaluate(()=>({activities:SC.state.activities.length,pins:SC.state.salesWorkflows.reportPins.filter(p=>p.item.kind==='highlight'),report:weeklyEmailText()}));
  expect(result.activities).toBe(before);expect(result.pins).toHaveLength(1);
  expect(result.report.match(/Synthetic reviewed sales highlight/g)).toHaveLength(1);
  await page.evaluate(()=>{
    const common={propertyId:SC.propertyId,date:SC.state.reportDate,type:'prospecting',account:'Synthetic Duplicate Test',contact:'Sam Example',notes:'Actually called and left a proposal message.'};
    SC.state.activities.push({...common,id:'qa-duplicate-one'},{...common,id:'qa-duplicate-two'});SC.save();SC.render();
  });
  await page.locator('#sc-report-dedup').click();
  await expect(page.getByRole('dialog')).toContainText('Synthetic Duplicate Test');
  await expect(page.getByRole('dialog')).toContainText('2 matching records');
  expect(await page.evaluate(()=>SC.state.activities.length)).toBe(before+2);
});

test('Three Rivers actually advances its gentle animation when motion is enabled', async ({ page }) => {
  await page.emulateMedia({reducedMotion:'no-preference'});await open(page);
  await appearance(page);await page.locator('[data-pg-palette="river"]').click();await page.locator('#pgMotionEnabled').check();await page.keyboard.press('Escape');
  await expect(page.locator('html')).toHaveAttribute('data-pg-motion','on');
  const snapshot=()=>page.locator('.pg-river-lines').evaluate(el=>({transform:getComputedStyle(el).transform,progress:el.getAnimations().map(a=>a.currentTime),box:el.getBoundingClientRect().toJSON()}));
  const moving='.pg-car-forward,.pg-car-reverse,.pg-plane,.pg-window-light,.pg-river-current,.pg-water-reflection';
  const clocks=()=>page.locator(moving).evaluateAll(nodes=>nodes.map(el=>({name:el.getAttribute('class'),time:el.getAnimations()[0]?.currentTime})));
  const initialClocks=await clocks();expect(initialClocks.length).toBeGreaterThanOrEqual(6);expect(initialClocks.every(c=>typeof c.time==='number')).toBe(true);
  const first=await snapshot();
  expect(first.box.width).toBeGreaterThan(100);expect(first.progress.length).toBeGreaterThan(0);
  await page.waitForTimeout(1200);
  const laterClocks=await clocks();for(let i=0;i<initialClocks.length;i++)expect(laterClocks[i].time).toBeGreaterThan(initialClocks[i].time+900);
  const second=await snapshot();expect(second.progress[0]).toBeGreaterThan(first.progress[0]+900);expect(second.transform).not.toBe(first.transform);
  await page.screenshot({path:'docs/screenshots/pittsburgh-river-motion-enabled.png'});
  await page.emulateMedia({reducedMotion:'reduce'});
  await expect(page.locator('html')).toHaveAttribute('data-pg-motion','off');
  expect(await page.locator(moving+',.pg-river-lines').evaluateAll(nodes=>nodes.reduce((n,el)=>n+el.getAnimations().length,0))).toBe(0);
});

test('reviewed Call Desk prospecting call counts once and retains one linked contacted prospect', async ({ page }) => {
  await open(page,'calls');
  await page.evaluate(async()=>{await SC.createProperty({name:'Synthetic QA Call Hotel',rooms:100});SC.navigate('calls')});
  await page.locator('[data-local-action="manual"]').click();
  await expect(page.locator('#local-review-form [name="activityType"]')).toHaveValue('prospecting');
  await page.locator('#local-review-text').fill('Company: Synthetic North Shore Business\nContact: Jordan Example\nEmail: jordan@example.test\nActually discussed upcoming training travel and requested proposal follow-up.');
  await page.locator('[data-local-action="suggest"]').click();
  await page.locator('#local-review-form [name="destination"]').selectOption('activity');
  await page.locator('#local-review-form [name="activityType"]').selectOption('prospecting');
  await page.locator('#local-review-form [name="confirmed"]').check();
  await page.getByRole('button',{name:'Confirm & add reviewed draft',exact:true}).click();
  await expect(page.locator('#local-review-dialog')).toHaveCount(0);
  await page.evaluate(()=>{SC.render();SC.render();SC.navigate('weekly');SC.render()});
  let result=await page.evaluate(()=>({activities:SC.state.activities,prospects:SC.state.salesWorkflows.prospects,counts:activityCounts()}));
  expect(result.activities).toHaveLength(1);expect(result.activities[0].type).toBe('prospecting');expect(result.counts.prospecting).toBe(1);expect(result.counts.total).toBe(1);
  expect(result.prospects).toHaveLength(1);expect(result.prospects[0]).toMatchObject({account:'Synthetic North Shore Business',status:'Contacted',contacted:true,contactActivityId:result.activities[0].id});
  await page.evaluate(async()=>{await SC.storage.flush()});await page.reload();await page.evaluate(async()=>{await SC.ready;SC.navigate('prospects');SC.render()});
  result=await page.evaluate(()=>({prospects:SC.state.salesWorkflows.prospects,counts:activityCounts()}));
  expect(result.prospects).toHaveLength(1);expect(result.counts.prospecting).toBe(1);
});

test('manual report controls remain available after async library views finish loading',async({page})=>{
  await open(page,'home');
  const ids=await page.evaluate(()=>SC.navigation.flatMap(([,rows])=>rows.map(([id])=>id)).filter(id=>['srpVault','templateLibrary','accountRadar'].includes(id)));
  expect(ids.length).toBeGreaterThanOrEqual(2);
  for(const id of ids){
    await page.evaluate(id=>SC.navigate(id),id);
    await expect(page.locator('#view .sc-loading')).toHaveCount(0);
    await expect(page.locator('#sc-report-dedup')).toBeVisible();
    await expect(page.getByRole('button',{name:'Send this section to weekly report',exact:true})).toHaveCount(1);
    await page.waitForTimeout(150);
    expect(await page.locator('#sc-report-dedup').count()).toBe(1);
  }
});
