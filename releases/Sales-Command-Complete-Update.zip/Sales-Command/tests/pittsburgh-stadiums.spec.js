import {test,expect} from '@playwright/test';

async function open(page){await page.goto('/');await page.waitForFunction(()=>window.SC?.ready);await page.evaluate(async()=>{await SC.ready;SC.navigate('home')});}
async function palette(page,value){await page.locator('#top [data-act="theme"]').click();await page.locator(`[data-pg-palette="${value}"]`).click();await page.keyboard.press('Escape');await expect(page.locator('html')).toHaveAttribute('data-pittsburgh-palette',value);}

// The scene is authored SVG; assertions check rendered visibility and geometry rather than class names alone.
test('River alone shows both stadiums and its selection persists without changing sales data',async({page})=>{
 await open(page);const before=await page.evaluate(()=>JSON.stringify({propertyId:SC.propertyId,accounts:SC.state.accounts,activities:SC.state.activities}));
 for(const value of ['steel','river','copper','daylight']){
  await palette(page,value);
  for(const selector of ['.pg-ballpark','.pg-football-stadium']){
   if(value==='river')await expect(page.locator(selector)).toBeVisible();else await expect(page.locator(selector)).toBeHidden();
  }
  await expect(page.locator('.pg-city-buildings')).toBeVisible();await expect(page.locator('.pg-bridge')).toBeVisible();
 }
 await palette(page,'river');await page.reload();await page.evaluate(async()=>{await SC.ready});
 await expect(page.locator('html')).toHaveAttribute('data-pittsburgh-palette','river');await expect(page.locator('.pg-ballpark')).toBeVisible();await expect(page.locator('.pg-football-stadium')).toBeVisible();
 expect(await page.evaluate(()=>JSON.stringify({propertyId:SC.propertyId,accounts:SC.state.accounts,activities:SC.state.activities}))).toBe(before);
});

for(const[size,width,height]of [['desktop',1440,1000],['phone',390,844]])test(`both River stadium landmarks fit inside the ${size} hero without page overflow`,async({page})=>{
 await page.setViewportSize({width,height});const errors=[];page.on('pageerror',e=>errors.push(e.message));await open(page);await palette(page,'river');
 const hero=await page.locator('#scToday').boundingBox(),boxes=[];
 for(const selector of ['.pg-ballpark','.pg-football-stadium']){
  await expect(page.locator(selector)).toBeVisible();const box=await page.locator(selector).boundingBox();expect(box.width).toBeGreaterThan(20);expect(box.height).toBeGreaterThan(10);
  expect(box.x).toBeGreaterThanOrEqual(Math.max(0,hero.x)-2);expect(box.y).toBeGreaterThanOrEqual(hero.y-2);expect(box.x+box.width).toBeLessThanOrEqual(Math.min(width,hero.x+hero.width)+2);expect(box.y+box.height).toBeLessThanOrEqual(hero.y+hero.height+2);boxes.push(box);
 }
 expect(Math.abs(boxes[0].x+boxes[0].width/2-boxes[1].x-boxes[1].width/2)).toBeGreaterThan(30);
 expect(await page.evaluate(()=>document.documentElement.scrollWidth)).toBe(width);expect(errors).toEqual([]);
 await page.mouse.move(0,0);await page.evaluate(()=>document.activeElement?.blur());await expect(page.locator('#toast')).not.toHaveClass(/show/);
 await page.screenshot({path:`docs/screenshots/pittsburgh-stadiums-${size}.png`});
 await page.screenshot({path:`docs/screenshots/pittsburgh-river-${size}.png`});
});

test('stadium lighting advances with motion enabled and stops for reduced-motion preference',async({page})=>{
 await page.emulateMedia({reducedMotion:'no-preference'});await open(page);await palette(page,'river');
 const clocks=()=>page.locator('.pg-stadium-light').evaluateAll(nodes=>nodes.map(n=>n.getAnimations()[0]?.currentTime));
 const first=await clocks();expect(first.length).toBeGreaterThan(0);expect(first.every(t=>typeof t==='number')).toBe(true);
 await page.waitForTimeout(1200);const second=await clocks();expect(second).toHaveLength(first.length);for(let i=0;i<first.length;i++)expect(second[i]).toBeGreaterThan(first[i]+900);
 await page.emulateMedia({reducedMotion:'reduce'});await expect(page.locator('html')).toHaveAttribute('data-pg-motion','off');expect(await page.locator('.pg-stadium-light').evaluateAll(nodes=>nodes.reduce((n,e)=>n+e.getAnimations().length,0))).toBe(0);
});
