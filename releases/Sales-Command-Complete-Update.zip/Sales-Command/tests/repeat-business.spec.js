import { test, expect } from '@playwright/test';

async function open(page) {
  await page.goto('/');
  await page.evaluate(async () => { await window.SC.ready; });
  await page.waitForFunction(() => window.SC.repeatBusiness && window.SC.atomicMutation);
}
const fixture = () => ({ account: 'Synthetic Repeat Company', event: 'Synthetic Annual Meeting', arrive: '2024-06-01', depart: '2024-06-03', asOf: '2024-06-05', sourceName: 'Synthetic stayed-production report', actualRn: '80', actualRevenue: '12000', contractedRn: '100', contractedRevenue: '15000', organizer: 'Synthetic Organizer', email: 'organizer@example.invalid', preferences: 'Business preference: early meeting room access', outcome: '80% pickup; discuss room allocation next cycle', reviewed: true, sourceKind: 'manual' });

test('closeout validates actuals separately from contractual values and reconciles nightly pickup', async ({ page }) => {
  await open(page);
  const result = await page.evaluate(async input => {
    const { normalizeCloseout, repeatVariance, parseActualCSV } = await import('/src/repeat-business.js');
    const normalized = normalizeCloseout(input);
    const failures = [];
    for (const patch of [
      { actualRn: '', actualRevenue: '', contractedRn: '100', contractedRevenue: '15000' },
      { actualRn: false },
      { actualRn: '1.5' },
      { actualRn: '0', actualRevenue: '100' },
      { actualRn: '0', actualRevenue: '0', actualAdr: '150' },
      { actualAdr: '149' },
      { reviewed: false },
      { arrive: '2024-02-31' },
      { arrive: '2024-06-01extra' },
      { nightly: [{ date: '2024-06-01', rn: 80, revenue: 12000 }] },
      { nightly: [{ date: '2024-06-01', rn: 40, revenue: 6000 }, { date: '2024-06-03', rn: 40, revenue: 6000 }] },
      { nightly: [{ date: '2024-06-01', rn: 39, revenue: 6000 }, { date: '2024-06-02', rn: 40, revenue: 6000 }] },
    ]) {
      try { normalizeCloseout({ ...input, ...patch }); failures.push(false); } catch { failures.push(true); }
    }
    const csv = parseActualCSV('Date,Room nights,Room revenue\n2024-06-01,40,6000\n2024-06-02,40,6000');
    const nightly = normalizeCloseout({ ...input, nightly: csv.nightly });
    const partial = normalizeCloseout({ ...input, actualRevenue: '', actualAdr: '' });
    let invalidCSV = false;
    try { parseActualCSV('Date,Room nights,Room revenue\n2024-06-01,40,6000\n2024-06-01,40,6000'); } catch { invalidCSV = true; }
    return { actual: normalized.actuals, variance: repeatVariance(normalized), failures, csv, nightly: nightly.actuals.nightly.length, unknownRevenue: partial.actuals.revenue, unknownADR: partial.actuals.adr, invalidCSV };
  }, fixture());
  expect(result.failures.every(Boolean)).toBe(true);
  expect(result.actual.rn).toBe(80);
  expect(result.actual.revenue).toBe(12000);
  expect(result.actual.adr).toBe(150);
  expect(result.variance).toEqual({ rn: -20, revenue: -3000, adr: 0, pickupPct: 80 });
  expect(result.csv.rn).toBe(80);
  expect(result.nightly).toBe(2);
  expect(result.unknownRevenue).toBeNull();
  expect(result.unknownADR).toBeNull();
  expect(result.invalidCSV).toBe(true);
});

test('selecting a past opportunity prefills declared comparison but never actual production', async ({ page }) => {
  await open(page);
  const id = await page.evaluate(() => {
    const booking = SC.commitGroup({ name: 'Synthetic Past Group', account: 'Synthetic Past Company', arrive: '2024-06-01', depart: '2024-06-03', rn: 100, rev: 15000, adr: 150, status: 'Definite' }, SC.propertyId);
    SC.navigate('repeatBusiness'); return booking.id;
  });
  await page.locator('[data-rb-action="new"]').click();
  await page.locator('#rb-source').selectOption('booking:' + id);
  await expect(page.locator('#rb-closeout-form [name="contractedRn"]')).toHaveValue('100');
  await expect(page.locator('#rb-closeout-form [name="contractedRevenue"]')).toHaveValue('15000');
  await expect(page.locator('#rb-closeout-form [name="actualRn"]')).toHaveValue('');
  await expect(page.locator('#rb-closeout-form [name="actualRevenue"]')).toHaveValue('');
  await expect(page.locator('#rb-closeout-form [name="actualAdr"]')).toHaveValue('');
  expect(await page.evaluate(() => SC.repeatBusiness.memories().length)).toBe(0);
});

test('reviewed actual CSV retains its original, displays variance and supports a local reminder', async ({ page }) => {
  await open(page);
  await page.evaluate(() => SC.navigate('repeatBusiness'));
  await page.locator('[data-rb-action="new"]').click();
  const form = page.locator('#rb-closeout-form');
  for (const [key, value] of Object.entries(fixture())) {
    if (['sourceKind', 'reviewed', 'actualRn', 'actualRevenue'].includes(key)) continue;
    await form.locator(`[name="${key}"]`).fill(String(value));
  }
  await page.locator('#rb-actual-csv').setInputFiles({ name: 'synthetic-repeat-actuals.csv', mimeType: 'text/csv', buffer: Buffer.from('Date,Room nights,Room revenue\n2024-06-01,40,6000\n2024-06-02,40,6000') });
  await expect(form.locator('[name="actualRn"]')).toHaveValue('80');
  await expect(form.locator('[name="actualRevenue"]')).toHaveValue('12000');
  await expect(form.locator('[name="reviewed"]')).not.toBeChecked();
  await form.locator('[name="reviewed"]').check();
  await form.locator('[type="submit"]').click();
  await expect.poll(() => page.evaluate(() => SC.repeatBusiness.memories().length)).toBe(1);
  const source = await page.evaluate(async () => { const m = SC.repeatBusiness.memories()[0]; return { file: await (await SC.storage.db.files.get(m.actualSource.fileId)).blob.text(), id: m.id }; });
  expect(source.file).toContain('2024-06-02,40,6000');
  await expect(page.locator('.rb-memory')).toContainText('80%');
  await expect(page.locator('.rb-memory')).toContainText('-$3,000.00');
  const downloadPromise = page.waitForEvent('download');
  await page.locator('.rb-memory [data-rb-action="source"]').click();
  expect((await downloadPromise).suggestedFilename()).toBe('synthetic-repeat-actuals.csv');
  await expect.poll(() => page.evaluate(() => SC.repeatBusiness.isBusy())).toBe(false);
  await page.locator('.rb-memory [data-rb-action="reminder"]').click();
  const today = await page.evaluate(() => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; });
  await page.locator('#rb-reminder-form [name="date"]').fill(today);
  await page.locator('#rb-reminder-form [name="leadDays"]').fill('90');
  await page.locator('#rb-reminder-form [type="submit"]').click();
  await expect.poll(() => page.evaluate(() => SC.repeatBusiness.queue().length)).toBe(1);
  await expect(page.locator('#rb-reminder-queue')).toContainText('Synthetic Annual Meeting');
  expect(await page.evaluate(() => SC.state.activities.length)).toBe(0);
});

test('new cycles require confirmed future dates, stay unquoted and create only one linked opportunity', async ({ page }) => {
  await open(page);
  const result = await page.evaluate(async input => {
    const m = await SC.repeatBusiness.closeout(input);
    const year = new Date().getFullYear() + 1, proposed = { label: year + ' annual meeting', arrive: `${year}-06-01`, depart: `${year}-06-03` };
    const before = { bookings: SC.state.bookings.length, prospects: SC.state.salesWorkflows?.prospects?.length || 0, activities: SC.state.activities.length };
    let noConfirmation = false, oldDates = false;
    try { await SC.repeatBusiness.createCycle(m.id, proposed); } catch { noConfirmation = true; }
    try { await SC.repeatBusiness.createCycle(m.id, { ...proposed, arrive: m.arrive, depart: m.depart, confirmedNewDates: true }); } catch { oldDates = true; }
    const first = await SC.repeatBusiness.createCycle(m.id, { ...proposed, confirmedNewDates: true });
    const second = await SC.repeatBusiness.createCycle(m.id, { ...proposed, label: proposed.label.toUpperCase(), confirmedNewDates: true });
    const b = SC.state.bookings.find(b => b.id === first.bookingId), p = SC.state.salesWorkflows.prospects.find(p => p.id === first.prospectId);
    return { noConfirmation, oldDates, first, second, before, after: { bookings: SC.state.bookings.length, prospects: SC.state.salesWorkflows.prospects.length, activities: SC.state.activities.length }, b, p };
  }, fixture());
  expect(result.noConfirmation).toBe(true);
  expect(result.oldDates).toBe(true);
  expect(result.first.existing).toBe(false);
  expect(result.second.existing).toBe(true);
  expect(result.second.bookingId).toBe(result.first.bookingId);
  expect(result.after.bookings).toBe(result.before.bookings + 1);
  expect(result.after.prospects).toBe(result.before.prospects + 1);
  expect(result.after.activities).toBe(result.before.activities);
  expect(result.b).toMatchObject({ status: 'Prospect', rn: 0, adr: 0, rev: 0, unquoted: true });
  expect(result.b.arrive).not.toBe('2024-06-01');
  expect(result.p).toMatchObject({ contacted: false, status: 'New' });
});

test('memory and actual-source links reject other properties and survive encrypted backup', async ({ page }) => {
  await open(page);
  const result = await page.evaluate(async input => {
    const m = await SC.repeatBusiness.closeout(input), a = SC.propertyId;
    SC.save(); await SC.storage.flush();
    const backup = await SC.storage.backup('Synthetic repeat backup passphrase');
    await SC.createProperty({ name: 'Synthetic Repeat Hotel B', rooms: 80 });
    const before = JSON.stringify(SC.state); let foreignCycle = false, foreignCloseout = false;
    try { await SC.repeatBusiness.createCycle(m.id, { label: 'Other cycle', arrive: '2090-06-01', depart: '2090-06-03', confirmedNewDates: true }, { propertyId: a }); } catch { foreignCycle = true; }
    try { await SC.repeatBusiness.closeout(input, { propertyId: a }); } catch { foreignCloseout = true; }
    const isolated = JSON.stringify(SC.state) === before && SC.repeatBusiness.memories().length === 0;
    await SC.storage.restore(backup, 'Synthetic repeat backup passphrase');
    const restored = SC.repeatBusiness.memories();
    await SC.storage.db.files.put({ id: 'synthetic-foreign-production', propertyId: 'other', hash: 'a'.repeat(64), blob: new Blob(['Synthetic source']), name: 'foreign.csv' });
    let foreignFile = false;
    try { await SC.repeatBusiness.closeout({ ...input, event: 'Different event', fileId: 'synthetic-foreign-production', hash: 'a'.repeat(64) }); } catch { foreignFile = true; }
    return { foreignCycle, foreignCloseout, foreignFile, isolated, active: SC.propertyId, expected: a, restored };
  }, fixture());
  expect(result.foreignCycle).toBe(true);
  expect(result.foreignCloseout).toBe(true);
  expect(result.foreignFile).toBe(true);
  expect(result.isolated).toBe(true);
  expect(result.active).toBe(result.expected);
  expect(result.restored).toHaveLength(1);
  expect(result.restored[0].actuals.rn).toBe(80);
  expect(result.restored[0].contracted.rn).toBe(100);
});

test('closeout text is escaped and repeated or stale closeouts cannot overwrite accepted facts', async ({ page }) => {
  await open(page);
  const result = await page.evaluate(async input => {
    window.__repeatXss = 0;
    const malicious = '<img src=x onerror="window.__repeatXss=1">';
    const m = await SC.repeatBusiness.closeout({ ...input, event: malicious, preferences: malicious });
    let duplicate = false, stale = false;
    try { await SC.repeatBusiness.closeout({ ...input, event: malicious }); } catch { duplicate = true; }
    await SC.repeatBusiness.closeout({ ...input, event: malicious, outcome: 'Reviewed update' }, { memoryId: m.id, baseJSON: JSON.stringify(m) });
    try { await SC.repeatBusiness.closeout({ ...input, event: malicious, outcome: 'Stale update' }, { memoryId: m.id, baseJSON: JSON.stringify(m) }); } catch { stale = true; }
    SC.navigate('repeatBusiness');
    return { duplicate, stale, facts: SC.repeatBusiness.memories()[0] };
  }, fixture());
  expect(result.duplicate).toBe(true);
  expect(result.stale).toBe(true);
  expect(result.facts.outcome).toBe('Reviewed update');
  await expect(page.locator('.rb-memory img')).toHaveCount(0);
  expect(await page.evaluate(() => window.__repeatXss)).toBe(0);
});

test('Import Station CSV entry opens an uncommitted closeout and source lists exclude foreign records', async ({ page }) => {
  await open(page);
  await page.evaluate(async () => {
    SC.state.bookings.push({ id: 'foreign-booking', propertyId: 'foreign-hotel', name: 'Foreign hidden group' });
    await SC.repeatBusiness.receiveFile(new File(['Actual room nights,Actual room revenue\n25,3750'], 'synthetic-summary.csv', { type: 'text/csv' }), { propertyId: SC.propertyId });
  });
  await expect(page.locator('#rb-closeout-form')).toBeVisible();
  await expect(page.locator('#rb-closeout-form [name="actualRn"]')).toHaveValue('25');
  await expect(page.locator('#rb-closeout-form [name="actualRevenue"]')).toHaveValue('3750');
  await expect(page.locator('#rb-closeout-form [name="arrive"]')).toHaveValue('');
  await expect(page.locator('#rb-closeout-form [name="asOf"]')).toHaveValue('');
  await expect(page.locator('#rb-closeout-form [name="reviewed"]')).not.toBeChecked();
  await expect(page.locator('#rb-source')).not.toContainText('Foreign hidden group');
  expect(await page.evaluate(() => SC.repeatBusiness.memories().length)).toBe(0);
});

test('closeout weekly summary is dated once and never invents missing actual revenue or another call', async ({ page }) => {
  await open(page);
  const result = await page.evaluate(async input => {
    const before = SC.state.activities.length;
    const m = await SC.repeatBusiness.closeout({ ...input, actualRevenue: '', actualAdr: '' });
    const date = m.actualSource.reviewedDate;
    const range = SC.reportRange(date);
    const one = SC.repeatBusiness.weeklyHighlights(range);
    await SC.repeatBusiness.closeout({ ...input, actualRevenue: '', actualAdr: '', outcome: 'Reviewed correction' }, { memoryId: m.id, baseJSON: JSON.stringify(m) });
    const updated = SC.repeatBusiness.weeklyHighlights(range);
    const exported = SC.salesReport.data(date).hl.filter(line => line.includes('Closeout reviewed') && line.includes(input.event));
    return { one, updated, exported, before, after: SC.state.activities.length };
  }, fixture());
  expect(result.one).toHaveLength(1);
  expect(result.updated).toHaveLength(1);
  expect(result.exported).toHaveLength(1);
  expect(result.updated[0]).toContain('actual room revenue Unknown');
  expect(result.updated[0]).toContain('PAST stay 2024-06-01 to 2024-06-03');
  expect(result.after).toBe(result.before);
});
