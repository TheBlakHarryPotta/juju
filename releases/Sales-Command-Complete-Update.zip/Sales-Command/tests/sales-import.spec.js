import {test,expect} from '@playwright/test';
import {parseTable,workbookTables,matrixTable,guessMapping,mappedProspects,mappedBT,btSummary,BT_FIELDS,dateValue} from '../src/sales-import-parser.js';
test('prospect table preserves quoted names, leadingzero phones, absent fields and explicit dates',()=>{
 const table=parseTable('Company,Contact,Email,Phone,Arrival,Departure\n"Example, Inc",Taylor,taylor@example.test,00123,2027-04-01,2027-04-03\nOther,Casey,,,,');
 const rows=mappedProspects(table,guessMapping(table.headers));expect(rows[0]).toMatchObject({account:'Example, Inc',phone:'00123',arrive:'2027-04-01'});expect(rows[1]).toMatchObject({contact:'Casey',email:'',arrive:''});
});
test('tables reject broken quotes, oversized cells, ambiguous dates and unsafe arbitrary header mapping',()=>{
 expect(()=>parseTable('Company,Contact\n"unfinished,Person')).toThrow(/unfinished/);
 expect(()=>parseTable('Company,Contact\nA,'+'a'.repeat(20001))).toThrow(/limit/);
 expect(()=>dateValue('04/05/2027')).toThrow(/YYYY/);expect(dateValue('04/05/2027','MDY')).toBe('2027-04-05');expect(dateValue('04/05/2027','DMY')).toBe('2027-05-04');
 expect(()=>dateValue('2027-02-29')).toThrow();
 const table=parseTable('__proto__,Company,constructor\nevil,Example,bad');const rows=mappedProspects(table,guessMapping(table.headers));expect(rows[0].account).toBe('Example');expect(Object.hasOwn(rows[0],'__proto__')).toBe(false);
});
test('Excel sparse matrices preserve numeric zeros and locate report headers',()=>{
 const sheets=workbookTables({sheets:{Data:{A1:'Source title',A3:'Company',B3:'Contact',C3:'Arrival',A4:'Example',B4:'Taylor',C4:46478}}});
 const table=matrixTable(sheets[0].matrix);expect(table.headerRow).toBe(3);const rows=mappedProspects(table,guessMapping(table.headers));expect(rows[0].arrive).toMatch(/^2027-/);
 expect(()=>workbookTables({sheets:{Bad:{XFD1000000:1}}})).toThrow(/exceeds/);
});
test('Lighthouse BT rows exclude totals and calculate sourced decline without inventing absent comparison',()=>{
 const table=parseTable('Segment,Room Nights,Room Revenue,ADR,LY Room Nights,LY Revenue\nBusiness Transient,20,"2,980",149,25,3500\nOther BT,0,0,0,,\nTotal,20,2980,149,25,3500');
 const rows=mappedBT(table,guessMapping(table.headers,BT_FIELDS));expect(rows).toHaveLength(2);expect(rows[0].adr).toBe(149);expect(rows[1].lyRn).toBe(null);
 const text=btSummary(rows[0],{start:'2026-10-24',end:'2026-10-30'});expect(text).toContain('-20.0%');expect(text).toContain('$2,980.00');
 const duplicate=parseTable('Account,Room Nights,Revenue\nExample,2,100\nExample,3,200');expect(()=>mappedBT(duplicate,guessMapping(duplicate.headers,BT_FIELDS))).toThrow(/Duplicate/);
});
test('BT mapping rejects mixed counts, negative revenues, inconsistent ADR and duplicate column use',()=>{
 for(const line of ['Example,2.5,100,40','Example,2,-100,50','Example,2,100,200']){
 const table=parseTable('Account,Room Nights,Revenue,ADR\n'+line);expect(()=>mappedBT(table,guessMapping(table.headers,BT_FIELDS))).toThrow();}
 const table=parseTable('Account,Room Nights,Revenue\nExample,2,100');expect(()=>mappedBT(table,{account:0,rn:1,revenue:1,adr:-1,lyRn:-1,lyRevenue:-1})).toThrow(/once/);
});
