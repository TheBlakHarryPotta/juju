import { test, expect } from '@playwright/test';
import { analyzeRadar, parseCSV, mergeText, safeCSV } from '../src/workspaces-model.js';

const period = (id, start, end, rows, options = {}) => ({ id, periodStart: start, periodEnd: end, basis: 'stayed', complete: true, rows, ...options });

test('radar distinguishes explicit decline, reactivation, new observation, and missing data', () => {
  const old = period('old', '2025-10-01', '2025-10-28', [{ account: 'ABC', rn: 40 }, { account: 'Returning', rn: 0 }, { account: 'Missing', rn: 30 }]);
  const current = period('now', '2026-10-01', '2026-10-28', [{ account: 'ABC', rn: 20 }, { account: 'Returning', rn: 8 }, { account: 'New observed', rn: 12 }]);
  const history = [period('prior', '2024-10-01', '2024-10-28', [{ account: 'Returning', rn: 4 }])];
  const result = analyzeRadar(current, old, history, true);
  expect(result.ready).toBe(true);
  expect(result.rows.find(r => r.account === 'ABC')).toMatchObject({ status: 'Declining', delta: -20, change: -.5 });
  expect(result.rows.find(r => r.account === 'Returning').status).toBe('Reactivated');
  expect(result.rows.find(r => r.account === 'New observed').status).toBe('First observed');
  expect(result.rows.find(r => r.account === 'Missing')).toMatchObject({ status: 'Missing current row', rn: null, delta: null });
});

test('radar withholds trend claims for incomplete, overlapping, unequal or unconfirmed comparisons', () => {
  const old = period('old', '2025-10-01', '2025-10-28', [{ account: 'ABC', rn: 40 }]);
  const current = period('now', '2026-10-01', '2026-10-28', [{ account: 'ABC', rn: 10 }]);
  for (const [now, then, comparable] of [
    [current, old, false], [{ ...current, complete: false }, old, true], [current, { ...old, basis: 'booked' }, true],
    [current, { ...old, periodEnd: '2025-10-20' }, true], [current, { ...old, periodStart: current.periodStart, periodEnd: current.periodEnd }, true],
  ]) {
    const result = analyzeRadar(now, then, [], comparable);
    expect(result.ready).toBe(false);
    expect(result.rows.find(r => r.account === 'ABC').status).not.toBe('Declining');
  }
});

test('spreadsheet CSV cells neutralize formulas including leading control and whitespace characters', () => {
  for (const dangerous of ['=1+1', '+SUM(A1)', '-1+1', '@SUM(A1)', '  =1+1', '\t=1+1', '\r=1+1']) {
    expect(safeCSV(dangerous)).toMatch(/^"'/);
  }
  expect(safeCSV('ACME "North", Inc')).toBe('"ACME ""North"", Inc"');
});

test('CSV quoting preserves embedded line breaks and leading zeros and rejects ambiguous input', () => {
  expect(parseCSV('Account,SRP,Note\r\n"ACME, Inc",00123,"line one\nline two"')).toEqual({ headers: ['Account', 'SRP', 'Note'], rows: [['ACME, Inc', '00123', 'line one\nline two']] });
  expect(() => parseCSV('Account,RN,RN\nABC,1,2')).toThrow(/unique/i);
  expect(() => parseCSV('Account,RN\n"ABC,1')).toThrow(/unfinished/i);
  expect(() => parseCSV('Account,RN\nABC,1,2')).toThrow(/column/i);
});

test('contract merge preserves text and refuses unresolved placeholders', () => {
  expect(mergeText('Contract for {{ group }}: {{rate}} at {{property}}. SRP {{code}}.', { group: 'ACME & Sons', rate: '$149.00', property: 'Hotel A', code: '00123' })).toBe('Contract for ACME & Sons: $149.00 at Hotel A. SRP 00123.');
  expect(() => mergeText('Arrive {{arrival}}', {})).toThrow(/arrival/);
  expect(() => mergeText('Contact {{contact}}', { contact: { name: 'person' } })).toThrow(/text|numbers/i);
});
