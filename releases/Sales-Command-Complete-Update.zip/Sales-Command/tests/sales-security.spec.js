import { test, expect } from '@playwright/test';

async function openApp(page) {
  await page.goto('/');
  await page.waitForFunction(() => window.SC?.ready);
  await page.evaluate(async () => { await SC.ready; });
}

test('planned-task envelope cannot be forged into another property or caller-selected ID', async ({ page }) => {
  await openApp(page);
  const result = await page.evaluate(() => {
    const before = (SC.state.plannedTasks || []).length;
    try {
      const saved = SC.commitPlannedTask({ id: 'forged-task-id', propertyId: 'foreign-property', account: 'Synthetic Local Company', due: todayISO(), notes: 'Synthetic planned touch' });
      return { accepted: true, active: SC.propertyId, id: saved.id, propertyId: saved.propertyId };
    } catch (error) {
      return { accepted: false, unchanged: (SC.state.plannedTasks || []).length === before, message: error.message };
    }
  });
  if (result.accepted) {
    expect(result.propertyId).toBe(result.active);
    expect(result.id).not.toBe('forged-task-id');
  } else {
    expect(result.unchanged).toBe(true);
  }
});

test('planning and duplicate completion cannot inflate completed weekly activity', async ({ page }) => {
  await openApp(page);
  const result = await page.evaluate(() => {
    const before = SC.state.activities.length;
    const task = SC.commitPlannedTask({ account: 'Synthetic Pittsburgh Business', due: todayISO(), contact: 'Synthetic Contact', notes: 'Make a real call later' });
    const planned = SC.state.activities.length;
    SC.completePlannedTask(task.id, { date: todayISO(), notes: 'Actually called; requested follow-up next week.' });
    const completed = SC.state.activities.length;
    let rejected = false;
    try { SC.completePlannedTask(task.id, { date: todayISO(), notes: 'Accidental repeated click' }); } catch { rejected = true; }
    return { before, planned, completed, afterRepeat: SC.state.activities.length, rejected };
  });
  expect(result.planned).toBe(result.before);
  expect(result.completed).toBe(result.before + 1);
  expect(result.afterRepeat).toBe(result.completed);
  expect(result.rejected).toBe(true);
});

test('local intake rejects over-limit originals before retaining data', async ({ page }) => {
  await openApp(page);
  const result = await page.evaluate(async () => {
    const before = await SC.storage.db.files.count();
    await SC.intakeFiles([new File([new Uint8Array(25 * 1024 * 1024 + 1)], 'synthetic-too-large.txt', { type: 'text/plain' })]);
    return { before, after: await SC.storage.db.files.count() };
  });
  expect(result.after).toBe(result.before);
});

test('bridge rejects stale-property commits before any active hotel mutation', async ({ page }) => {
  await openApp(page);
  const result = await page.evaluate(() => {
    const before = JSON.stringify(SC.state);
    const rejected = [];
    const operations = [
      ['activity', () => SC.commitActivity({ account: 'Foreign synthetic', notes: 'Do not save' }, 'foreign-property')],
      ['account', () => SC.commitAccount({ name: 'Foreign synthetic' }, 'foreign-property')],
      ['rfp', () => SC.commitRfp({ name: 'Foreign synthetic' }, 'foreign-property')],
      ['group', () => SC.commitGroup({ name: 'Foreign synthetic' }, 'foreign-property')],
      ['plan', () => SC.commitPlannedTask({ account: 'Foreign synthetic', due: todayISO() }, 'foreign-property')],
      ['complete', () => SC.completePlannedTask('missing', { notes: 'Do not save' }, 'foreign-property')],
    ];
    for (const [name, operation] of operations) {
      try { operation(); } catch (error) { rejected.push({ name, message: error.message }); }
    }
    return { rejected, unchanged: JSON.stringify(SC.state) === before };
  });
  expect(result.rejected).toHaveLength(6);
  expect(result.rejected.every(row => /hotel changed|original hotel/i.test(row.message))).toBe(true);
  expect(result.unchanged).toBe(true);
});

test('weekly model excludes foreign-property RFP rows and deduplicates report pins', async () => {
  const { buildWeeklyItems } = await import('../src/sales-model.js');
  const date = '2027-01-04';
  const activity = { id: 'own-activity', propertyId: 'A', date, type: 'followup', account: 'Synthetic own account', notes: 'Actually called' };
  const pin = { reportEnd: '2027-01-07', item: { key: 'activity:own-activity', propertyId: 'A', date, kind: 'followup', account: activity.account, summary: 'Pinned copy of the same work' } };
  const rows = buildWeeklyItems({
    propertyId: 'A', start: '2027-01-01', end: '2027-01-07',
    activities: [activity, { ...activity, id: 'foreign-activity', propertyId: 'B' }, { ...activity, id: 'planned', planned: true, done: false }],
    rfps: [{ id: 'foreign-rfp', propertyId: 'B', receivedDate: date, name: 'Foreign synthetic inquiry' }],
    workflows: { reportPins: [pin, pin] },
  });
  expect(rows).toHaveLength(1);
  expect(rows[0].key).toBe('activity:own-activity');
  expect(JSON.stringify(rows)).not.toContain('Foreign synthetic inquiry');
});

test('hostile import headers map only fixed prospect fields and retain names as plain data', async () => {
  const { parseTable, guessMapping, mappedProspects } = await import('../src/sales-import-parser.js');
  const table = parseTable('Company,Contact,Notes,__proto__,propertyId\n"<img src=x onerror=alert(1)>",Synthetic Contact,"=1+1",polluted,foreign-property');
  const rows = mappedProspects(table, guessMapping(table.headers));
  expect(rows).toHaveLength(1);
  expect(rows[0].account).toBe('<img src=x onerror=alert(1)>');
  expect(rows[0].notes).toBe('=1+1');
  expect(Object.hasOwn(rows[0], '__proto__')).toBe(false);
  expect(Object.hasOwn(rows[0], 'propertyId')).toBe(false);
  expect(Object.prototype.polluted).toBeUndefined();
});

test('table bounds and explicit room-night numbers reject ambiguous input', async () => {
  const { parseTable, nonnegative, dateValue } = await import('../src/sales-import-parser.js');
  expect(() => parseTable('Company,Notes\nSynthetic,' + 'x'.repeat(20001))).toThrow(/limit|20,000|exceeds/i);
  expect(() => dateValue('03/04/2027')).toThrow(/full dates|ambiguous/i);
  expect(() => nonnegative('', 'Room nights', { integer: true })).toThrow(/missing/i);
  expect(() => nonnegative('1.5', 'Room nights', { integer: true })).toThrow(/whole|range/i);
  expect(nonnegative('0', 'Room nights', { integer: true })).toBe(0);
});

test('reviewed hostile prospect text remains inert, local and isolated from another hotel', async ({ page }) => {
  const external = [];
  const foreign = url => /^https?:/.test(url) && !['127.0.0.1', 'localhost', '[::1]'].includes(new URL(url).hostname);
  await page.route('**/*', route => foreign(route.request().url()) ? route.abort() : route.continue());
  page.on('request', request => { if (foreign(request.url())) external.push(request.url()); });
  await openApp(page);
  const payload = '<img src="https://example.invalid/tracker" onerror="window.__salesInjected=1">';
  await page.evaluate(async payload => {
    window.__salesInjected = 0;
    SC.navigate('captureStation');
    const quote = value => '"' + String(value).replaceAll('"', '""') + '"';
    await SC.salesImport.receiveText('Company,Contact,Notes\n' + [payload, 'Synthetic Contact', '=1+1'].map(quote).join(','));
  }, payload);
  await expect(page.locator('.si-review img')).toHaveCount(0);
  await page.locator('#si-import-form input[name="confirmed"]').check();
  await page.locator('#si-import-form button[type="submit"]').click();
  await expect.poll(() => page.evaluate(() => SC.state.salesWorkflows.prospects.some(p => p.account.startsWith('<img')))).toBe(true);
  const own = await page.evaluate(() => {
    const p = SC.state.salesWorkflows.prospects.find(p => p.account.startsWith('<img'));
    SC.navigate('prospects');
    return { propertyId: SC.propertyId, contacted: p.contacted, status: p.status, activities: SC.state.activities.length };
  });
  await expect(page.locator('#sales-prospect-list h3').filter({ hasText: payload })).toHaveCount(1);
  await expect(page.locator('#sales-prospect-list img')).toHaveCount(0);
  expect(await page.evaluate(() => window.__salesInjected)).toBe(0);
  expect(external).toEqual([]);
  expect(own.contacted).toBe(false);
  expect(own.status).toBe('New');
  const switched = await page.evaluate(async previous => {
    await SC.createProperty({ name: 'Synthetic second hotel', rooms: 99 });
    SC.navigate('prospects');
    const before = JSON.stringify(SC.state);
    let rejected = false;
    try { SC.salesWorkflows.importProspects([{ account: 'Do not cross properties' }], { source: { propertyId: previous, id: 'old-source' } }); }
    catch { rejected = true; }
    return { rejected, unchanged: before === JSON.stringify(SC.state), prospects: SC.state.salesWorkflows?.prospects?.length || 0 };
  }, own.propertyId);
  expect(switched.rejected).toBe(true);
  expect(switched.unchanged).toBe(true);
  expect(switched.prospects).toBe(0);
  await expect(page.locator('#view')).not.toContainText(payload);
});

test('same-source BT corrections require approval and survive encrypted backup with sales records', async ({ page }) => {
  await openApp(page);
  const csv = 'Company,Room nights,Room revenue,Other revenue\nSynthetic BT Company,10,1000,2000';
  async function prepare() {
    await page.evaluate(async csv => { SC.state.reportDate = '2027-01-07'; SC.navigate('captureStation'); await SC.salesImport.receiveText(csv); }, csv);
    await page.locator('#si-destination').selectOption('lighthouse');
    await page.locator('#si-import-form [name="start"]').fill('2027-01-01');
    await page.locator('#si-import-form [name="end"]').fill('2027-01-07');
    await page.locator('#si-import-form [name="reportEnd"]').fill('2027-01-07');
    await page.locator('#si-import-form [name="confirmed"]').check();
  }
  await prepare();
  await page.locator('#si-import-form [type="submit"]').click();
  await expect.poll(() => page.evaluate(() => SC.state.btImports?.[0]?.rows[0]?.revenue)).toBe(1000);
  await prepare();
  await page.locator('#si-import-form [name="map-revenue"]').selectOption('3');
  await page.locator('#si-import-form [type="submit"]').click();
  await expect(page.locator('#si-review-error')).toContainText(/replace|correction|already covers/i);
  expect(await page.evaluate(() => SC.state.btImports[0].rows[0].revenue)).toBe(1000);
  await page.locator('#si-import-form [name="replace"]').check();
  await page.locator('#si-import-form [type="submit"]').click();
  await expect.poll(() => page.evaluate(() => SC.state.btImports?.[0]?.rows[0]?.revenue)).toBe(2000);
  expect(await page.evaluate(() => SC.state.btImports.length)).toBe(1);
  const restored = await page.evaluate(async () => {
    SC.salesWorkflows.importProspects([{ account: 'Synthetic backed-up prospect', sourceId: 'row:2' }], { source: { id: 'backup-fixture', propertyId: SC.propertyId } });
    SC.save(); await SC.storage.flush();
    const backup = await SC.storage.backup('Synthetic backup passphrase 2027');
    SC.state.btImports = [];
    SC.state.salesWorkflows.prospects = [];
    SC.save(); await SC.storage.flush();
    await SC.storage.restore(backup, 'Synthetic backup passphrase 2027');
    return { imports: SC.state.btImports.length, revenue: SC.state.btImports[0].rows[0].revenue, prospects: SC.state.salesWorkflows.prospects.map(p => p.account), report: SC.salesReport.data('2027-01-07').bt };
  });
  expect(restored.imports).toBe(1);
  expect(restored.revenue).toBe(2000);
  expect(restored.prospects).toContain('Synthetic backed-up prospect');
  expect(restored.report.some(line => line.includes('Synthetic BT Company') && line.includes('$2,000.00'))).toBe(true);
});

test('table import reads the full original CSV rather than the truncated inbox preview', async ({ page }) => {
  await openApp(page);
  const loaded = await page.evaluate(async () => {
    const rows = Array.from({ length: 400 }, (_, i) => ['Synthetic Company ' + i, 'Synthetic Contact ' + i, 'x'.repeat(600)].join(','));
    const text = 'Company,Contact,Notes\n' + rows.join('\n');
    SC.navigate('captureStation');
    await SC.salesImport.receiveFiles([new File([text], 'synthetic-full-original.csv', { type: 'text/csv' })]);
    const source = await SC.storage.db.files.filter(file => file.name === 'synthetic-full-original.csv').first();
    return { size: text.length, preview: source.text.length, original: (await source.blob.text()).length };
  });
  expect(loaded.size).toBeGreaterThan(200000);
  expect(loaded.preview).toBeLessThan(loaded.original);
  await expect(page.locator('.si-review')).toContainText('400 rows');
  await page.locator('#si-import-form [name="confirmed"]').check();
  await page.locator('#si-import-form [type="submit"]').click();
  await expect.poll(() => page.evaluate(() => SC.state.salesWorkflows.prospects.filter(p => p.account.startsWith('Synthetic Company ')).length)).toBe(400);
});

test('section-highlight hashing blocks restore and rejects a property switch before committing', async ({ page }) => {
  await openApp(page);
  await page.evaluate(() => { SC.state.reportDate = todayISO(); SC.navigate('home'); });
  await page.getByRole('button', { name: 'Send this section to weekly report', exact: true }).click();
  await page.locator('#sc-section-report-form [name="summary"]').fill('Synthetic manual section highlight');
  await page.locator('#sc-section-report-form [name="confirmed"]').check();
  await page.evaluate(() => {
    window.__originalSectionDigest = crypto.subtle.digest.bind(crypto.subtle);
    crypto.subtle.digest = (...args) => new Promise(resolve => {
      window.__releaseSectionDigest = () => window.__originalSectionDigest(...args).then(resolve);
    });
  });
  await page.locator('#sc-section-report-form [type="submit"]').click();
  await expect.poll(() => page.evaluate(() => SC.salesReport.isBusy())).toBe(true);
  const result = await page.evaluate(async () => {
    let restoreError = '';
    try { await SC.storage.restore('{}', 'Synthetic unused passphrase'); } catch (error) { restoreError = error.message; }
    await SC.createProperty({ name: 'Synthetic highlight second hotel', rooms: 80 });
    window.__releaseSectionDigest();
    crypto.subtle.digest = window.__originalSectionDigest;
    return { restoreError };
  });
  expect(result.restoreError).toMatch(/wait|finish|local job/i);
  await expect.poll(() => page.evaluate(() => SC.salesReport.isBusy())).toBe(false);
  expect(await page.evaluate(() => (SC.state.salesWorkflows?.reportPins || []).some(pin => pin.item.summary.includes('Synthetic manual section highlight')))).toBe(false);
});

test('an older delayed hotel switch cannot apply its snapshot over a newer hotel', async ({ page }) => {
  await openApp(page);
  const ids = await page.evaluate(async () => {
    const original = SC.propertyId;
    const b = await SC.createProperty({ name: 'Synthetic delayed hotel B', rooms: 81 });
    const c = await SC.createProperty({ name: 'Synthetic latest hotel C', rooms: 82 });
    await SC.switchProperty(original);
    window.__originalPropertyLoad = SC.storage.loadProperty.bind(SC.storage);
    SC.storage.loadProperty = async id => {
      if (id === b) await new Promise(resolve => { window.__releasePropertyB = resolve; });
      return window.__originalPropertyLoad(id);
    };
    window.__delayedPropertySwitch = SC.switchProperty(b);
    return { b, c };
  });
  await page.waitForFunction(() => typeof window.__releasePropertyB === 'function');
  const result = await page.evaluate(async ({ c }) => {
    try {
      await SC.switchProperty(c);
      window.__releasePropertyB();
      try { await window.__delayedPropertySwitch; } catch { /* an obsolete switch may explicitly cancel */ }
      SC.save(); await SC.storage.flush();
      return { active: SC.propertyId, hotel: SC.state.settings.hotel, durableHotel: (await SC.storage.db.snapshots.get(c)).state.settings.hotel };
    } finally { SC.storage.loadProperty = window.__originalPropertyLoad; }
  }, ids);
  expect(result.active).toBe(ids.c);
  expect(result.hotel).toBe('Synthetic latest hotel C');
  expect(result.durableHotel).toBe('Synthetic latest hotel C');
});
