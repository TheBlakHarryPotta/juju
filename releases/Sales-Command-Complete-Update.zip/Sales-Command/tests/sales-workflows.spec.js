import {test,expect} from '@playwright/test';
import {buildWeeklyItems,normalizeProspect,findProspectDuplicates} from '../src/sales-model.js';
const PERIOD={start:'2026-10-24',end:'2026-10-30',propertyId:'A'};
test('sales weekly model deduplicates linked actuals, derived prospects and repeated pins',()=>{
 const actual={id:'a',date:'2026-10-28',type:'tour',account:'QA',source:{salesKey:'workflow:tour:t'}};
 const result=buildWeeklyItems({...PERIOD,activities:[actual],rfps:[{id:'r',receivedDate:'2026-10-29',name:'QA RFP'}],workflows:{tours:[{id:'t',date:'2026-10-28',status:'Completed',activityId:'a',account:'QA'}],prospects:[{id:'p',identifiedDate:'2026-10-29',sourceKind:'Reviewed RFP',sourceKey:'rfp:r'}],reportPins:[{reportEnd:PERIOD.end,item:{key:'workflow:tour:t',date:'2026-10-28',summary:'Repeated manual send'}}]}});
 expect(result).toHaveLength(2);expect(new Set(result.map(x=>x.key)).size).toBe(2);
});
test('sales report excludes planned, undated, outside-period and other-property records',()=>{
 const result=buildWeeklyItems({...PERIOD,activities:[{id:'plan',date:'2026-10-28',planned:true,done:false},{id:'foreign',propertyId:'B',date:'2026-10-28'},{id:'old',date:'2026-10-01'}],rfps:[{id:'none',name:'Undated'},{id:'other',propertyId:'B',receivedDate:'2026-10-28'}],workflows:{tours:[{id:'t',status:'Planned',date:'2026-10-28'}],networking:[{id:'n',status:'Cancelled',date:'2026-10-28'}]}});expect(result).toEqual([]);
});
test('duplicate check proposes review without changing records or equating people with completed calls',()=>{
 const rows=[{id:'a',propertyId:'A',account:'QA Corp',email:'jane@example.test'},{id:'b',propertyId:'A',account:'QA Other',email:'JANE@example.test'},{id:'c',propertyId:'B',account:'QA Third',email:'jane@example.test'}];
 const before=structuredClone(rows);expect(findProspectDuplicates(rows)).toHaveLength(1);expect(rows).toEqual(before);
 expect(normalizeProspect({account:'QA',arrive:'2027-05-01',depart:'2027-05-02'}).status).toBe('New');expect(()=>normalizeProspect({account:'QA',arrive:'2027-05-03',depart:'2027-05-02'})).toThrow(/departure/i);
});
async function open(page,view='tours'){
 await page.goto('/');await page.evaluate(async()=>{await SC.ready;await SC.createProperty({name:'QA Sales Workflow Hotel',rooms:100});SC.state.reportDate=todayISO();SC.save();});await page.evaluate(view=>SC.navigate(view),view);
}
test('planned tour creates no actual work, completion/edit/manual sends stay one source',async({page})=>{
 await open(page);await page.locator('[data-sales-action="new-tour"]').click();
 await page.locator('#sales-tour-form [name="account"]').fill('QA Corporate Visit');await page.locator('#sales-tour-form [name="direction"]').selectOption('Outbound');await page.locator('#sales-tour-form [name="nextStep"]').fill('Review dates');
 await page.getByRole('button',{name:'Save tour',exact:true}).click();expect(await page.evaluate(()=>SC.state.activities.length)).toBe(0);
 await page.locator('[data-sales-action="complete-tour"]').click();await page.locator('#sales-tour-form [name="outcome"]').fill('Met planner; proposal requested');await page.getByRole('button',{name:'Save tour',exact:true}).click();
 expect(await page.evaluate(()=>SC.state.activities.length)).toBe(1);expect(await page.evaluate(()=>SC.salesWorkflows.reportItems(SC.reportRange()).length)).toBe(1);
 await page.locator('[data-sales-action="send"]').click();await page.locator('[data-sales-action="send"]').click();expect(await page.evaluate(()=>SC.state.salesWorkflows.reportPins.length)).toBe(1);
 await page.locator('[data-sales-action="edit-tour"]').click();await page.locator('#sales-tour-form [name="outcome"]').fill('Updated result: approved dates requested');await page.getByRole('button',{name:'Save tour',exact:true}).click();
 expect(await page.evaluate(()=>SC.state.activities.length)).toBe(1);await page.reload();await page.evaluate(async()=>{await SC.ready;SC.navigate('tours');});await expect(page.locator('.sales-record')).toContainText('Updated result');
});
test('networking completed work feeds the selected report exactly once',async({page})=>{
 await open(page,'networking');await page.locator('[data-sales-action="new-networking"]').click();await page.locator('#sales-network-form [name="event"]').fill('QA Chamber Introduction');await page.locator('#sales-network-form [name="account"]').fill('QA Local Business');await page.locator('#sales-network-form [name="status"]').selectOption('Completed');await page.locator('#sales-network-form [name="outcome"]').fill('Introduced to travel coordinator');await page.getByRole('button',{name:'Save networking meeting',exact:true}).click();
 expect(await page.evaluate(()=>SC.state.activities.filter(a=>a.type==='networking').length)).toBe(1);await page.evaluate(()=>SC.navigate('salesWeek'));await expect(page.locator('.sales-week-feed')).toContainText('QA Local Business');
});
test('prospect reimports skip stable source, duplicate review is nondestructive, real contact logs once',async({page})=>{
 await open(page,'prospects');const outcome=await page.evaluate(()=>{const rows=[{account:'QA Sample Company',contact:'Jo Example',email:'jo@example.test',phone:'202-555-0101',nextStep:'Verify travel needs'}];const source={id:'qa-file',propertyId:SC.propertyId,name:'Reviewed QA list'};const first=SC.salesWorkflows.importProspects(rows,{source}),again=SC.salesWorkflows.importProspects(rows,{source});SC.salesWorkflows.importProspects(rows,{source:{...source,id:'qa-other-file'}});return {added:first.added,skipped:again.skipped,actual:SC.state.activities.length};});
 expect(outcome).toEqual({added:1,skipped:1,actual:0});await page.locator('[data-sales-action="duplicates"]').click();await expect(page.getByRole('dialog')).toContainText('Same email');expect(await page.evaluate(()=>SC.state.salesWorkflows.prospects.length)).toBe(2);await page.locator('[data-sales-action="close"]').click();
 await page.locator('[data-sales-action="contact-prospect"]').first().click();await page.locator('#sales-contact-form [name="outcome"]').fill('Spoke with Jo; verified upcoming crew dates');await page.getByRole('button',{name:'Save completed contact',exact:true}).click();
 expect(await page.evaluate(()=>SC.state.activities.length)).toBe(1);expect(await page.evaluate(()=>SC.state.salesWorkflows.prospects.length)).toBe(2);await expect(page.locator('.sales-record').first()).toContainText('Contacted');
});
test('sales source property and week boundaries reject misrouted imports and manual sends',async({page})=>{
 await open(page,'prospects');const results=await page.evaluate(()=>{let propertyRejected=false,outsideRejected=false;try{SC.salesWorkflows.importProspects([{account:'Other hotel'}],{source:{id:'x',propertyId:'different-hotel'}});}catch{propertyRejected=true;}const added=SC.salesWorkflows.importProspects([{account:'Old QA Lead',date:'2025-01-01'}],{source:{id:'old'}});try{SC.salesWorkflows.pinToReport({kind:'prospect',id:added.prospects[0].id});}catch{outsideRejected=true;}return {propertyRejected,outsideRejected,pins:SC.state.salesWorkflows.reportPins.length};});expect(results).toEqual({propertyRejected:true,outsideRejected:true,pins:0});
});

test('one received RFP and its already logged source-file activity remain one report entry',()=>{const rows=buildWeeklyItems({...PERIOD,activities:[{id:'saved-rfp',type:'rfp',date:'2026-10-29',sourceId:'source-file',account:'QA'}],rfps:[{id:'inquiry',sourceId:'source-file',receivedDate:'2026-10-29',name:'QA inquiry'}]});expect(rows).toHaveLength(1);expect(rows[0].activityId).toBe('saved-rfp');});

test('edited or deleted linked activities are not resurrected by stale workflow cards and manual pins',()=>{const pin={reportEnd:PERIOD.end,item:{key:'workflow:tour:t',date:'2026-10-28',summary:'Stale tour'}};const workflows={tours:[{id:'t',activityId:'a',status:'Completed',date:'2026-10-28'}],reportPins:[pin]};expect(buildWeeklyItems({...PERIOD,activities:[{id:'a',date:'2026-11-01',source:{salesKey:'workflow:tour:t'}}],workflows})).toEqual([]);expect(buildWeeklyItems({...PERIOD,activities:[],workflows})).toEqual([]);});

test('reviewed call file and synced actual activity keep one prospect identity',async({page})=>{await open(page,'prospects');const result=await page.evaluate(()=>{const activity=SC.commitActivity({type:'prospecting',date:todayISO(),account:'QA Call Company',contact:'Jo Example',outcome:'Confirmed travel needs',sourceId:'qa-call-file'});SC.salesWorkflows.recordCall({...activity,email:'jo@example.test'},{source:{id:'qa-call-file',activityId:activity.id,propertyId:SC.propertyId}});for(let n=0;n<3;n++){SC.salesWorkflows.syncCalls(SC.state.activities);SC.render();}return {prospects:SC.state.salesWorkflows.prospects.length,activities:SC.state.activities.length,linked:SC.state.salesWorkflows.prospects[0].contactActivityId===activity.id};});expect(result).toEqual({prospects:1,activities:1,linked:true});});
