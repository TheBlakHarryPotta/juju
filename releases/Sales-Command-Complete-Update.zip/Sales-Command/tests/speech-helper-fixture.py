#!/usr/bin/env python3
"""Synthetic whisper-cli contract fixture. This does NOT recognize speech."""
import json
from pathlib import Path
import sys
import time
import wave

args = sys.argv[1:]
def option(name):
    return args[args.index(name) + 1]

mode = Path(option('-m')).read_text().strip()
source = Path(option('-f'))
with wave.open(str(source), 'rb') as audio:
    if audio.getnchannels() != 1 or audio.getsampwidth() != 2 or audio.getframerate() != 16000:
        sys.exit(22)
if source.name != 'bounded.wav':
    sys.exit(23)
if mode == 'timeout':
    time.sleep(2)
if mode == 'process-error':
    sys.exit(24)
output = Path(option('-of')).with_suffix('.json')
if mode == 'missing-output':
    sys.exit(0)
if mode == 'invalid-json':
    output.write_text('{ invalid JSON')
elif mode == 'oversized-output':
    output.write_text(' ' * (4 * 1024 * 1024 + 1))
elif mode == 'invalid-segments':
    output.write_text(json.dumps({'transcription': [{'offsets': {'from': 100, 'to': -100}, 'text': 'INVALID'}]}))
else:
    output.write_text(json.dumps({'result': {'language': 'en'}, 'transcription': [
        {'offsets': {'from': 0, 'to': 250}, 'text': ' SYNTHETIC CLI FIXTURE '},
        {'offsets': {'from': 250, 'to': 500}, 'text': 'Infrastructure test only.'},
    ]}))
