#!/usr/bin/env python3
"""Executable local-helper tests. Fixture output is not an ASR accuracy result.
Run: tools/.venv/bin/python tests/speech-helper-tests.py -v
"""
from __future__ import annotations
from contextlib import contextmanager
import http.client
import importlib.util
import io
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import tempfile
import time
import unittest
import wave

ROOT = Path(__file__).resolve().parents[1]
SERVER = ROOT / 'tools' / 'speech_server.py'
FIXTURE = Path(__file__).with_name('speech-helper-fixture.py')
ORIGIN = 'http://127.0.0.1:5173'
# Known synthetic pairing material, used only by disposable test servers.
PAIRING = 'qa-fixture-pairing-material-0123456789-abcdefghijklmnopqrstuvwxyz'
spec = importlib.util.spec_from_file_location('qa_speech_server', SERVER)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

def wav(duration=.5, rate=8000):
    stream = io.BytesIO()
    with wave.open(stream, 'wb') as output:
        output.setnchannels(1); output.setsampwidth(2); output.setframerate(rate)
        output.writeframes(b'\0\0' * int(duration * rate))
    return stream.getvalue()

class Helper:
    def __init__(self, mode='valid', missing=None, timeout=False):
        self.directory = tempfile.TemporaryDirectory(prefix='sales-command-qa-helper-')
        self.root = Path(self.directory.name)
        self.binary = self.root / 'synthetic-whisper-cli'
        self.binary.write_bytes(FIXTURE.read_bytes()); self.binary.chmod(0o700)
        self.model = self.root / 'synthetic-model.bin'; self.model.write_text(mode)
        self.token = self.root / 'pairing.txt'; self.token.write_text(PAIRING)
        if missing == 'binary': self.binary.unlink()
        if missing == 'model': self.model.unlink()
        if missing == 'empty-model': self.model.write_bytes(b'')
        with socket.socket() as listener:
            listener.bind(('127.0.0.1', 0)); self.port = listener.getsockname()[1]
        # Tests alone lower the actual subprocess deadline to exercise timeout cleanup
        # without waiting the production 180-second limit. Production code is unchanged.
        runner = self.root / 'run-helper.py'
        runner.write_text('import runpy, subprocess\n' + (
            'original_run=subprocess.run\n'
            'def bounded_run(*args, **kwargs):\n'
            '    kwargs["timeout"]=0.05\n'
            '    return original_run(*args, **kwargs)\n'
            'subprocess.run=bounded_run\n' if timeout else '') +
            'runpy.run_path(' + repr(str(SERVER)) + ',run_name="__main__")\n')
        self.process = subprocess.Popen([sys.executable, str(runner), '--model', str(self.model), '--binary', str(self.binary), '--token-file', str(self.token), '--port', str(self.port)], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        deadline = time.monotonic() + 8
        while time.monotonic() < deadline:
            if self.process.poll() is not None:
                out, err = self.process.communicate()
                raise RuntimeError('Test helper failed to start: ' + err)
            try:
                self.request('GET', '/health'); break
            except OSError: time.sleep(.03)
        else: raise RuntimeError('Test helper did not listen within eight seconds.')
    def request(self, method, path, body=None, headers=None):
        actual = {'Origin': ORIGIN, 'X-Sales-Command-Token': PAIRING}
        if method == 'POST': actual.update({'Content-Type': 'application/octet-stream', 'X-File-Name': 'fixture.wav'})
        if headers:
            for key, value in headers.items():
                if value is None: actual.pop(key, None)
                else: actual[key] = value
        connection = http.client.HTTPConnection('127.0.0.1', self.port, timeout=15)
        try:
            connection.request(method, path, body=body, headers=actual)
            response = connection.getresponse(); raw = response.read()
            return response.status, dict(response.getheaders()), json.loads(raw) if raw else None
        finally: connection.close()
    def close(self):
        self.process.terminate()
        try: self.logs = self.process.communicate(timeout=5)
        except subprocess.TimeoutExpired:
            self.process.kill(); self.logs = self.process.communicate()
        self.directory.cleanup()

@contextmanager
def helper(*args, **kwargs):
    instance = Helper(*args, **kwargs)
    try: yield instance
    finally: instance.close()

class ProtocolTests(unittest.TestCase):
    def setUp(self): self.helper = Helper()
    def tearDown(self): self.helper.close()
    def test_health_distinguishes_available_from_validated(self):
        status, headers, data = self.helper.request('GET', '/health')
        self.assertEqual(status, 200); self.assertTrue(data['ready']); self.assertFalse(data['modelValidated'])
        self.assertEqual(data['engine'], 'whisper.cpp'); self.assertTrue(data['localOnly'])
        self.assertEqual(headers['Cache-Control'], 'no-store')
    def test_wrong_or_missing_token_is_rejected(self):
        for token in ['wrong', None]:
            self.assertEqual(self.helper.request('GET', '/health', headers={'X-Sales-Command-Token': token})[0], 401)
    def test_wrong_and_missing_origin_is_rejected_without_cors_grant(self):
        for origin in ['https://example.invalid', 'http://localhost.attacker:5173', None, 'null']:
            status, headers, _ = self.helper.request('GET', '/health', headers={'Origin': origin})
            self.assertEqual(status, 403); self.assertNotIn('Access-Control-Allow-Origin', headers)
    def test_dns_rebinding_host_is_rejected(self):
        self.assertEqual(self.helper.request('GET', '/health', headers={'Host': 'attacker.invalid'})[0], 403)
    def test_preflight_requires_origin_but_not_pairing_token(self):
        status, headers, _ = self.helper.request('OPTIONS', '/transcribe', headers={'X-Sales-Command-Token': None})
        self.assertEqual(status, 204); self.assertEqual(headers['Access-Control-Allow-Origin'], ORIGIN)
    def test_unknown_endpoint_is_404(self):
        self.assertEqual(self.helper.request('GET', '/not-an-endpoint')[0], 404)
    def test_wrong_upload_content_type_is_rejected(self):
        self.assertEqual(self.helper.request('POST', '/transcribe', wav(), {'Content-Type': 'text/plain'})[0], 415)
    def test_empty_oversized_and_invalid_size_are_rejected(self):
        for declared in ['0', str(module.MAX_BYTES + 1), 'not-a-number']:
            self.assertEqual(self.helper.request('POST', '/transcribe', b'', {'Content-Length': declared})[0], 413)
    def test_malformed_audio_is_rejected_and_lock_released(self):
        self.assertEqual(self.helper.request('POST', '/transcribe', b'not a WAV recording')[0], 422)
        self.assertEqual(self.helper.request('POST', '/transcribe', wav())[0], 200)
    def test_expanded_audio_duration_is_bounded_before_inference(self):
        status, _, result = self.helper.request('POST', '/transcribe', wav(901))
        self.assertEqual(status, 422); self.assertIn('15 minutes', result['error'])
    def test_actual_cli_subprocess_contract_and_cleanup(self):
        status, _, result = self.helper.request('POST', '/transcribe', wav(), {'X-File-Name': '../../escape.wav'})
        self.assertEqual(status, 200); self.assertEqual(result['duration'], .5)
        self.assertEqual(result['text'], 'SYNTHETIC CLI FIXTURE\nInfrastructure test only.')
        self.assertEqual(result['segments'][1], {'start': .25, 'end': .5, 'text': 'Infrastructure test only.'})
        self.assertTrue(result['reviewRequired']); self.assertEqual(result['engine'], 'whisper.cpp')
        self.assertTrue(self.helper.request('GET', '/health')[2]['modelValidated'])
        self.assertFalse((self.helper.root / 'escape.wav').exists())
        self.assertEqual(list(self.helper.root.glob('transcript*')), [])

class FailureTests(unittest.TestCase):
    def test_missing_binary_model_or_empty_model_is_not_ready(self):
        for missing in ['binary', 'model', 'empty-model']:
            with self.subTest(missing=missing), helper(missing=missing) as service:
                data = service.request('GET', '/health')[2]
                self.assertFalse(data['ready']); self.assertFalse(data['modelValidated'])
                self.assertEqual(service.request('POST', '/transcribe', wav())[0], 503)
    def test_process_error_invalid_json_missing_oversized_or_invalid_output_are_rejected(self):
        for mode in ['process-error', 'invalid-json', 'missing-output', 'oversized-output', 'invalid-segments']:
            with self.subTest(mode=mode), helper(mode) as service:
                self.assertEqual(service.request('POST', '/transcribe', wav())[0], 422)
                self.assertFalse(service.request('GET', '/health')[2]['modelValidated'])
    def test_actual_subprocess_timeout_returns_actionable_error(self):
        with helper('timeout', timeout=True) as service:
            status, _, result = service.request('POST', '/transcribe', wav())
            self.assertEqual(status, 422); self.assertIn('three minutes', result['error'])
            self.assertFalse(service.request('GET', '/health')[2]['modelValidated'])

class ParserTests(unittest.TestCase):
    def test_millisecond_offsets_take_precedence_over_timestamp_text(self):
        value = {'transcription': [{'offsets': {'from': 125, 'to': 1350}, 'timestamps': {'from': 'broken', 'to': 'broken'}, 'text': ' Reviewed fact '}]}
        self.assertEqual(module.parse_transcription(value, 2), [{'start': .12, 'end': 1.35, 'text': 'Reviewed fact'}])
    def test_hh_mm_ss_comma_and_dot_timestamp_fallback(self):
        value = {'transcription': [{'timestamps': {'from': '00:01:02,500', 'to': '00:01:03.250'}, 'text': 'Fallback'}]}
        self.assertEqual(module.parse_transcription(value, 65), [{'start': 62.5, 'end': 63.25, 'text': 'Fallback'}])
    def test_invalid_segment_times_and_payloads_are_rejected(self):
        for start, end in [(-1, 50), (500, 100), (0, 90000), (float('nan'), 100), (0, float('inf'))]:
            with self.subTest(start=start, end=end), self.assertRaises(ValueError):
                module.parse_transcription({'transcription': [{'offsets': {'from': start, 'to': end}, 'text': 'Unsafe'}]}, 1)
        for value in [{}, {'transcription': 'bad'}, {'transcription': [{}]}]:
            with self.subTest(value=value), self.assertRaises((ValueError, TypeError)):
                module.parse_transcription(value, 1)
    def test_empty_segments_are_not_invented_as_speech(self):
        self.assertEqual(module.parse_transcription({'transcription': []}, 1), [])
        self.assertEqual(module.parse_transcription({'transcription': [{'offsets': {'from': 0, 'to': 100}, 'text': '  '}]}, 1), [])

if __name__ == '__main__': unittest.main()
