import {test,expect} from '@playwright/test';
async function open(page){await page.goto('/');await page.waitForFunction(()=>window.SC?.ready);await page.evaluate(async()=>{await SC.ready;await SC.createProperty({name:'Synthetic Atomic QA Hotel',rooms:100});clearTimeout(xSaveT);await SC.storage.flush()});}
async function create(page){return page.evaluate(async()=>SC.transactions.commit({propertyId:SC.propertyId,label:'Synthetic linked review',source:{kind:'qa-linked'},changes:d=>{
 d.plannedTasks??=[];d.plannedTasks.push({id:'qa-owned-task',propertyId:SC.propertyId,account:'Synthetic Atomic Company',due:'2027-06-01',notes:'Planned only',done:false});
 d.bookings.push({id:'qa-owned-booking',propertyId:SC.propertyId,name:'Synthetic Atomic Group',account:'Synthetic Atomic Company',status:'Prospect',statusDate:todayISO(),created:todayISO(),arrival:'2027-06',arrive:'2027-06-04',depart:'2027-06-05',rn:5,adr:149,rev:745,revManual:false});
}}));}

test('one durable revision saves linked records and undo preserves unrelated later work by ID',async({page})=>{
 await open(page);const before=await page.evaluate(async()=>({revision:(await SC.storage.db.snapshots.get(SC.propertyId)).revision,activities:SC.state.activities.length}));
 const receipt=await create(page);
 const saved=await page.evaluate(async()=>{const r=await SC.storage.db.snapshots.get(SC.propertyId);return{revision:r.revision,state:r.state}});
 expect(saved.revision).toBe(before.revision+1);expect(saved.state.innovationReceipts.find(r=>r.id===receipt.id).status).toBe('applied');expect(saved.state.plannedTasks.map(t=>t.id)).toContain('qa-owned-task');expect(saved.state.bookings.map(b=>b.id)).toContain('qa-owned-booking');expect(saved.state.activities).toHaveLength(before.activities);
 await page.evaluate(async()=>{SC.state.plannedTasks.unshift({id:'qa-unrelated-task',propertyId:SC.propertyId,account:'Synthetic Other Company',due:'2027-07-01',notes:'Later unrelated plan',done:false});SC.save();await SC.storage.flush()});
 await page.evaluate(id=>SC.transactions.undo(id),receipt.id);
 const result=await page.evaluate(async()=>({state:SC.state,durable:(await SC.storage.db.snapshots.get(SC.propertyId)).state,inert:document.body.inert,busy:SC.transactions.isBusy()}));
 for(const state of[result.state,result.durable]){expect(state.plannedTasks.map(t=>t.id)).toEqual(['qa-unrelated-task']);expect(state.bookings).toHaveLength(0);expect(state.innovationReceipts.find(r=>r.id===receipt.id).status).toBe('undone');}
 expect(result.inert).toBe(false);expect(result.busy).toBe(false);
});

test('a failed database write publishes no partial linked records or receipt and releases the lock',async({page})=>{
 await open(page);const result=await page.evaluate(async()=>{
  const before=JSON.stringify(SC.state),row=await SC.storage.db.snapshots.get(SC.propertyId),put=SC.storage.db.snapshots.put;
  let error='';SC.storage.db.snapshots.put=async()=>{throw Error('Synthetic database failure')};
  try{await SC.transactions.commit({label:'Must not publish',changes:d=>{d.plannedTasks??=[];d.plannedTasks.push({id:'qa-failed-task',account:'Never saved'});d.bookings.push({id:'qa-failed-booking',name:'Never saved'})}})}catch(e){error=e.message}finally{SC.storage.db.snapshots.put=put}
  return{error,liveUnchanged:JSON.stringify(SC.state)===before,durableUnchanged:JSON.stringify((await SC.storage.db.snapshots.get(SC.propertyId)))===JSON.stringify(row),busy:SC.transactions.isBusy(),inert:document.body.inert};
 });
 expect(result).toMatchObject({error:'Synthetic database failure',liveUnchanged:true,durableUnchanged:true,busy:false,inert:false});
 const receipt=await create(page);expect(receipt.status).toBe('applied');
});

test('undo rejects the whole receipt when one owned record was edited later',async({page})=>{
 await open(page);const receipt=await create(page);
 const result=await page.evaluate(async id=>{SC.state.bookings.find(b=>b.id==='qa-owned-booking').notes='A later manually approved edit';SC.save();await SC.storage.flush();const before=JSON.stringify(SC.state);let error='';try{await SC.transactions.undo(id)}catch(e){error=e.message}return{error,unchanged:JSON.stringify(SC.state)===before,durable:(await SC.storage.db.snapshots.get(SC.propertyId)).state};},receipt.id);
 expect(result.error).toMatch(/changed|later work/i);expect(result.unchanged).toBe(true);expect(result.durable.plannedTasks.map(t=>t.id)).toContain('qa-owned-task');expect(result.durable.bookings.find(b=>b.id==='qa-owned-booking').notes).toBe('A later manually approved edit');expect(result.durable.innovationReceipts.find(r=>r.id===receipt.id).status).toBe('applied');
});

test('new history referencing a package record blocks undo instead of orphaning that history',async({page})=>{
 await open(page);const receipt=await create(page);
 const result=await page.evaluate(async id=>{SC.state.repeatBusiness={memories:[{id:'qa-later-memory',account:'Synthetic Atomic Company',source:{kind:'booking',id:'qa-owned-booking'}}],reminders:[]};SC.save();await SC.storage.flush();const before=JSON.stringify(SC.state);let error='';try{await SC.transactions.undo(id)}catch(e){error=e.message}return{error,unchanged:JSON.stringify(SC.state)===before,memories:SC.state.repeatBusiness.memories};},receipt.id);
 expect(result.error).toMatch(/refers|history/i);expect(result.unchanged).toBe(true);expect(result.memories[0].source.id).toBe('qa-owned-booking');
});

test('stale reviews, foreign hotels and forbidden settings changes are rejected before publication',async({page})=>{
 await open(page);const result=await page.evaluate(async()=>{
  const stale=JSON.stringify(SC.state);SC.state.plannedTasks??=[];SC.state.plannedTasks.push({id:'qa-newer-work',account:'Synthetic Newer Work'});SC.save();SC.prepareAtomic();await SC.storage.flush();const before=JSON.stringify(SC.state),durableBefore=await SC.storage.db.snapshots.get(SC.propertyId),errors=[];
  for(const args of[{expectedStateJSON:stale,changes:d=>d.bookings.push({id:'bad-stale'})},{propertyId:'foreign-hotel',changes:d=>d.bookings.push({id:'bad-hotel'})},{changes:d=>{d.settings.hotel='Forbidden overwrite'}}]){try{await SC.transactions.commit(args);errors.push('ACCEPTED')}catch(e){errors.push(e.message)}}
  return{errors,unchanged:JSON.stringify(SC.state)===before,durableUnchanged:JSON.stringify(await SC.storage.db.snapshots.get(SC.propertyId))===JSON.stringify(durableBefore),baselineDifferences:Object.keys(SC.state).filter(k=>JSON.stringify(SC.state[k])!==JSON.stringify(durableBefore.state[k]))};
 });
 expect(result.errors).toHaveLength(3);expect(result.errors.every(e=>e!=='ACCEPTED')).toBe(true);expect(result.unchanged).toBe(true);expect(result.durableUnchanged).toBe(true);
});

test('encrypted backup and reload retain receipts with working guarded undo',async({page})=>{
 await open(page);const receipt=await create(page);
 await page.evaluate(async()=>{window.__qaReceiptBackup=await(await SC.storage.backup('synthetic-qa-passphrase')).text();SC.state.bookings[0].notes='Temporary edit after backup';SC.save();await SC.storage.flush();await SC.storage.restore(window.__qaReceiptBackup,'synthetic-qa-passphrase')});
 await page.reload();await page.waitForFunction(()=>window.SC?.ready);await page.evaluate(async()=>{await SC.ready});
 expect(await page.evaluate(id=>SC.transactions.list().find(r=>r.id===id)?.status,receipt.id)).toBe('applied');
 await page.evaluate(id=>SC.transactions.undo(id),receipt.id);
 const result=await page.evaluate(async()=>({bookings:SC.state.bookings,tasks:SC.state.plannedTasks,durable:(await SC.storage.db.snapshots.get(SC.propertyId)).state}));
 expect(result.bookings).toHaveLength(0);expect(result.tasks).toHaveLength(0);expect(result.durable.innovationReceipts.find(r=>r.id===receipt.id).status).toBe('undone');
});

test('linked updates cannot sign a draft, edit a signed contract or use a foreign-property source',async({page})=>{
 await open(page);const result=await page.evaluate(async()=>{
  const c=SC.contracts.makeDraft('group');SC.state.contracts.push(c);SC.save();await SC.storage.flush();let errors=[];
  for(const changes of[d=>{d.contracts[0].data.signed=true},d=>{d.contracts[0].status='Signed'}]){try{await SC.transactions.commit({changes});errors.push('ACCEPTED')}catch(e){errors.push(e.message)}}
  SC.state.contracts[0].status='Signed';SC.state.contracts[0].data.signed=true;SC.save();await SC.storage.flush();const before=JSON.stringify(SC.state);
  for(const args of[{changes:d=>{d.contracts[0].data.org='Forbidden later change';d.plannedTasks??=[];d.plannedTasks.push({id:'qa-forbidden-plan'})}},{source:{propertyId:'foreign-hotel'},changes:d=>d.bookings.push({id:'qa-foreign-source'})}]){try{await SC.transactions.commit(args);errors.push('ACCEPTED')}catch(e){errors.push(e.message)}}
  return{errors,unchanged:JSON.stringify(SC.state)===before,receipts:SC.transactions.list().length};
 });
 expect(result.errors).toHaveLength(4);expect(result.errors.every(e=>e!=='ACCEPTED')).toBe(true);expect(result.unchanged).toBe(true);expect(result.receipts).toBe(0);
});

test('a delayed hotel load cannot erase a linked update committed while that hotel was opening',async({page})=>{
 await open(page);const result=await page.evaluate(async()=>{
  const first=SC.propertyId,second=await SC.createProperty({name:'Synthetic Delayed Atomic Hotel',rooms:80});await SC.switchProperty(first);clearTimeout(xSaveT);await SC.storage.flush();
  const original=SC.storage.loadProperty;let release,ready;const captured=new Promise(r=>ready=r);
  SC.storage.loadProperty=async id=>{const old=await original.call(SC.storage,id);if(id===second){ready();await new Promise(r=>release=r)}return old};
  let receipt=null,error='',afterLoad,afterLaterSave;
  try{
   const switching=SC.switchProperty(second);await captured;
   try{receipt=await SC.transactions.commit({propertyId:second,label:'Reviewed while hotel opens',changes:d=>{d.plannedTasks??=[];d.plannedTasks.push({id:'qa-race-linked',propertyId:second,account:'Synthetic Race Review',due:'2027-06-01',done:false})}})}catch(e){error=e.message}
   release();await switching;afterLoad={live:(SC.state.plannedTasks||[]).some(t=>t.id==='qa-race-linked'),durable:((await SC.storage.db.snapshots.get(second)).state.plannedTasks||[]).some(t=>t.id==='qa-race-linked')};
   SC.state.settings.preparedBy='Synthetic later unrelated edit';SC.save();await SC.storage.flush();afterLaterSave=((await SC.storage.db.snapshots.get(second)).state.plannedTasks||[]).some(t=>t.id==='qa-race-linked');
  }finally{release?.();SC.storage.loadProperty=original}
  return{committed:!!receipt,error,afterLoad,afterLaterSave};
 });
 if(result.committed){expect(result.afterLoad).toEqual({live:true,durable:true});expect(result.afterLaterSave).toBe(true)}else{expect(result.error).toMatch(/hotel|loading|switch|changed|saving/i);expect(result.afterLoad).toEqual({live:false,durable:false});expect(result.afterLaterSave).toBe(false)}
});
