import { test, expect } from '@playwright/test';

import PizZip from 'pizzip';
import fs from 'node:fs/promises';
async function open(page, id) {
  await page.goto('/');
  await page.waitForFunction(() => window.SC?.ready);
  await page.evaluate(async id => { await SC.ready; SC.navigate(id); }, id);
}

test('SRP records preserve leading zeros and support edit, verification, search and deletion', async ({ page }) => {
  await open(page, 'srpVault');
  await page.locator('#ws-srp-form [name="code"]').fill('00123');
  await page.locator('#ws-srp-form [name="account"]').fill('QA Youth Hockey');
  await page.locator('#ws-srp-form [name="notes"]').fill('Approved two-night minimum');
  await page.locator('#ws-srp-form [name="source"]').fill('QA approved agreement');
  await page.getByRole('button', { name: 'Save code', exact: true }).click();
  await expect(page.locator('#ws-srp-list code')).toHaveText('00123');
  await page.locator('[data-ws-act="edit-srp"]').click();
  await expect(page.locator('#ws-srp-form [name="code"]')).toHaveValue('00123');
  await page.locator('#ws-srp-form [name="notes"]').fill('Updated approved instructions');
  await page.getByRole('button', { name: 'Save code', exact: true }).click();
  await page.locator('[data-ws-act="verify-srp"]').click();
  await expect(page.locator('#ws-srp-list')).toContainText('Verified');
  await page.locator('#ws-srp-search').fill('no-match-company');
  await expect(page.locator('#ws-srp-list')).toContainText('No matching codes');
  await page.locator('#ws-srp-search').fill('00123');
  await expect(page.locator('#ws-srp-list')).toContainText('Updated approved instructions');
  await page.locator('[data-ws-act="delete-record"]').click();
  await page.locator('[data-ws-act="confirm-delete"]').click();
  await expect(page.locator('#ws-srp-list code')).toHaveCount(0);
});

test('saved templates merge to a real DOCX and preserve earlier revisions', async ({ page }) => {
  await open(page, 'templateLibrary');
  await page.locator('#ws-template-form [name="name"]').fill('QA approved group contract');
  await page.locator('#ws-template-form [name="body"]').fill('Dear {{contact}}, your group at {{hotel}} uses code {{code}}.');
  await page.getByRole('button', { name: 'Save template', exact: true }).click();
  await page.locator('[data-ws-act="edit-template"]').click();
  await page.locator('#ws-template-form [name="body"]').fill('Dear {{contact}}, confirmed at {{hotel}}. Booking code {{code}}.');
  await page.getByRole('button', { name: 'Save template', exact: true }).click();
  await expect(page.locator('#view')).toContainText('version 2');
  await page.locator('[data-ws-act="preview-template"]').click();
  for (const [key, value] of Object.entries({ contact: 'Jo Smith', hotel: 'QA Hotel', code: '00123' })) await page.locator(`#ws-merge-form [name="merge:${key}"]`).fill(value);
  const downloadPromise = page.waitForEvent('download');
  await page.getByRole('button', { name: 'Export merged DOCX', exact: true }).click();
  const download = await downloadPromise;
  expect(download.suggestedFilename()).toMatch(/\.docx$/i);
  const zip = new PizZip(await fs.readFile(await download.path()));
  const xml = zip.file('word/document.xml').asText();
  expect(xml).toContain('Jo Smith'); expect(xml).toContain('QA Hotel'); expect(xml).toContain('00123'); expect(xml).not.toContain('{{contact}}');
  const history = await page.evaluate(async () => (await SC.storage.db.records.where('propertyId').equals(SC.propertyId).toArray()).filter(r => r.type === 'template'));
  expect(history[0].data.version).toBe(2);
  expect(JSON.stringify(history[0])).toContain('your group at');
});

test('production import aggregates duplicate account rows and blocks duplicate period upload', async ({ page }) => {
  await open(page, 'accountRadar');
  async function upload() {
    await page.locator('#ws-production-file-form input[type="file"]').setInputFiles({ name: 'production.csv', mimeType: 'text/csv', buffer: Buffer.from('Company,RN,Revenue\nQA ACME,10,1490\n qa acme ,5,745\nQA Other,0,0') });
    await page.getByRole('button', { name: 'Read CSV & map columns', exact: true }).click();
    await page.locator('#ws-production-form [name="periodStart"]').fill('2026-10-01');
    await page.locator('#ws-production-form [name="periodEnd"]').fill('2026-10-28');
    await page.locator('#ws-production-form [name="revCol"]').selectOption('2');
    await page.locator('#ws-production-form [name="complete"]').check();
    await page.getByRole('button', { name: 'Save reviewed production', exact: true }).click();
  }
  await upload();
  await expect(page.locator('#view')).toContainText('15');
  const first = await page.evaluate(async () => SC.storage.db.production.toArray());
  expect(first).toHaveLength(1); expect(first[0].rows).toHaveLength(2);
  expect(first[0].rows.find(r => r.account.trim() === 'QA ACME')).toMatchObject({ rn: 15, rev: 2235 });
  await upload();
  await expect(page.locator('#toast')).toContainText(/already|duplicate/i);
  expect(await page.evaluate(async () => SC.storage.db.production.count())).toBe(1);
});

test('signature appearance can be placed, resized, removed and saved as a draft', async ({ page }) => {
  await open(page, 'signatureStudio');
  await page.locator('#ws-signature-form [name="name"]').fill('QA Sales Manager');
  await page.getByRole('button', { name: 'Update document & name', exact: true }).click();
  await page.locator('[data-ws-act="add-typed-signature"]').click();
  await expect(page.locator('.ws-mark')).toHaveCount(1);
  await expect(page.locator('.ws-mark')).toContainText('QA Sales Manager');
  const before = await page.locator('.ws-mark').boundingBox();
  const handle = page.locator('.ws-resize'); await handle.scrollIntoViewIfNeeded(); const box = await handle.boundingBox();
  await page.mouse.move(box.x + 6, box.y + 6); await page.mouse.down(); await page.mouse.move(box.x + 45, box.y + 20); await page.mouse.up();
  const after = await page.locator('.ws-mark').boundingBox(); expect(after.width).toBeGreaterThan(before.width);
  await page.locator('[data-ws-act="save-studio"]').click();
  expect(await page.evaluate(async () => (await SC.storage.db.records.toArray()).some(r => r.type === 'signatureDraft'))).toBe(true);
  await page.getByRole('button', { name: 'Remove this signature', exact: true }).click();
  await expect(page.locator('.ws-mark')).toHaveCount(0);
});

test('workspace modes navigate and presentation has a visible exit', async ({ page }) => {
  await open(page, 'home');
  await expect(page.locator('#scToday')).toBeVisible();
  for (const [mode, view] of [['revenue', 'revmeet'], ['documents', 'templateLibrary'], ['presentation', 'gm']]) {
    await page.locator(`[data-sc-mode="${mode}"]`).click();
    await expect(page.locator('html')).toHaveAttribute('data-sc-mode', mode);
    expect(await page.evaluate(() => SC.currentView)).toBe(view);
  }
  await page.getByRole('button', { name: 'Exit presentation', exact: true }).click();
  await expect(page.locator('html')).toHaveAttribute('data-sc-mode', 'daily');
  expect(await page.evaluate(() => SC.currentView)).toBe('home');
});

test('workspace dialog supports keyboard focus containment and Escape', async ({ page }) => {
  await open(page, 'home');
  await page.evaluate(() => SC.modal('<h3>QA keyboard dialog</h3><input id="qa-dialog-first"><button data-act="xClose">Close</button>'));
  const dialog = page.getByRole('dialog'); await expect(dialog).toBeVisible();
  await page.locator('#qa-dialog-first').focus(); await page.keyboard.press('Shift+Tab');
  expect(await page.evaluate(() => !!document.activeElement.closest('[role="dialog"]'))).toBe(true);
  await page.keyboard.press('Escape'); await expect(dialog).toHaveCount(0);
});

test('Account Radar plans preserve evidence and count as activity only after explicit completion', async ({ page }) => {
  await open(page, 'accountRadar');
  const before = await page.evaluate(() => state.activities.length);
  await page.locator('#ws-production-file-form input[type="file"]').setInputFiles({ name: 'followup-source.csv', mimeType: 'text/csv', buffer: Buffer.from('Company,RN,Revenue\nQA Followup Company,25,3725') });
  await page.getByRole('button', { name: 'Read CSV & map columns', exact: true }).click();
  await page.locator('#ws-production-form [name="periodStart"]').fill('2026-10-01');
  await page.locator('#ws-production-form [name="periodEnd"]').fill('2026-10-28');
  await page.locator('#ws-production-form [name="revCol"]').selectOption('2');
  await page.locator('#ws-production-form [name="complete"]').check();
  await page.getByRole('button', { name: 'Save reviewed production', exact: true }).click();
  await page.locator('[data-ws-act="plan-followup"]').click();
  await expect(page.locator('#ws-followup-form')).toBeVisible();
  await page.locator('#ws-followup-form [name="contact"]').fill('Jo Smith');
  await page.locator('#ws-followup-form [name="outreach"]').fill('Jo, may we review your upcoming hotel needs?');
  await page.locator('#ws-followup-form [name="reviewed"]').check();
  await page.getByRole('button', { name: 'Save follow-up plan', exact: true }).click();
  await expect(page.locator('#ws-followup-form')).toHaveCount(0);
  const plan = await page.evaluate(() => ({ tasks: state.plannedTasks, count: state.activities.length }));
  expect(plan.count).toBe(before); expect(plan.tasks).toHaveLength(1); expect(plan.tasks[0].source).toBeTruthy();
  await page.locator('[data-ws-act="complete-planned-followup"]').click();
  await page.locator('#ws-complete-followup-form [name="outcome"]').fill('Spoke with Jo; proposal requested');
  await page.locator('#ws-complete-followup-form [name="notes"]').fill('Send approved rates tomorrow.');
  await page.getByRole('button', { name: 'Save completed activity', exact: true }).click();
  await expect(page.locator('#ws-complete-followup-form')).toHaveCount(0);
  const result = await page.evaluate(id => {
    let duplicateRejected = false;
    try { SC.completePlannedTask(id, { date: todayISO(), outcome: 'Duplicate attempt' }); } catch { duplicateRejected = true; }
    return { count: state.activities.length, activity: state.activities.at(-1), duplicateRejected };
  }, plan.tasks[0].id);
  expect(result.count).toBe(before + 1); expect(result.activity.outcome).toBe('Spoke with Jo; proposal requested'); expect(result.duplicateRejected).toBe(true);
});
