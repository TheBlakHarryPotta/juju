import {mkdir,copyFile,readdir,cp} from 'node:fs/promises';
const out='public/ocr';
await mkdir(out,{recursive:true});
await copyFile('node_modules/tesseract.js/dist/worker.min.js',`${out}/worker.min.js`);
for(const name of await readdir('node_modules/tesseract.js-core')) {
 if(name.endsWith('.wasm')||name.endsWith('.wasm.js'))await copyFile(`node_modules/tesseract.js-core/${name}`,`${out}/${name}`);
}
await copyFile('node_modules/@tesseract.js-data/eng/4.0.0_best_int/eng.traineddata.gz',`${out}/eng.traineddata.gz`);
console.log('Local OCR worker, WASM and English language data ready.');

for(const dir of ['cmaps','standard_fonts','wasm']) await cp('node_modules/pdfjs-dist/'+dir,'public/pdfjs/'+dir,{recursive:true});
