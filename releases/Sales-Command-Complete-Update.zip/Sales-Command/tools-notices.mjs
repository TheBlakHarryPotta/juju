import {readFile,readdir,mkdir,copyFile,writeFile} from 'node:fs/promises';
const lock=JSON.parse(await readFile('package-lock.json','utf8'));
const inventory=[];
await mkdir('docs/licenses',{recursive:true});
for(const path of Object.keys(lock.packages).filter(p=>p.startsWith('node_modules/'))){
 try {
 const pkg=JSON.parse(await readFile(path+'/package.json','utf8'));
 const dir=(pkg.name+'-'+pkg.version).replace(/[^a-zA-Z0-9.-]/g,'_');
 const names=(await readdir(path)).filter(n=>/^(license|licence|copying|notice|ofl)(\.|$)/i.test(n));
 if(names.length)await mkdir('docs/licenses/'+dir,{recursive:true});
 for(const name of names)await copyFile(path+'/'+name,'docs/licenses/'+dir+'/'+name).catch(()=>{});
 inventory.push({name:pkg.name,version:pkg.version,license:pkg.license,notices:names});
 }catch{}
}
await writeFile('docs/licenses/inventory.json',JSON.stringify(inventory,null,2)+'\n');
console.log('Saved installed dependency notices:',inventory.length);
