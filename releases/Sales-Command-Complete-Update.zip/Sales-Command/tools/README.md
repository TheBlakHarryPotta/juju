# Local whisper.cpp transcription

This optional helper transcribes on your computer with the native [official whisper.cpp](https://github.com/ggml-org/whisper.cpp) engine. Voice memos, files and transcripts remain local. No hosted speech API is used, and the helper never downloads a model while serving a request. Recording, uploaded audio and editable manual transcripts work without a speech model.

## Apple Silicon Mac setup

Required: an M1/M2/M3/M4 or later Apple Silicon Mac, **Python 3.12+**, Git and Apple Command Line Tools. The pinned PyAV and NumPy releases require Python 3.12 or newer. If Command Line Tools are missing, run `xcode-select --install` yourself and complete Apple's installer. This setup does not install Homebrew or system software silently.

From the repository root in Terminal:

```sh
bash tools/setup-speech.sh
# Separate, explicit first-time download of the official tiny.en model.
tools/.venv/bin/python tools/download-speech-model.py
# Restart this local process whenever you want transcription.
tools/.venv/bin/python tools/speech_server.py
```

The installer builds whisper.cpp with **Metal ON and Accelerate ON on Apple Silicon**. Linux uses the same pinned source with Metal OFF, Accelerate OFF and CPU inference. Intel macOS gets Metal OFF. Default build parallelism is three jobs; override with `SC_BUILD_JOBS=1` through `8`. An existing system CMake is reused; otherwise the installer installs pinned `cmake==4.4.4` into the dedicated local Python environment. Runtime Python dependencies are only `av==19.0.2` and `numpy==2.5.4`. PyAV decodes audio; inference runs in the native executable, without PyTorch, faster-whisper, CTranslate2 or a Python model stack.

The exact official source pin is tag **v1.9.5**, commit **d1be6fde11ac6e0407606b4e42fe72d34add8037**. The compiled upstream CLI reports `1.9.5-dev`; the exact source commit is verified rather than assuming its printed version identifies the checkout. Existing source modifications or a different source pin cause setup to stop without overwriting that checkout. Source and build output live under ignored `tools/.whisper.cpp/`.

## Pair with Call Desk

The helper binds only to `127.0.0.1:8766`, accepts explicit local app Origins and requires a private pairing token. Open `tools/.speech-token` privately on your own machine and paste its contents into Call Desk's pairing-token field. Do not commit or share the token. The app holds it only in memory. Choose **Check local helper**, then open a recording review and choose **Transcribe locally**. Verify names, room counts, dates, rates and the recording's ending before approving sales records. A transcript is not verified source data.

Default permitted Origins are the local Vite development and preview servers on ports 5173 and 4173 for `localhost` and `127.0.0.1`. For another **local** port, pass `--origin http://localhost:PORT`. Do not expose the helper to the network or authorize arbitrary websites. Hosted HTTPS installations need a separately reviewed desktop packaging/integration approach; do not open local service access broadly. A helper running on a Mac does not provide phone-only local transcription on another device.

To rotate your token, stop the helper, delete only `tools/.speech-token`, then restart the helper. Keep that file private. Never serve the repository folder with a generic file server; the app's static launcher serves only the built `dist` directory.

## Model installation and verification

Default model path: `tools/.models/ggml-tiny.en.bin`. The explicit downloader uses the official URL declared in whisper.cpp's pinned source:

`https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-tiny.en.bin`

It verifies the expected SHA-1 **c78c86eb1a8faa21b369bcd33207cc90d64ae9df**, published in the official pinned [models/README.md](https://github.com/ggml-org/whisper.cpp/blob/d1be6fde11ac6e0407606b4e42fe72d34add8037/models/README.md), before making the model available. It also records the downloaded file's SHA-256 locally; that receipt is a measured digest, not an invented official SHA-256. The official README lists the English tiny model at roughly 75 MiB. Existing valid models are reused without network access. Mismatching existing files are preserved and rejected. Bad or incomplete downloads are discarded. TLS verification stays enabled.

To verify an already-installed official model without any network access:

```sh
tools/.venv/bin/python tools/download-speech-model.py --verify-only
```

A restricted environment must authorize `huggingface.co` and its actual model-artifact redirect destination. A proxy tunnel 403 is an access blocker, not an authentication prompt. Do not disable certificate checking, use an unofficial model mirror, or alter expected checksums. You can copy the verified official file into the default model path, or use `--model /path/to/ggml-tiny.en.bin`. The server reports not ready and rejects transcription when the executable or model is missing. This repository does not embed a model, and a native CLI build alone does not prove recognition quality.

## Limits and practical use

One transcription runs at a time. Requests allow up to 25 MB and 15 minutes of audio, with bounded incremental decode and a native-process timeout. The browser voice-memo recorder stops at ten minutes or its recording-size cap. CPU decoding uses at most four inference threads; Apple Silicon builds can use Metal through the native engine. Long/noisy calls may take time, names and numbers may be wrong, and speech can be omitted or hallucinated. Check the final sentence, not just the beginning. The English tiny model is the small starting point; higher-accuracy model evaluation is separate.

MediaRecorder captures only the granted microphone. It does not automatically capture phone, Teams or other application calls. Obtain the required permission. Temporary audio, native JSON output and transcripts from helper requests are removed after the request; approved browser records remain until you delete them. Server logs do not include tokens, request bodies or transcripts. Installed dependencies and models remain on disk; the helper process must restart after machine restart.

## Linux validation and Mac limitation

The pinned source was compiled successfully on Linux x86_64 using GNU 14.2, CMake 4.4.4 and three build jobs. The complete saved setup script was rerun successfully, reused valid outputs, and the resulting `whisper-cli --help` and `--version` completed. CLI JSON support was checked against the compiled help and pinned writer source: `-oj -of PATH` writes `PATH.json`, with `transcription[]` entries carrying `text`, `timestamps` and millisecond `offsets`.

The official model download was attempted in the cloud environment and denied by the proxy with tunnel 403. Checked official GitHub release assets did not provide the real tiny.en weights. No genuine model inference was run and no recognition accuracy or speed is claimed. Apple Silicon build flags are provided but were **not executed or benchmarked on a Mac** in this environment. The current cloud instance's Python environment may still retain dependencies from earlier experiments; a fresh install uses only the lightweight dependencies listed above.

## Windows

The current native installer supports macOS and Linux. Earlier faster-whisper PowerShell instructions no longer apply. A Windows native build/package requires separate toolchain validation; do not install the obsolete Python inference stack from an old handoff.
