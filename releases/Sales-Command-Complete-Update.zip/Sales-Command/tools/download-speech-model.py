#!/usr/bin/env python3
"""Explicit, checksum-verified official whisper.cpp tiny.en download. No runtime fetching."""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import tempfile
import urllib.error
import urllib.parse
import urllib.request

# Authoritative expected digest from models/README.md at our exact source release:
# https://github.com/ggml-org/whisper.cpp/blob/d1be6fde11ac6e0407606b4e42fe72d34add8037/models/README.md
EXPECTED_SHA1 = 'c78c86eb1a8faa21b369bcd33207cc90d64ae9df'
OFFICIAL_URL = 'https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-tiny.en.bin'
MAX_BYTES = 90 * 1024 * 1024

def digests(path):
    sha1, sha256 = hashlib.sha1(), hashlib.sha256()
    with path.open('rb') as file:
        for block in iter(lambda: file.read(1024 * 1024), b''):
            sha1.update(block); sha256.update(block)
    return sha1.hexdigest(), sha256.hexdigest()

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=Path(__file__).parent / '.models' / 'ggml-tiny.en.bin')
    parser.add_argument('--verify-only', action='store_true', help='Verify an existing local file without network access.')
    args = parser.parse_args()
    path = args.output.resolve()
    if path.exists():
        sha1, sha256 = digests(path)
        if sha1 != EXPECTED_SHA1:
            raise SystemExit('Existing model checksum does not match the pinned official tiny.en model. It was not overwritten. Preserve or remove it before retrying.')
        print('Official tiny.en model verified locally. SHA-1:', sha1, 'SHA-256:', sha256)
        return
    if args.verify_only:
        raise SystemExit('Local model is missing. No network request was made.')
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary = tempfile.mkstemp(prefix='.tiny-en-download-', dir=path.parent)
    try:
        size = 0
        request = urllib.request.Request(OFFICIAL_URL, headers={'User-Agent': 'SalesCommand-local-model-installer/1'})
        # urllib preserves the environment proxy and default TLS certificate verification.
        with urllib.request.urlopen(request, timeout=30) as response, os.fdopen(descriptor, 'wb') as file:
            descriptor = None
            while True:
                block = response.read(1024 * 1024)
                if not block: break
                size += len(block)
                if size > MAX_BYTES: raise ValueError('Model exceeds its allowed download size.')
                file.write(block)
        downloaded = Path(temporary)
        sha1, sha256 = digests(downloaded)
        if sha1 != EXPECTED_SHA1:
            raise ValueError('Downloaded model checksum differs from the official pinned source. The artifact was discarded.')
        os.replace(downloaded, path)
        receipt = {'model': 'tiny.en', 'source': OFFICIAL_URL, 'whisperCommit': 'd1be6fde11ac6e0407606b4e42fe72d34add8037', 'sha1': sha1, 'sha256': sha256, 'size': size}
        path.with_suffix('.receipt.json').write_text(json.dumps(receipt, indent=2)+'\n')
        print('Official tiny.en model installed and verified:', path)
        print('SHA-1:', sha1, 'SHA-256:', sha256)
    except (urllib.error.URLError, OSError, ValueError) as error:
        raise SystemExit('Official model download failed: '+str(error)+'. Keep TLS verification enabled. Authorize huggingface.co and its actual artifact redirect host in environment settings, or provide the verified official file locally.') from None
    finally:
        if descriptor is not None: os.close(descriptor)
        if os.path.exists(temporary): os.unlink(temporary)

if __name__ == '__main__':
    main()
