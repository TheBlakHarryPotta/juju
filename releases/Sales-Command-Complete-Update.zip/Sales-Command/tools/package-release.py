#!/usr/bin/env python3
from pathlib import Path
import zipfile
root=Path(__file__).resolve().parents[1]
out=root.parent/'Sales-Command-Local-Release.zip'
skip={'.git','node_modules','test-results','playwright-report','.venv','.models','__pycache__','.local','releases'}
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(root.rglob('*')):
  if not p.is_file(): continue
  rel=p.relative_to(root)
  if any(part.startswith('.') and part not in {'.gitignore','.gitattributes'} for part in rel.parts): continue
  if any(part in skip or part.startswith('test-results') or part.startswith('playwright-report') for part in rel.parts) or p.name=='.speech-token' or p.suffix=='.log': continue
  if rel.parts[:2] in [('public','ocr'),('public','pdfjs')]: continue
  z.write(p,Path('Sales-Command')/rel)
print('Release created:',out.name,'bytes:',out.stat().st_size)
with zipfile.ZipFile(out) as z:
 if any('.speech-token' in n or '/.venv/' in n or '/.git/' in n for n in z.namelist()): raise RuntimeError('Private file in release')
 print('Private files excluded; archive integrity:',z.testzip() or 'OK')
