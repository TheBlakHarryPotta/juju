#!/usr/bin/env bash
# Installs a dedicated local codec environment and an exact official whisper.cpp release.
set -euo pipefail
cd "$(dirname "$0")"
TOOLS_DIR="$PWD"
WHISPER_RELEASE=v1.9.5
WHISPER_COMMIT=d1be6fde11ac6e0407606b4e42fe72d34add8037
PYTHON_BIN="${SC_PYTHON:-python3}"
command -v "$PYTHON_BIN" >/dev/null || { echo 'Python 3.12+ is required. Install Python, then rerun this script.' >&2; exit 1; }
"$PYTHON_BIN" -c 'import sys; sys.exit(0 if sys.version_info >= (3,12) else "Python 3.12 or newer is required.")'
command -v git >/dev/null || { echo 'Git is required. Install it, then rerun this script.' >&2; exit 1; }
case "$(uname -s)" in
  Darwin)
    xcode-select -p >/dev/null 2>&1 || { echo 'Apple Command Line Tools are required. Run xcode-select --install, finish installation, then rerun this script.' >&2; exit 1; }
    if [ "$(uname -m)" = arm64 ]; then METAL=ON; else METAL=OFF; fi
    ACCELERATE=ON
    ;;
  Linux)
    command -v cc >/dev/null && command -v c++ >/dev/null && command -v make >/dev/null || { echo 'A C/C++ compiler and make are required. Ask your system administrator to install the development toolchain.' >&2; exit 1; }
    METAL=OFF; ACCELERATE=OFF
    ;;
  *) echo 'This installer supports macOS and Linux. Windows native building requires a separate reviewed setup.' >&2; exit 1 ;;
esac
"$PYTHON_BIN" -m venv .venv
.venv/bin/python -m pip install --disable-pip-version-check -r speech-requirements.txt
if command -v cmake >/dev/null 2>&1; then
  CMAKE_BIN="$(command -v cmake)"
elif [ -x "$TOOLS_DIR/.venv/bin/cmake" ]; then
  CMAKE_BIN="$TOOLS_DIR/.venv/bin/cmake"
else
  .venv/bin/python -m pip install --disable-pip-version-check cmake==4.4.4
  CMAKE_BIN="$TOOLS_DIR/.venv/bin/cmake"
fi
if [ ! -e .whisper.cpp ]; then
  git clone --depth 1 --branch "$WHISPER_RELEASE" https://github.com/ggml-org/whisper.cpp.git .whisper.cpp
fi
[ -d .whisper.cpp/.git ] || { echo 'tools/.whisper.cpp exists but is not the expected source checkout. Preserve it and choose a clean installation location.' >&2; exit 1; }
[ "$(git -C .whisper.cpp remote get-url origin)" = 'https://github.com/ggml-org/whisper.cpp.git' ] || { echo 'Existing whisper.cpp origin is not the official expected source. No checkout was changed.' >&2; exit 1; }
[ "$(git -C .whisper.cpp rev-parse HEAD)" = "$WHISPER_COMMIT" ] || { echo 'Existing whisper.cpp is not the pinned release. Preserve local changes and reinstall the official pinned checkout.' >&2; exit 1; }
[ -z "$(git -C .whisper.cpp status --porcelain --untracked-files=no)" ] || { echo 'Existing whisper.cpp source has local modifications. Preserve them before reinstalling.' >&2; exit 1; }
BUILD_JOBS="${SC_BUILD_JOBS:-3}"
case "$BUILD_JOBS" in [1-8]) ;; *) echo 'SC_BUILD_JOBS must be an integer from 1 to 8.' >&2; exit 1 ;; esac
"$CMAKE_BIN" -S .whisper.cpp -B .whisper.cpp/build -DCMAKE_BUILD_TYPE=Release \
  -DGGML_METAL="$METAL" -DGGML_METAL_EMBED_LIBRARY=ON -DGGML_ACCELERATE="$ACCELERATE" \
  -DGGML_CUDA=OFF -DGGML_NATIVE=OFF -DWHISPER_BUILD_SERVER=OFF \
  -DWHISPER_BUILD_TESTS=OFF -DWHISPER_CURL=OFF -DBUILD_SHARED_LIBS=OFF
"$CMAKE_BIN" --build .whisper.cpp/build --target whisper-cli --parallel "$BUILD_JOBS"
.whisper.cpp/build/bin/whisper-cli --help >/dev/null 2>&1
printf '%s\n' "Built official whisper.cpp $WHISPER_RELEASE ($WHISPER_COMMIT). Metal: $METAL."
printf '%s\n' 'Next: tools/.venv/bin/python tools/download-speech-model.py (run from the repository root).'
printf '%s\n' 'Then: tools/.venv/bin/python tools/speech_server.py. Model downloading is separate and explicit.'
