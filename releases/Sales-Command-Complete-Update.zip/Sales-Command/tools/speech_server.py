#!/usr/bin/env python3
"""Local-only Sales Command transcription. Never downloads a model at runtime."""
from __future__ import annotations
import argparse
import hmac
import json
import os
from pathlib import Path
import secrets
import subprocess
import math
import tempfile
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import time
import wave

MAX_BYTES = 25 * 1024 * 1024
AUDIO_FORMATS = {'.wav': 'wav', '.mp3': 'mp3', '.m4a': 'mov', '.mp4': 'mov', '.webm': 'matroska', '.ogg': 'ogg', '.opus': 'ogg', '.flac': 'flac', '.aac': 'aac'}
ALLOWED_SUFFIXES = set(AUDIO_FORMATS)


def parse_transcription(result, duration):
    """Read whisper-cli JSON; offsets are milliseconds, timestamps are HH:MM:SS,mmm."""
    rows = result.get('transcription')
    if not isinstance(rows, list) or len(rows) > 10000:
        raise ValueError('Invalid transcription segment list.')
    def seconds(value):
        if not isinstance(value, str):
            raise ValueError('Invalid timestamp.')
        parts = value.replace(',', '.').split(':')
        if len(parts) != 3:
            raise ValueError('Invalid timestamp.')
        return float(parts[0]) * 3600 + float(parts[1]) * 60 + float(parts[2])
    output = []
    for row in rows:
        offsets = row.get('offsets', {})
        if 'from' in offsets and 'to' in offsets:
            start, end = float(offsets['from']) / 1000, float(offsets['to']) / 1000
        else:
            timestamps = row.get('timestamps', {})
            start, end = seconds(timestamps.get('from')), seconds(timestamps.get('to'))
        text = row.get('text')
        if not isinstance(text, str) or len(text) > 200000:
            raise ValueError('Invalid segment text.')
        if not math.isfinite(start) or not math.isfinite(end) or start < 0 or end < start or end > duration + 2:
            raise ValueError('Invalid segment time range.')
        if text.strip():
            output.append({'start': round(start, 2), 'end': round(end, 2), 'text': text.strip()})
    if sum(len(row['text']) for row in output) > 200000:
        raise ValueError('Transcription result is too long.')
    return output


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--model', type=Path, default=Path(__file__).parent / '.models' / 'ggml-tiny.en.bin')
    parser.add_argument('--binary', type=Path, default=Path(__file__).parent / '.whisper.cpp' / 'build' / 'bin' / 'whisper-cli')
    parser.add_argument('--port', type=int, default=8766)
    parser.add_argument('--origin', action='append', default=[])
    parser.add_argument('--token-file', type=Path, default=Path(__file__).parent / '.speech-token')
    args = parser.parse_args()
    origins = set(args.origin or ['http://localhost:5173', 'http://127.0.0.1:5173', 'http://localhost:4173', 'http://127.0.0.1:4173'])
    if any(not (origin.startswith('http://localhost:') or origin.startswith('http://127.0.0.1:')) for origin in origins):
        parser.error('Origins must be explicit localhost/127.0.0.1 HTTP development origins. Do not expose this helper to the network.')
    model_path = args.model.resolve()
    binary_path = args.binary.resolve()
    args.token_file.parent.mkdir(parents=True, exist_ok=True)
    if args.token_file.exists():
        token = args.token_file.read_text().strip()
        if len(token) < 32:
            parser.error('Existing pairing token is invalid. Remove the token file to generate a new one.')
    else:
        token = secrets.token_urlsafe(32)
        fd = os.open(args.token_file, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        with os.fdopen(fd, 'w') as file:
            file.write(token + '\n')
    lock = threading.Lock()
    validated_model = None
    try:
        import av
        decode_available = True
    except ImportError:
        decode_available = False

    def model_signature():
        try:
            stat = model_path.stat()
            return (str(model_path), stat.st_size, stat.st_mtime_ns)
        except OSError:
            return None

    def readiness():
        missing = []
        if not decode_available:
            missing.append('PyAV audio decoder; run tools/setup-speech.sh')
        if not binary_path.is_file() or not os.access(binary_path, os.X_OK):
            missing.append('whisper-cli executable; run tools/setup-speech.sh')
        if not model_path.is_file() or not model_path.stat().st_size:
            missing.append('local GGML model; run the model download step')
        available = not missing
        tested = available and validated_model == model_signature()
        return {'ready': available, 'available': available, 'model': model_path.name,
                'engine': 'whisper.cpp', 'modelValidated': tested, 'localOnly': True,
                'message': 'Missing: ' + '; '.join(missing) if missing else
                ('Local binary and model completed a transcription in this helper session.' if tested else
                 'Local binary and model file are available. Model validity and transcription have not been tested in this helper session.')}

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *_):
            # Request bodies, filenames, tokens and transcripts are never logged.
            pass
        def reply(self, status, value):
            raw = json.dumps(value).encode()
            self.send_response(status)
            origin = self.headers.get('Origin', '')
            if origin in origins:
                self.send_header('Access-Control-Allow-Origin', origin)
                self.send_header('Vary', 'Origin')
            self.send_header('Content-Type', 'application/json')
            self.send_header('Content-Length', str(len(raw)))
            self.send_header('Cache-Control', 'no-store')
            self.send_header('X-Content-Type-Options', 'nosniff')
            self.end_headers()
            self.wfile.write(raw)
        def authorized(self, token_required=True):
            # Host protects against DNS rebinding; Origin protects against browser cross-site requests.
            if self.headers.get('Host', '') not in {f'127.0.0.1:{args.port}', f'localhost:{args.port}'}:
                self.reply(403, {'error': 'Invalid local host.'}); return False
            if self.headers.get('Origin', '') not in origins:
                self.reply(403, {'error': 'Origin is not authorized for this local helper.'}); return False
            if token_required and not hmac.compare_digest(self.headers.get('X-Sales-Command-Token', ''), token):
                self.reply(401, {'error': 'Enter the local helper pairing token in Call Desk.'}); return False
            return True
        def do_OPTIONS(self):
            if not self.authorized(False): return
            self.send_response(204)
            self.send_header('Access-Control-Allow-Origin', self.headers['Origin'])
            self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
            self.send_header('Access-Control-Allow-Headers', 'Content-Type, X-Sales-Command-Token, X-File-Name')
            self.send_header('Access-Control-Max-Age', '600')
            self.send_header('Vary', 'Origin')
            self.end_headers()
        def do_GET(self):
            if not self.authorized(): return
            if self.path == '/health': self.reply(200, readiness())
            else: self.reply(404, {'error': 'Unknown local endpoint.'})
        def do_POST(self):
            nonlocal validated_model
            if not self.authorized(): return
            if self.path != '/transcribe': self.reply(404, {'error': 'Unknown local endpoint.'}); return
            if self.headers.get('Content-Type') != 'application/octet-stream':
                self.reply(415, {'error': 'Send audio bytes as application/octet-stream.'}); return
            try: size = int(self.headers.get('Content-Length', '-1'))
            except ValueError: size = -1
            if size <= 0 or size > MAX_BYTES:
                self.reply(413, {'error': 'Audio must be nonempty and no larger than 25 MB.'}); return
            state = readiness()
            if not state['ready']:
                self.reply(503, {'error': state['message']}); return
            if not lock.acquire(blocking=False):
                self.reply(429, {'error': 'Another local transcription is running. Try again when it finishes.'}); return
            try:
                self.connection.settimeout(30)
                audio = self.rfile.read(size)
                if len(audio) != size: self.reply(400, {'error': 'The complete audio file was not received.'}); return
                from urllib.parse import unquote
                suffix = Path(unquote(self.headers.get('X-File-Name', 'audio.wav'))).suffix.lower()
                if suffix not in ALLOWED_SUFFIXES: suffix = '.wav'
                # Fixed generated filename prevents arbitrary writes from the provided filename.
                with tempfile.TemporaryDirectory(prefix='sales-command-audio-') as directory:
                    path = Path(directory) / ('recording' + suffix)
                    path.write_bytes(audio)
                    # Decode incrementally into bounded mono PCM before model preprocessing.
                    # A tiny compressed file may otherwise expand into hours of audio.
                    import av
                    pcm_path = Path(directory) / 'bounded.wav'
                    samples = 0
                    started = time.monotonic()
                    with av.open(str(path), format=AUDIO_FORMATS[suffix], options={'protocol_whitelist': 'file,pipe'}) as container, wave.open(str(pcm_path), 'wb') as output_audio:
                        output_audio.setnchannels(1); output_audio.setsampwidth(2); output_audio.setframerate(16000)
                        resampler = av.AudioResampler(format='s16', layout='mono', rate=16000)
                        for frame in container.decode(audio=0):
                            if time.monotonic() - started > 30:
                                self.reply(422, {'error': 'Audio decoding exceeded 30 seconds. Split or re-export this recording.'}); return
                            for converted in resampler.resample(frame):
                                samples += converted.samples
                                if samples > 15 * 60 * 16000:
                                    self.reply(422, {'error': 'Audio exceeds 15 minutes. Split the recording before transcription.'}); return
                                output_audio.writeframes(converted.to_ndarray().tobytes())
                        for converted in resampler.resample(None):
                            samples += converted.samples
                            if samples > 15 * 60 * 16000:
                                self.reply(422, {'error': 'Audio exceeds 15 minutes. Split the recording before transcription.'}); return
                            output_audio.writeframes(converted.to_ndarray().tobytes())
                    duration = samples / 16000
                    output_prefix = Path(directory) / 'transcript'
                    # Argument-list subprocess, no shell, no network downloads, no transcript logs.
                    # whisper-cli's normal GPU discovery uses Metal on supported Apple builds.
                    subprocess.run([str(binary_path), '-m', str(model_path), '-f', str(pcm_path),
                                    '-oj', '-of', str(output_prefix), '-t', str(min(4, os.cpu_count() or 2)),
                                    '-l', 'en'], check=True, timeout=180,
                                   stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                                   stderr=subprocess.DEVNULL)
                    json_path = output_prefix.with_suffix('.json')
                    if not json_path.is_file() or json_path.stat().st_size > 4 * 1024 * 1024:
                        raise ValueError('Missing or oversized transcription result.')
                    result = json.loads(json_path.read_text(encoding='utf-8'))
                    output = parse_transcription(result, duration)
                    text = '\n'.join(segment['text'] for segment in output).strip()
                    validated_model = model_signature()
                    self.reply(200, {'text': text, 'segments': output, 'duration': round(duration, 2),
                                     'language': result.get('result', {}).get('language', 'en'),
                                     'engine': 'whisper.cpp', 'localOnly': True, 'reviewRequired': True,
                                     'warning': 'Review names, dates, numbers and the end of the recording. ASR can omit speech or hallucinate words.'})
            except subprocess.TimeoutExpired:
                self.reply(422, {'error': 'Local transcription exceeded three minutes. Split this recording or use a smaller model; no transcript was saved.'})
            except Exception:
                self.reply(422, {'error': 'Local transcription failed. Check the model installation and audio format, or enter the transcript manually.'})
            finally:
                lock.release()
    server = ThreadingHTTPServer(('127.0.0.1', args.port), Handler)
    print(f'Local speech helper listening at http://127.0.0.1:{args.port}', flush=True)
    print('Local model status: ' + readiness()['message'], flush=True)
    print('Pairing token file: ' + str(args.token_file.resolve()), flush=True)
    print('Open that local file privately and paste its value into Call Desk. Never share it in chat.', flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        server.server_close()

if __name__ == '__main__':
    main()
