#!/usr/bin/env python3
"""Stage and verify a static-app update; retain local engine, model and browser data."""
import argparse
import hashlib
from pathlib import Path
import shutil
import tempfile
import uuid

def update_app(source, target):
    source, target = Path(source).resolve(), Path(target).resolve()
    if source == target:
        raise ValueError('Choose your existing installed Sales-Command folder, not this newly extracted update folder.')
    incoming, installed = source / 'dist', target / 'dist'
    if target == incoming or incoming in target.parents:
        raise ValueError('Choose an existing app folder outside the new dist folder.')
    required = ['index.html', 'bridge.js', 'contracts-bridge.js', 'service-worker.js']
    if any(not (incoming / name).is_file() for name in required):
        raise ValueError('The update folder is incomplete. Keep its dist folder with this updater.')
    if not (installed / 'index.html').is_file() or not (target / 'start-mac.command').is_file():
        raise ValueError('Choose the existing Sales-Command app folder that you already use.')
    for path in incoming.rglob('*'):
        if path.is_symlink():
            raise ValueError('Unexpected symbolic link in the update. Download a fresh package.')
    backup = target / '.app-backups' / uuid.uuid4().hex
    backup.mkdir(parents=True)
    stage = Path(tempfile.mkdtemp(prefix='.app-update-', dir=target))
    old_moved = False
    try:
        shutil.copytree(incoming, stage / 'dist')
        for path in incoming.rglob('*'):
            if not path.is_file(): continue
            copied = stage / 'dist' / path.relative_to(incoming)
            if hashlib.sha256(path.read_bytes()).digest() != hashlib.sha256(copied.read_bytes()).digest():
                raise ValueError('Update copy verification failed. Your installed app was not changed.')
        installed.rename(backup / 'dist')
        old_moved = True
        try:
            (stage / 'dist').rename(installed)
        except Exception:
            (backup / 'dist').rename(installed)
            old_moved = False
            raise
        return backup
    finally:
        shutil.rmtree(stage, ignore_errors=True)
        if not old_moved:
            try: backup.rmdir()
            except OSError: pass

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument('--target', type=Path, required=True)
    args = parser.parse_args()
    try:
        backup = update_app(args.source, args.target)
    except (ValueError, OSError) as error:
        raise SystemExit(str(error))
    print('App updated. Your installed speech engine, model and pairing token were kept.')
    print('Previous app files retained at:', backup)
    print('Start your existing start-mac.command. Open the app once while online, then close ALL Sales Command tabs and reopen it so the new offline cache can activate.')

if __name__ == '__main__':
    main()
