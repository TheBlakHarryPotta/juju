#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if [ "$(uname -s)" != Darwin ]; then echo 'This launcher is for macOS.'; exit 1; fi
echo 'Before updating, export an encrypted backup from Device & Backups.'
echo 'Choose the existing Sales-Command folder you already use, not this update folder.'
TARGET_APP="$(osascript -e 'POSIX path of (choose folder with prompt "Choose your EXISTING installed Sales-Command folder")')"
if [ -x "$TARGET_APP/tools/.venv/bin/python" ]; then
  "$TARGET_APP/tools/.venv/bin/python" tools/update-app.py --target "$TARGET_APP"
else
  python3 tools/update-app.py --target "$TARGET_APP"
fi
