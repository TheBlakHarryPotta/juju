import { defineConfig } from 'vite';
import { readdirSync,readFileSync } from 'node:fs';
import { join } from 'node:path';
import { createHash } from 'node:crypto';
function listFiles(dir,prefix='') {
 return readdirSync(dir,{withFileTypes:true}).flatMap(item=>item.isDirectory()?listFiles(join(dir,item.name),prefix+item.name+'/'):[prefix+item.name]);
}
export default defineConfig({
 server:{host:'0.0.0.0',port:5173,strictPort:true,fs:{deny:['.env','.env.*','*.{crt,pem}','**/.git/**','**/.speech-token','**/.venv/**','**/.models/**']}},
 preview:{host:'0.0.0.0',port:4173,strictPort:true},
 build:{chunkSizeWarningLimit:1500},
 plugins:[{
  name:'local-offline-shell',
  configureServer(server) {
   server.middlewares.use((req,res,next)=>{
    let path;try{path=decodeURIComponent(new URL(req.url,'http://localhost').pathname);}catch{res.statusCode=400;res.end('Invalid URL');return;}
    const parts=path.replaceAll('\\','/').split('/');
    if(parts.some(part=>part==='.speech-token'||part==='.venv'||part==='.models'||part==='.git'||part==='.env'||part.startsWith('.env.'))) {
      res.statusCode=403;res.setHeader('Content-Type','text/plain');res.end('Private local application files are not served.');return;
    }
    next();
   });
  },
  generateBundle(_,bundle){
   const publicFiles=listFiles('public').filter(file=>file!=='service-worker.js');
   const files=['/',...Object.keys(bundle).filter(file=>!file.endsWith('.map')).map(file=>'/'+file),...publicFiles.map(file=>'/'+file)];
   const digest=createHash('sha256').update(JSON.stringify(Object.keys(bundle))).update(readFileSync('index.html'));
   for (const file of publicFiles) digest.update(file).update(readFileSync(join('public',file)));
   const fingerprint=digest.digest('hex').slice(0,12);
   this.emitFile({type:'asset',fileName:'service-worker.js',source:`
const CACHE='sales-command-${fingerprint}';
const FILES=${JSON.stringify([...new Set(files)])};
self.addEventListener('install',event=>event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(FILES))));
self.addEventListener('activate',event=>event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(key=>key.startsWith('sales-command-')&&key!==CACHE).map(key=>caches.delete(key)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',event=>{const url=new URL(event.request.url);if(event.request.method!=='GET'||url.origin!==self.location.origin)return;if(event.request.mode==='navigate'){event.respondWith(fetch(event.request).catch(()=>caches.match('/')));return;}event.respondWith(caches.match(event.request,{ignoreVary:true}).then(hit=>hit||fetch(event.request)));});
`});
  }
 }]
});
