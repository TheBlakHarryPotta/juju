# Sales Command

A personal, local-first hotel sales web application. Preserves the supplied Aurora dashboards and hotel sales calculations, with local document capture, a booking-code vault, document templates, account production history, signature placement, and encrypted backups.

## Run

Requires Node.js 22.12+ (tested with Node 24), npm, and a modern browser.

```sh
npm ci
npm run dev
```

`npm ci` verifies the lockfile artifacts and copies the installed OCR model, worker, WASM and PDF resources into `public/`. Application files stay in the browser's IndexedDB and local compatibility storage. Nothing automatically uploads to a server or cloud AI service.

For a production build:

```sh
npm run build
npm run preview
```

Deploy the contents of `dist/` to an HTTPS static host when you choose one. Use HTTPS for microphone access and PWA installation away from localhost. This repository does not deploy or publish automatically. Production assets are cached for offline use after the first successful load; live processes do not survive an environment restart. Update the installed app online to receive new builds. The local database belongs to the site's origin; changing the host/port creates a separate workspace. Transfer data through an encrypted backup before moving origins.

## First use

Open **Device & Backups** to create a blank hotel, preserving the original sample workspace. Add additional hotels from the hotel selector. Export an encrypted backup with a unique passphrase and keep it outside the browser. Restore replaces all local hotels; export first. The passphrase cannot be reset. Browser persistence does not substitute for a backup.

- **SRP & Group Code Vault:** store/search codes as text, effective dates, sources and verification.
- **Templates & RFP Library:** keep approved text and source documents, edit versioned templates, fill named fields and export genuine DOCX. DOCX template placeholders use double braces, e.g. `{{contact}}`. Attached source files are retained unchanged.
- **Account Radar:** import mapped CSV production with explicit periods, basis and coverage; compare complete, nonoverlapping, equal-length periods. Missing account rows are not treated as zero.
- **Signature Studio:** compose approved text, type/draw/upload your own signature, drag/resize marks and explicitly apply them to a print/PDF output. This is a visual mark, not identity-verified electronic signing. It does not edit arbitrary uploaded PDF contracts.
- **Files & Capture:** drop/paste/upload originals; locally extract supported text PDFs, DOCX, spreadsheets and screenshots. Review text and proposed fields before saving records. Unsupported files are labeled attachment-only. Processing limits and coverage are displayed.
- **Call Desk:** record a voice memo, upload audio or enter notes. Review a transcript and edit field suggestions. Local automatic transcription requires the optional companion described in `tools/README.md`; mic recording alone does not capture another application's phone-call audio.

Default limits include 25 MB per file, ten files per batch and a 500 MB attachment vault. PDF inspection is bounded and OCR coverage is explicitly labeled; a partial extraction is never a complete contract review. OCR, transcription and deterministic field suggestions require human verification of names, dates, rates and room counts.

## Checks

```sh
npm test
node tests/amad-security-probes.cjs
npm run build
```

Browser tests use system Chromium at `/usr/bin/chromium`; override the Playwright configuration for another installation. See `docs/VALIDATION.md` for the current results and limits. Original handoff code and reports remain separately under the onboarding workspace, not required at runtime.

## Data and system boundaries

This first version has no automatic phone/computer synchronization or coworker accounts. Device/browser access controls protect the unlocked local database; only exported encrypted backups have application-level encryption. Backup/restore includes attachments and all hotels. Conflicting stale-tab edits are rejected and retained for recovery instead of silently overwriting newer data.

PEP, OnQ, Hilton Lobby, Lighthouse, ProfitSword and Delphi are separate systems. Use authorized exports/screenshots. No credentials, live private API integration, automated outreach or write-back is included. A locally saved SRP is a reference, not a live PEP availability check.

## Repository layout

- `index.html`: preserved legacy sales dashboards with corrected security/integrity paths.
- `public/bridge.js`: narrow adapter to the established calculations and navigation.
- `src/storage.js`: transactional local state, conflicts and encrypted backup/restore.
- `src/workspaces*.js`: SRP, templates, production radar and signature workflows.
- `src/intake.js`: bounded local extraction, OCR, recording and transcript review.
- `src/design.*`: responsive Aurora presentation and focused workspaces.
- `tools/`: optional local speech companion.
- `docs/`: decisions, workflows, dependency inventory and validation.

Each cloud task already has an isolated checkout. Work in the existing repository; do not create worktrees unless explicitly requested.

## M1 native speech engine

The current speech engine is whisper.cpp v1.9.5, pinned to the official source commit in `tools/setup-speech.sh`. `setup-mac.command` builds it natively with Metal on Apple Silicon and downloads a checksum-verified tiny.en model. `start-mac.command` starts the local app and authenticated audio bridge. Python handles HTTP and codec conversion only; ML inference runs in a short-lived native process when requested. See `docs/WHISPER-VALIDATION.md` for the actual build/test evidence and model-download blocker. The Linux executable built in the cloud is not installed on or compatible with your Mac; the installer builds the Mac executable on your Mac.
