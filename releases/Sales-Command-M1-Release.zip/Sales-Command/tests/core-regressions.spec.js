import { test, expect } from '@playwright/test';


async function openApp(page) {
  await page.goto('/');
  await page.waitForFunction(() => window.SC?.storage);
  await page.evaluate(async () => { await SC.ready; });
}

test('host-free app starts and renders every legacy view without runtime failures', async ({ page }) => {
  const errors = [];
  page.on('pageerror', error => errors.push(error.message));
  await openApp(page);
  const views = await page.evaluate(() => NAV.flatMap(([, items]) => items.map(([id]) => id)));
  expect(views.length).toBeGreaterThan(20);
  for (const id of views) {
    await page.evaluate(id => { view = id; render(); }, id);
    await expect(page.locator('#view')).not.toBeEmpty();
  }
  expect(errors).toEqual([]);
});

test('extraction field names cannot create event handlers or mutate prototypes', async ({ page }) => {
  await openApp(page);
  const result = await page.evaluate(() => {
    window.__qaInjected = 0;
    const container = document.createElement('div'); document.body.appendChild(container);
    const key = 'x" onpointerover="window.__qaInjected=1" z="';
    container.innerHTML = xEd({ [key]: 'value', rows: [{ [key]: 'row' }] }, 'fields');
    const handlers = container.querySelectorAll('[onpointerover]').length;
    container.querySelectorAll('input').forEach(el => el.dispatchEvent(new Event('pointerover')));
    const object = {};
    try { xSet(object, '__proto__.__qaPolluted', 'yes'); } catch {}
    try { xSet(object, 'constructor.prototype.__qaPolluted', 'yes'); } catch {}
    const result = { handlers, executed: window.__qaInjected, polluted: ({}).__qaPolluted || null };
    container.remove(); delete Object.prototype.__qaPolluted;
    return result;
  });
  expect(result).toEqual({ handlers: 0, executed: 0, polluted: null });
});

test('cloud push keeps one immutable property snapshot across asynchronous waits', async ({ page }) => {
  await openApp(page);
  const result = await page.evaluate(async () => {
    const writes = [];
    const original = { state, registry: HR, col: X.col, pulled: X.pulled, pushing: X.pushing, again: X.again, last: X.last, base: X.base };
    const source = structuredClone(state); source.settings.hotel = 'QA PROPERTY A'; source.bookings = [{ name: 'A private account' }]; source._at = 100;
    state = source; HR = { ...HR, active: 'qaA' };
    X.pulled = true; X.pushing = false; X.again = false; X.last = {}; X.base = {};
    X.col = { doc: key => ({
      get: async () => { state = { ...structuredClone(source), settings: { ...source.settings, hotel: 'QA PROPERTY B' }, bookings: [{ name: 'B private account' }], _at: 200 }; HR.active = 'qaB'; return { exists: false }; },
      set: async data => writes.push([key, structuredClone(data)]), delete: async () => {},
    }) };
    try { await cloudPush(); return writes; }
    finally { state = original.state; HR = original.registry; Object.assign(X, { col: original.col, pulled: original.pulled, pushing: original.pushing, again: original.again, last: original.last, base: original.base }); }
  });
  expect(result.length).toBeGreaterThan(0);
  expect(result.every(([key]) => key.includes('qaA'))).toBe(true);
  expect(JSON.stringify(result)).toContain('A private account');
  expect(JSON.stringify(result)).not.toContain('B private account');
});

test('quota errors never claim a successful cloud save', async ({ page }) => {
  await openApp(page);
  const result = await page.evaluate(async () => {
    const original = Storage.prototype.setItem, col = X.col, put = SC.storage.db.snapshots.put;
    Storage.prototype.setItem = () => { throw new DOMException('QA quota exhausted', 'QuotaExceededError'); };
    SC.storage.db.snapshots.put = async () => { throw new DOMException('QA durable quota exhausted', 'QuotaExceededError'); };
    X.col = {};
    try {
      xWriteLocal();
      try { await SC.storage.flush(); } catch {}
      return { label: document.getElementById('saved').textContent, state: SC.storage.status.state };
    } finally { Storage.prototype.setItem = original; X.col = col; SC.storage.db.snapshots.put = put; }
  });
  expect(result.label).not.toMatch(/saved to cloud/i);
  expect(result.label).toMatch(/not saved|fail|backup|error|quota/i);
  expect(result.state).toBe('error');
});

test('cutoff countdown uses current date despite a stale production report', async ({ page }) => {
  await openApp(page);
  const result = await page.evaluate(() => {
    const today = todayISO();
    const cutoff = addDays(today, -3), asOf = addDays(today, -20);
    revState().wash = { asOf, groups: [] };
    const facts = xGroupFacts({ key: 'qa', name: 'QA group', wash: { name: 'QA group', cutoff, block: 10, pu: 3, avail: 7, nights: [] } });
    return { toCut: facts.toCut, cutoff, actual: today };
  });
  expect(result.toCut).toBe(-3);
});

test('edits persist through page reload', async ({ page }) => {
  await openApp(page);
  await page.evaluate(async () => { state.settings.preparedBy = 'QA durable manager'; save(); await SC.storage.flush(); });
  await page.reload();
  await page.waitForFunction(() => window.SC?.storage);
  const saved = await page.evaluate(async () => { await SC.storage.ready; return state.settings.preparedBy; });
  expect(saved).toBe('QA durable manager');
});

test('stale second tab cannot overwrite a newer durable edit', async ({ page, context }) => {
  await openApp(page);
  const second = await context.newPage(); await openApp(second);
  await page.evaluate(async () => { state.settings.preparedBy = 'QA newer tab'; save(); await SC.storage.flush(); });
  const conflict = await second.evaluate(async () => {
    state.settings.preparedBy = 'QA stale tab'; save();
    try { await SC.storage.flush(); return { rejected: false }; }
    catch (e) { return { rejected: true, message: e.message }; }
  });
  expect(conflict.rejected).toBe(true);
  expect(conflict.message).toMatch(/another tab|newer|conflict/i);
  const durable = await page.evaluate(async () => (await SC.storage.db.snapshots.get(SC.propertyId)).state.settings.preparedBy);
  expect(durable).toBe('QA newer tab');
  second.on('dialog', d => d.accept()); await second.close();
});

test('encrypted backup rejects wrong passphrase without changing records and restores originals', async ({ page }) => {
  await openApp(page);
  const result = await page.evaluate(async () => {
    await SC.storage.ready;
    state.settings.preparedBy = 'QA before backup'; save(); await SC.storage.flush();
    await SC.storage.db.files.put({ id: 'qa-backup-file', propertyId: SC.propertyId, name: 'qa.txt', blob: new Blob(['QA binary retained'], { type: 'text/plain' }) });
    const blob = await SC.storage.backup('QA correct passphrase 2026');
    const text = await blob.text();
    state.settings.preparedBy = 'QA after backup'; save(); await SC.storage.flush();
    let error = '';
    try { await SC.storage.restore(text, 'QA incorrect passphrase 2026'); } catch (e) { error = e.message; }
    const afterBad = (await SC.storage.db.snapshots.get(SC.propertyId)).state.settings.preparedBy;
    await SC.storage.restore(text, 'QA correct passphrase 2026');
    return { encrypted: !text.includes('QA before backup'), format: JSON.parse(text).format, error, afterBad, restored: state.settings.preparedBy, file: await (await SC.storage.db.files.get('qa-backup-file')).blob.text() };
  });
  expect(result.encrypted).toBe(true);
  expect(result.format).toBe('sales-command-encrypted');
  expect(result.error).toMatch(/incorrect|changed/i);
  expect(result.afterBad).toBe('QA after backup');
  expect(result.restored).toBe('QA before backup');
  expect(result.file).toBe('QA binary retained');
});

test('new workspaces remain usable without horizontal page overflow on phone', async ({ page }) => {
  await page.setViewportSize({ width: 390, height: 844 });
  await openApp(page);
  for (const id of ['srpVault', 'templateLibrary', 'accountRadar', 'signatureStudio', 'intake', 'calls']) {
    await page.evaluate(id => { view = id; render(); }, id);
    const overflow = await page.evaluate(() => ({ full: document.documentElement.scrollWidth, viewport: innerWidth, content: document.getElementById('view').textContent.trim() }));
    expect(overflow.content.length, id).toBeGreaterThan(30);
    expect(overflow.full, id).toBeLessThanOrEqual(overflow.viewport + 2);
  }
});

test('durable save captures property and state before the caller switches hotels', async ({ page }) => {
  await page.goto('/src/storage.js');
  const result = await page.evaluate(async () => {
    const { initStorage } = await import('/src/storage.js');
    const fixture = { propertyId: 'qaA', state: { settings: { hotel: 'Property A' }, bookings: [{ name: 'A account' }] }, registry: { active: 'qaA', list: [{ id: 'qaA' }, { id: 'qaB' }] }, setState(value) { this.state = value; } };
    const storage = initStorage(fixture); await storage.ready;
    fixture.state.settings.hotel = 'Property A edited'; storage.capture();
    fixture.propertyId = 'qaB'; fixture.registry.active = 'qaB'; fixture.state = { settings: { hotel: 'Property B' }, bookings: [{ name: 'B account' }] };
    await storage.flush();
    const first = await storage.db.snapshots.get('qaA');
    storage.capture(); await storage.flush(); const second = await storage.db.snapshots.get('qaB');
    return { a: first.state, b: second.state };
  });
  expect(result.a.settings.hotel).toBe('Property A edited');
  expect(result.a.bookings[0].name).toBe('A account');
  expect(result.b.settings.hotel).toBe('Property B');
  expect(result.b.bookings[0].name).toBe('B account');
});

test('new hotel starts blank and visiting contracts or plans does not inject sample hotel details', async ({ page }) => {
  await openApp(page);
  const result = await page.evaluate(async () => {
    const previous = SC.propertyId;
    const id = await SC.createProperty({ name: 'QA independent hotel', short: 'QA Independent', rooms: 101 });
    SC.navigate('plan'); SC.navigate('contracts');
    const fresh = structuredClone(state);
    const blankText = document.getElementById('view').textContent;
    await SC.switchProperty(previous);
    const original = state.settings.hotel;
    await SC.switchProperty(id);
    return { id, property: SC.propertyId, fresh, blankText, original, restored: state.settings.hotel };
  });
  expect(result.property).toBe(result.id);
  expect(result.restored).toBe('QA independent hotel');
  expect(result.fresh.bookings).toEqual([]); expect(result.fresh.accounts).toEqual([]); expect(result.fresh.activities).toEqual([]);
  expect(result.fresh.ap.actions).toEqual([]);
  expect(JSON.stringify(result.fresh.settings.k)).not.toMatch(/Cranberry|724|pa\.hampton/i);
  expect(result.blankText).not.toMatch(/Cranberry|Westinghouse/);
});

test('backup restore refuses to replace data while local processing is active', async ({ page }) => {
  await openApp(page);
  const result = await page.evaluate(async () => {
    state.settings.preparedBy = 'QA protected edit'; save(); await SC.storage.flush();
    const backup = await SC.storage.backup('QA restore guard passphrase');
    const previous = SC.hasActiveJobs; SC.hasActiveJobs = () => true;
    try {
      let message = ''; try { await SC.storage.restore(backup, 'QA restore guard passphrase'); } catch (e) { message = e.message; }
      return { message, name: state.settings.preparedBy, restoring: SC.storage.isRestoring() };
    } finally { SC.hasActiveJobs = previous; }
  });
  expect(result.message).toMatch(/finish|processing|recording/i);
  expect(result.name).toBe('QA protected edit'); expect(result.restoring).toBe(false);
});

test('development server refuses to serve the local speech pairing credential', async ({ request }) => {
  for (const path of ['/tools/.speech-token', '/tools/.speech-token?raw', '/%74ools/.speech-token', '/@fs/workspace/juju/tools/.speech-token']) {
    const response = await request.get(path);
    expect(response.status(), path).toBe(403);
  }
});
